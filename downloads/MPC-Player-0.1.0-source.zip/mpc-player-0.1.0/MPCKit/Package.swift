// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "MPCPlayer",
    platforms: [.macOS(.v14), .iOS(.v17)],
    products: [
        .library(name: "PlayerCore", targets: ["PlayerCore"]),
        .library(name: "PlayerUI", targets: ["PlayerUI"]),
        .executable(name: "MPCPlayer", targets: ["MPCPlayerMac"]),
    ],
    dependencies: [
        // LGPL build of libmpv + FFmpeg. Switch to "MPVKit-GPL" for the GPL-only codecs/protocols.
        .package(url: "https://github.com/mpvkit/MPVKit.git", exact: "1.1.0-n9.0.2"),
    ],
    targets: [
        .target(
            name: "PlayerCore",
            dependencies: [.product(name: "MPVKit", package: "MPVKit")],
            // The video layer uses OpenGL (libmpv render API), deprecated but supported.
            swiftSettings: [.unsafeFlags(["-Xcc", "-DGL_SILENCE_DEPRECATION"])]
        ),
        .target(
            name: "PlayerUI",
            dependencies: ["PlayerCore"]
        ),
        .executableTarget(
            name: "MPCPlayerMac",
            dependencies: ["PlayerCore", "PlayerUI"]
        ),
    ]
)
