import AppKit
import SwiftUI
import PlayerCore
import PlayerUI

@MainActor
final class AppDelegate: NSObject, NSApplicationDelegate, NSWindowDelegate {
    private var model: AppModel!
    private var window: NSWindow!
    private let windowController = MacWindowController()
    private var optionsWindow: NSWindow?
    private var pendingURLs: [URL] = []
    private var launched = false

    func applicationWillFinishLaunching(_ notification: Notification) {
        model = AppModel()
        NSApp.mainMenu = MacMainMenu.build(model: model) { [weak self] in self?.showOptions() }
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        let window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 800, height: 520),
            styleMask: [.titled, .closable, .miniaturizable, .resizable],
            backing: .buffered, defer: false)
        window.title = "MPC Player"
        window.isReleasedWhenClosed = false
        window.delegate = self
        window.contentView = NSHostingView(rootView: MacPlayerView(model: model))
        window.center()
        window.setFrameAutosaveName("MPCPlayerMainWindow")
        self.window = window
        windowController.attach(window: window, model: model) { [weak self] in self?.showOptions() }
        window.makeKeyAndOrderFront(nil)
        window.makeFirstResponder(model.videoView)
        NSApp.activate(ignoringOtherApps: true)
        launched = true

        // Files passed on the command line (`MPCPlayer movie.mkv`) that AppKit did not
        // already deliver through application(_:open:).
        let cli = CommandLine.arguments.dropFirst()
            .filter { !$0.hasPrefix("-") && !["png", "jpg"].contains(($0 as NSString).pathExtension) }
            .map { URL(fileURLWithPath: ($0 as NSString).expandingTildeInPath) }
            .filter { FileManager.default.fileExists(atPath: $0.path) }
        let urls = pendingURLs.isEmpty ? Array(cli) : pendingURLs
        pendingURLs = []
        if !urls.isEmpty { model.open(urls: urls) }
        SelfTest.schedule(model: model, window: window)
    }

    func application(_ application: NSApplication, open urls: [URL]) {
        let media = urls.filter { !["png", "jpg"].contains($0.pathExtension.lowercased()) }
        if launched { model.open(urls: media) } else { pendingURLs += media }
    }

    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }

    func applicationWillTerminate(_ notification: Notification) {
        model.persistState()
        model.player.shutdown()
    }

    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        if !flag { window.makeKeyAndOrderFront(nil) }
        return true
    }

    func showOptions() {
        if let optionsWindow {
            optionsWindow.makeKeyAndOrderFront(nil)
            return
        }
        let w = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 820, height: 600),
            styleMask: [.titled, .closable, .resizable],
            backing: .buffered, defer: false)
        w.title = "Options"
        w.isReleasedWhenClosed = false
        w.contentView = NSHostingView(rootView: OptionsView(store: model.store) { [weak w] in w?.close() })
        w.center()
        w.setFrameAutosaveName("MPCPlayerOptionsWindow")
        optionsWindow = w
        w.makeKeyAndOrderFront(nil)
    }
}
