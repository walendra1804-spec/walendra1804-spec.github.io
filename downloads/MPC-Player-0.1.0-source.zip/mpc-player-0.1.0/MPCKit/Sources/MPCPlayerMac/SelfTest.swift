import AppKit
import PlayerCore
import PlayerUI

/// Developer automation for verifying the UI without Screen Recording permission:
///   MPCPlayer file.mp4 --perform toggleStats,togglePlaylist --snapshot out.png --quit-after 8
/// `--snapshot` composites the SwiftUI chrome with mpv's rendered video frame
/// (SwiftUI's OSD overlay is not part of the composite).
@MainActor
enum SelfTest {
    static func schedule(model: AppModel, window: NSWindow) {
        let args = CommandLine.arguments
        func value(_ flag: String) -> String? {
            guard let i = args.firstIndex(of: flag), i + 1 < args.count else { return nil }
            return args[i + 1]
        }
        let base = Double(value("--delay") ?? "3") ?? 3
        if let list = value("--perform") {
            let cmds = list.split(separator: ",").compactMap { PlayerCommand(rawValue: String($0)) }
            DispatchQueue.main.asyncAfter(deadline: .now() + base) {
                cmds.forEach(model.perform)
            }
        }
        // --steps a,b,c runs one command per second and logs the video geometry
        // after each, to compare the view/layer size with what mpv renders at.
        if let list = value("--steps") {
            let cmds = list.split(separator: ",").map(String.init)
            for (i, name) in cmds.enumerated() {
                DispatchQueue.main.asyncAfter(deadline: .now() + base + Double(i)) {
                    if let cmd = PlayerCommand(rawValue: name) {
                        model.perform(cmd)
                    } else if name.hasPrefix("set:"), let eq = name.firstIndex(of: "=") {
                        // set:<mpv property>=<value>
                        let prop = String(name[name.index(name.startIndex, offsetBy: 4)..<eq])
                        model.player.setString(prop, String(name[name.index(after: eq)...]))
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) { probe(model: model, label: name) }
                }
            }
        }
        if let path = value("--snapshot") {
            DispatchQueue.main.asyncAfter(deadline: .now() + base + 1.5) {
                capture(model: model, window: window, to: path)
                // Any other open window (e.g. Options) is saved next to it as <path>.<title>.png
                for other in NSApp.windows where other !== window && other.isVisible {
                    guard let v = other.contentView, let rep = v.bitmapImageRepForCachingDisplay(in: v.bounds) else { continue }
                    v.cacheDisplay(in: v.bounds, to: rep)
                    let name = other.title.isEmpty ? "window" : other.title
                    if let png = rep.representation(using: .png, properties: [:]) {
                        try? png.write(to: URL(fileURLWithPath: path + ".\(name).png"))
                    }
                }
            }
        }
        if let q = value("--quit-after"), let secs = Double(q) {
            DispatchQueue.main.asyncAfter(deadline: .now() + secs) { NSApp.terminate(nil) }
        }
    }

    static func probe(model: AppModel, label: String) {
        let v = model.videoView, l = v.renderLayer, p = model.player
        let osd = ["w", "h", "mt", "mb", "ml", "mr"].map { "\($0)=\(p.getInt("osd-dimensions/\($0)") ?? -1)" }
        print("probe[\(label)] view=\(v.bounds.size) layer=\(l.bounds.size)@\(l.contentsScale)x mpv-osd(\(osd.joined(separator: " "))) paused=\(p.isPaused) hwdec=\(p.getString("hwdec-current") ?? "?") vo=\(p.getString("current-vo") ?? "?")")
    }

    static func capture(model: AppModel, window: NSWindow, to path: String) {
        guard let content = window.contentView,
              let rep = content.bitmapImageRepForCachingDisplay(in: content.bounds) else { return }
        content.cacheDisplay(in: content.bounds, to: rep)
        let size = content.bounds.size
        let image = NSImage(size: size)
        image.lockFocus()
        rep.draw(in: NSRect(origin: .zero, size: size))
        if model.player.hasMedia, let cg = model.player.screenshotImage(withSubtitles: true) {
            let frame = NSImage(cgImage: cg, size: NSSize(width: cg.width, height: cg.height))
            var r = model.videoView.convert(model.videoView.bounds, to: content)
            if content.isFlipped { r.origin.y = size.height - r.maxY }
            // Letterbox the frame inside the video area like mpv does.
            let fs = frame.size
            let scale = min(r.width / fs.width, r.height / fs.height)
            let fit = NSRect(x: r.midX - fs.width * scale / 2, y: r.midY - fs.height * scale / 2,
                             width: fs.width * scale, height: fs.height * scale)
            NSColor.black.setFill()
            r.fill()
            frame.draw(in: fit)
        }
        image.unlockFocus()
        if let tiff = image.tiffRepresentation, let bmp = NSBitmapImageRep(data: tiff),
           let png = bmp.representation(using: .png, properties: [:]) {
            try? png.write(to: URL(fileURLWithPath: path))
            print("selftest: snapshot written to \(path)")
        }
        print("selftest: status='\(model.statusText)' pos=\(model.player.position) dur=\(model.player.duration) tracks=\(model.player.tracks.map(\.displayName))")
    }
}
