import Foundation

public struct KeyModifiers: OptionSet, Codable, Hashable, Sendable {
    public let rawValue: Int
    public init(rawValue: Int) { self.rawValue = rawValue }

    public static let command = KeyModifiers(rawValue: 1 << 0)
    public static let control = KeyModifiers(rawValue: 1 << 1)
    public static let option  = KeyModifiers(rawValue: 1 << 2)
    public static let shift   = KeyModifiers(rawValue: 1 << 3)
}

/// A platform-neutral key chord. `key` is a normalized name: a lowercase
/// character ("a", ".", "[") or a special key ("space", "left", "f5", ...).
public struct KeyBinding: Codable, Hashable, Sendable, CustomStringConvertible {
    public var key: String
    public var modifiers: KeyModifiers

    public init(_ key: String, _ modifiers: KeyModifiers = []) {
        self.key = key
        self.modifiers = modifiers
    }

    public var description: String { displayString }

    /// Mac-style chord label, e.g. "⌘⇧→".
    public var displayString: String {
        var s = ""
        if modifiers.contains(.control) { s += "⌃" }
        if modifiers.contains(.option) { s += "⌥" }
        if modifiers.contains(.shift) { s += "⇧" }
        if modifiers.contains(.command) { s += "⌘" }
        return s + Self.displayName(forKey: key)
    }

    public static func displayName(forKey key: String) -> String {
        switch key {
        case "space": return "Space"
        case "return": return "↩"
        case "escape": return "Esc"
        case "tab": return "⇥"
        case "delete": return "⌫"
        case "forwarddelete": return "⌦"
        case "left": return "←"
        case "right": return "→"
        case "up": return "↑"
        case "down": return "↓"
        case "home": return "Home"
        case "end": return "End"
        case "pageup": return "PgUp"
        case "pagedown": return "PgDn"
        default:
            if key.hasPrefix("f"), key.count > 1, Int(key.dropFirst()) != nil { return key.uppercased() }
            return key.uppercased()
        }
    }

    /// Normalizes a character delivered by AppKit/UIKit/SwiftUI (including the
    /// private-use function-key code points) into a key name.
    public static func keyName(for character: Character) -> String? {
        guard let scalar = character.unicodeScalars.first else { return nil }
        switch scalar.value {
        case 0x20: return "space"
        case 0x0D, 0x03: return "return"
        case 0x1B: return "escape"
        case 0x09, 0x19: return "tab"
        case 0x7F, 0x08: return "delete"
        case 0xF728: return "forwarddelete"
        case 0xF700: return "up"
        case 0xF701: return "down"
        case 0xF702: return "left"
        case 0xF703: return "right"
        case 0xF704...0xF71B: return "f\(scalar.value - 0xF704 + 1)"
        case 0xF729: return "home"
        case 0xF72B: return "end"
        case 0xF72C: return "pageup"
        case 0xF72D: return "pagedown"
        default:
            if scalar.value < 0x20 { return nil }
            return String(character).lowercased()
        }
    }

    /// Inverse of `keyName(for:)`, used to build SwiftUI `KeyEquivalent`s.
    public var character: Character? {
        switch key {
        case "space": return " "
        case "return": return "\r"
        case "escape": return "\u{1B}"
        case "tab": return "\t"
        case "delete": return "\u{7F}"
        case "forwarddelete": return Character(UnicodeScalar(0xF728)!)
        case "up": return Character(UnicodeScalar(0xF700)!)
        case "down": return Character(UnicodeScalar(0xF701)!)
        case "left": return Character(UnicodeScalar(0xF702)!)
        case "right": return Character(UnicodeScalar(0xF703)!)
        case "home": return Character(UnicodeScalar(0xF729)!)
        case "end": return Character(UnicodeScalar(0xF72B)!)
        case "pageup": return Character(UnicodeScalar(0xF72C)!)
        case "pagedown": return Character(UnicodeScalar(0xF72D)!)
        default:
            if key.hasPrefix("f"), let n = Int(key.dropFirst()), (1...24).contains(n) {
                return Character(UnicodeScalar(0xF704 + UInt32(n - 1))!)
            }
            return key.count == 1 ? key.first : nil
        }
    }
}
