#if os(macOS)
import AppKit
import OpenGL.GL3
import Libmpv

/// CAOpenGLLayer that draws mpv through the libmpv render API (vo=libmpv),
/// the same approach IINA uses. Every frame is rendered at the layer's current
/// pixel size, so the picture follows window resizes and layout changes.
/// (The wid + MoltenVK context only reads the layer size on video reconfig,
/// which left the picture cropped/misplaced after the video area changed.)
public final class MPVOpenGLLayer: CAOpenGLLayer {
    private let glPixelFormat: CGLPixelFormatObj
    private let glContext: CGLContextObj
    private var renderContext: OpaquePointer?
    private let renderQueue = DispatchQueue(label: "mpc.mpv.render", qos: .userInteractive)
    private let lock = NSRecursiveLock()
    private var lastSize: CGSize = .zero
    private var frameReady = false

    public override init() {
        (glPixelFormat, glContext) = Self.makeGLContext()
        super.init()
        isAsynchronous = false
        isOpaque = true
        needsDisplayOnBoundsChange = true
        backgroundColor = NSColor.black.cgColor
    }

    /// Used by Core Animation for presentation copies.
    public override init(layer: Any) {
        let other = layer as! MPVOpenGLLayer
        glPixelFormat = other.glPixelFormat
        glContext = other.glContext
        super.init(layer: layer)
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    private static func makeGLContext() -> (CGLPixelFormatObj, CGLContextObj) {
        let attributes: [CGLPixelFormatAttribute] = [
            kCGLPFAOpenGLProfile, CGLPixelFormatAttribute(UInt32(kCGLOGLPVersion_3_2_Core.rawValue)),
            kCGLPFAAccelerated,
            kCGLPFADoubleBuffer,
            kCGLPFAAllowOfflineRenderers,
            CGLPixelFormatAttribute(0),
        ]
        var pix: CGLPixelFormatObj?
        var count: GLint = 0
        CGLChoosePixelFormat(attributes, &pix, &count)
        guard let pix else { fatalError("No OpenGL pixel format available") }
        var ctx: CGLContextObj?
        CGLCreateContext(pix, nil, &ctx)
        guard let ctx else { fatalError("Could not create OpenGL context") }
        var swapInterval: GLint = 1
        CGLSetParameter(ctx, kCGLCPSwapInterval, &swapInterval)
        CGLEnable(ctx, kCGLCEMPEngine)
        return (pix, ctx)
    }

    // MARK: mpv render context

    /// Creates the render context for an initialized mpv core (vo=libmpv).
    func attach(to mpv: OpaquePointer) {
        lock.lock(); defer { lock.unlock() }
        guard renderContext == nil else { return }
        CGLLockContext(glContext)
        CGLSetCurrentContext(glContext)
        defer { CGLUnlockContext(glContext) }

        var initParams = mpv_opengl_init_params(get_proc_address: { _, name in
            guard let name,
                  let bundle = CFBundleGetBundleWithIdentifier("com.apple.opengl" as CFString) else { return nil }
            let symbol = CFStringCreateWithCString(kCFAllocatorDefault, name, CFStringBuiltInEncodings.ASCII.rawValue)
            return CFBundleGetFunctionPointerForName(bundle, symbol)
        }, get_proc_address_ctx: nil)

        var rc: OpaquePointer?
        // Advanced control is required for screenshots and stats (VOCTRL_SCREENSHOT
        // runs on the render thread), and obliges us to call update() on every callback.
        var advanced: Int32 = 1
        let status = withUnsafeMutablePointer(to: &initParams) { ip in
            withUnsafeMutablePointer(to: &advanced) { ap in "opengl".withCString { api in
                var params = [
                    mpv_render_param(type: MPV_RENDER_PARAM_API_TYPE, data: UnsafeMutableRawPointer(mutating: api)),
                    mpv_render_param(type: MPV_RENDER_PARAM_OPENGL_INIT_PARAMS, data: UnsafeMutableRawPointer(ip)),
                    mpv_render_param(type: MPV_RENDER_PARAM_ADVANCED_CONTROL, data: UnsafeMutableRawPointer(ap)),
                    mpv_render_param(),
                ]
                return mpv_render_context_create(&rc, mpv, &params)
            } }
        }
        guard status >= 0, let rc else {
            NSLog("mpv_render_context_create failed: %@", String(cString: mpv_error_string(status)))
            return
        }
        renderContext = rc
        mpv_render_context_set_update_callback(rc, { ctx in
            guard let ctx else { return }
            Unmanaged<MPVOpenGLLayer>.fromOpaque(ctx).takeUnretainedValue().scheduleDisplay()
        }, Unmanaged.passUnretained(self).toOpaque())
    }

    /// Frees the render context. Must run before the mpv core is destroyed.
    func detach() {
        lock.lock(); defer { lock.unlock() }
        guard let rc = renderContext else { return }
        mpv_render_context_set_update_callback(rc, nil, nil)
        renderContext = nil
        CGLLockContext(glContext)
        CGLSetCurrentContext(glContext)
        mpv_render_context_free(rc)
        CGLUnlockContext(glContext)
    }

    /// Update callback: runs mpv's pending render-thread work (with the GL
    /// context current), then redraws if a new frame is due.
    private func scheduleDisplay() {
        renderQueue.async { [self] in
            lock.lock(); defer { lock.unlock() }
            guard let rc = renderContext else { return }
            CGLLockContext(glContext)
            CGLSetCurrentContext(glContext)
            let flags = mpv_render_context_update(rc)
            CGLUnlockContext(glContext)
            if flags & UInt64(MPV_RENDER_UPDATE_FRAME.rawValue) != 0 {
                frameReady = true
                display()
            }
        }
    }

    // MARK: CAOpenGLLayer

    public override func copyCGLPixelFormat(forDisplayMask mask: UInt32) -> CGLPixelFormatObj {
        CGLRetainPixelFormat(glPixelFormat)
    }

    public override func copyCGLContext(forPixelFormat pf: CGLPixelFormatObj) -> CGLContextObj {
        CGLRetainContext(glContext)
    }

    private var pixelSize: CGSize {
        CGSize(width: (bounds.width * contentsScale).rounded(), height: (bounds.height * contentsScale).rounded())
    }

    public override func display() {
        lock.lock(); defer { lock.unlock() }
        super.display()
        CATransaction.flush()
        if let rc = renderContext { mpv_render_context_report_swap(rc) }
    }

    public override func canDraw(inCGLContext ctx: CGLContextObj, pixelFormat pf: CGLPixelFormatObj,
                                 forLayerTime t: CFTimeInterval, displayTime ts: UnsafePointer<CVTimeStamp>?) -> Bool {
        // A size change always redraws, so the picture is re-fitted immediately.
        renderContext == nil || frameReady || pixelSize != lastSize
    }

    public override func draw(inCGLContext ctx: CGLContextObj, pixelFormat pf: CGLPixelFormatObj,
                              forLayerTime t: CFTimeInterval, displayTime ts: UnsafePointer<CVTimeStamp>?) {
        lastSize = pixelSize
        frameReady = false
        guard let rc = renderContext else {
            glClearColor(0, 0, 0, 1)
            glClear(GLbitfield(GL_COLOR_BUFFER_BIT))
            glFlush()
            return
        }
        var fbo: GLint = 0
        glGetIntegerv(GLenum(GL_DRAW_FRAMEBUFFER_BINDING), &fbo)
        var viewport = [GLint](repeating: 0, count: 4)
        glGetIntegerv(GLenum(GL_VIEWPORT), &viewport)

        var target = mpv_opengl_fbo(fbo: Int32(fbo), w: viewport[2], h: viewport[3], internal_format: 0)
        var flip: Int32 = 1
        withUnsafeMutablePointer(to: &target) { tp in
            withUnsafeMutablePointer(to: &flip) { fp in
                var params = [
                    mpv_render_param(type: MPV_RENDER_PARAM_OPENGL_FBO, data: UnsafeMutableRawPointer(tp)),
                    mpv_render_param(type: MPV_RENDER_PARAM_FLIP_Y, data: UnsafeMutableRawPointer(fp)),
                    mpv_render_param(),
                ]
                _ = mpv_render_context_render(rc, &params)
            }
        }
        glFlush()
    }
}

// Mutable state is only touched under `lock` (render queue / Core Animation).
extension MPVOpenGLLayer: @unchecked Sendable {}
#endif
