import Foundation
import CoreGraphics
import Metal
import QuartzCore
import Combine
import Libmpv

/// Works around MoltenVK forcing a 1x1 drawable to flush presentation,
/// which makes the picture flicker (mpv PR #13651, same fix as MPVKit's demo).
public final class MPVMetalLayer: CAMetalLayer {
    public override var drawableSize: CGSize {
        get { super.drawableSize }
        set {
            if Int(newValue.width) > 1 && Int(newValue.height) > 1 {
                super.drawableSize = newValue
            }
        }
    }
}

public enum EndFileReason: Sendable {
    case eof, stop, quit, error, redirect, other
}

enum MPVValue: Sendable {
    case double(Double), flag(Bool), int(Int64), string(String), none

    var double: Double? {
        switch self {
        case .double(let d): return d
        case .int(let i): return Double(i)
        default: return nil
        }
    }
    var flag: Bool? { if case .flag(let b) = self { return b }; return nil }
    var int: Int64? {
        switch self {
        case .int(let i): return i
        case .double(let d): return Int64(d)
        default: return nil
        }
    }
    var string: String? { if case .string(let s) = self { return s }; return nil }
}

enum MPVEvent: Sendable {
    case property(String, MPVValue)
    case startFile
    case fileLoaded
    case endFile(EndFileReason, String?)
    case seekDone
    case log(String)
    case shutdown
}

/// Drains the mpv event queue on a background queue and hands batches to the main thread.
final class MPVEventPump: @unchecked Sendable {
    private let handle: OpaquePointer
    private let queue = DispatchQueue(label: "mpcplayer.mpv.events", qos: .userInitiated)
    private let deliver: @Sendable ([MPVEvent]) -> Void
    private var stopped = false

    init(handle: OpaquePointer, deliver: @escaping @Sendable ([MPVEvent]) -> Void) {
        self.handle = handle
        self.deliver = deliver
    }

    func drain() {
        queue.async { [self] in
            var batch: [MPVEvent] = []
            while !stopped {
                guard let ev = mpv_wait_event(handle, 0) else { break }
                let id = ev.pointee.event_id
                if id == MPV_EVENT_NONE { break }
                switch id {
                case MPV_EVENT_PROPERTY_CHANGE:
                    if let data = ev.pointee.data {
                        let prop = data.assumingMemoryBound(to: mpv_event_property.self).pointee
                        batch.append(.property(String(cString: prop.name), Self.value(of: prop)))
                    }
                case MPV_EVENT_START_FILE:
                    batch.append(.startFile)
                case MPV_EVENT_FILE_LOADED:
                    batch.append(.fileLoaded)
                case MPV_EVENT_END_FILE:
                    var reason = EndFileReason.other
                    var message: String?
                    if let data = ev.pointee.data {
                        let end = data.assumingMemoryBound(to: mpv_event_end_file.self).pointee
                        switch end.reason {
                        case MPV_END_FILE_REASON_EOF: reason = .eof
                        case MPV_END_FILE_REASON_STOP: reason = .stop
                        case MPV_END_FILE_REASON_QUIT: reason = .quit
                        case MPV_END_FILE_REASON_ERROR:
                            reason = .error
                            message = String(cString: mpv_error_string(end.error))
                        case MPV_END_FILE_REASON_REDIRECT: reason = .redirect
                        default: break
                        }
                    }
                    batch.append(.endFile(reason, message))
                case MPV_EVENT_PLAYBACK_RESTART:
                    batch.append(.seekDone)
                case MPV_EVENT_LOG_MESSAGE:
                    if let data = ev.pointee.data {
                        let msg = data.assumingMemoryBound(to: mpv_event_log_message.self).pointee
                        let text = "[\(String(cString: msg.prefix))] \(String(cString: msg.level)): \(String(cString: msg.text))"
                        batch.append(.log(text))
                    }
                case MPV_EVENT_SHUTDOWN:
                    stopped = true
                    batch.append(.shutdown)
                default:
                    break
                }
            }
            if !batch.isEmpty {
                let deliver = self.deliver
                DispatchQueue.main.async { deliver(batch) }
            }
        }
    }

    /// Blocks until queued drains finish, then stops further draining.
    func stop() {
        queue.sync { stopped = true }
    }

    private static func value(of prop: mpv_event_property) -> MPVValue {
        guard let data = prop.data else { return .none }
        switch prop.format {
        case MPV_FORMAT_DOUBLE: return .double(data.assumingMemoryBound(to: Double.self).pointee)
        case MPV_FORMAT_FLAG: return .flag(data.assumingMemoryBound(to: Int32.self).pointee != 0)
        case MPV_FORMAT_INT64: return .int(data.assumingMemoryBound(to: Int64.self).pointee)
        case MPV_FORMAT_STRING:
            if let cstr = data.assumingMemoryBound(to: UnsafePointer<CChar>?.self).pointee {
                return .string(String(cString: cstr))
            }
            return .none
        default: return .none
        }
    }
}

/// Thin Swift wrapper around a libmpv client handle that publishes playback state.
@MainActor
public final class MPVPlayer: ObservableObject {
    @Published public private(set) var isPaused = true
    @Published public private(set) var hasMedia = false
    @Published public private(set) var isLoading = false
    @Published public private(set) var position: Double = 0
    @Published public private(set) var duration: Double = 0
    @Published public private(set) var volume: Double = 100
    @Published public private(set) var isMuted = false
    @Published public private(set) var speed: Double = 1
    @Published public private(set) var mediaTitle = ""
    @Published public private(set) var path: String?
    @Published public private(set) var tracks: [Track] = []
    @Published public private(set) var chapters: [Chapter] = []
    @Published public private(set) var abLoopA: Double?
    @Published public private(set) var abLoopB: Double?
    @Published public private(set) var isBuffering = false
    @Published public private(set) var eofReached = false
    @Published public private(set) var videoSize: CGSize = .zero
    @Published public private(set) var subDelay: Double = 0
    @Published public private(set) var audioDelay: Double = 0
    @Published public private(set) var subVisible = true
    @Published public private(set) var loopFile = false
    @Published public private(set) var videoZoom: Double = 0
    @Published public private(set) var panX: Double = 0
    @Published public private(set) var panY: Double = 0
    @Published public private(set) var rotation: Int = 0
    @Published public private(set) var aspectOverride: String = "-1"
    @Published public private(set) var lastError: String?

    public var onFileLoaded: (() -> Void)?
    public var onEndFile: ((EndFileReason) -> Void)?
    public var onEOFReached: (() -> Void)?
    public var onSeekDone: (() -> Void)?
    public var logHandler: ((String) -> Void)?

    public var isInitialized: Bool { handle != nil }
    public var audioTracks: [Track] { tracks.filter { $0.kind == .audio } }
    public var subtitleTracks: [Track] { tracks.filter { $0.kind == .sub } }
    public var videoTracks: [Track] { tracks.filter { $0.kind == .video } }

    private var handle: OpaquePointer?
    private var pump: MPVEventPump?
    private var pendingLoad: (url: URL, start: Double?, paused: Bool)?
    private var pendingOptions: [(String, String)] = []

    public init() {}

    // MARK: Lifecycle

    /// Creates the mpv core rendering into `layer` via `wid` (Vulkan/MoltenVK).
    /// Options are applied before `mpv_initialize`.
    public func setup(layer: CAMetalLayer, options: [(String, String)]) {
        start(output: [("vo", "gpu-next"), ("gpu-api", "vulkan"), ("gpu-context", "moltenvk")],
              options: options,
              preInit: { h in
                  var wid = Int64(Int(bitPattern: Unmanaged.passUnretained(layer).toOpaque()))
                  mpv_set_option(h, "wid", MPV_FORMAT_INT64, &wid)
              },
              postInit: { _ in })
    }

    #if os(macOS)
    private var renderLayer: MPVOpenGLLayer?

    /// Creates the mpv core drawing through the render API into `renderLayer`,
    /// which always renders at the layer's current size.
    public func setup(renderLayer: MPVOpenGLLayer, options: [(String, String)]) {
        start(output: [("vo", "libmpv")], options: options, preInit: { _ in }) { [weak self] h in
            renderLayer.attach(to: h)
            self?.renderLayer = renderLayer
        }
    }
    #endif

    private func start(output: [(String, String)], options: [(String, String)],
                       preInit: (OpaquePointer) -> Void, postInit: (OpaquePointer) -> Void) {
        guard handle == nil, let h = mpv_create() else { return }
        preInit(h)

        let base: [(String, String)] = output + [
            ("config", "no"),
            ("load-scripts", "no"),
            ("terminal", "no"),
            ("idle", "yes"),
            ("keep-open", "yes"),
            ("input-default-bindings", "no"),
            ("input-vo-keyboard", "no"),
            ("osc", "no"),
            ("osd-level", "0"),
            ("ytdl", "no"),
            ("audio-client-name", "MPC Player"),
            ("screenshot-high-bit-depth", "no"),
            ("subs-fallback", "yes"),
        ]
        for (k, v) in base + options + pendingOptions {
            let rc = mpv_set_option_string(h, k, v)
            if rc < 0 { log("option \(k)=\(v) failed: \(String(cString: mpv_error_string(rc)))") }
        }
        pendingOptions.removeAll()

        mpv_request_log_messages(h, "warn")
        let rc = mpv_initialize(h)
        guard rc >= 0 else {
            lastError = "mpv_initialize failed: \(String(cString: mpv_error_string(rc)))"
            mpv_terminate_destroy(h)
            return
        }
        handle = h

        let observed: [(String, mpv_format)] = [
            ("pause", MPV_FORMAT_FLAG), ("idle-active", MPV_FORMAT_FLAG),
            ("time-pos", MPV_FORMAT_DOUBLE), ("duration", MPV_FORMAT_DOUBLE),
            ("volume", MPV_FORMAT_DOUBLE), ("mute", MPV_FORMAT_FLAG), ("speed", MPV_FORMAT_DOUBLE),
            ("media-title", MPV_FORMAT_STRING), ("path", MPV_FORMAT_STRING),
            ("track-list", MPV_FORMAT_NONE), ("chapter-list", MPV_FORMAT_NONE),
            ("ab-loop-a", MPV_FORMAT_DOUBLE), ("ab-loop-b", MPV_FORMAT_DOUBLE),
            ("paused-for-cache", MPV_FORMAT_FLAG), ("eof-reached", MPV_FORMAT_FLAG),
            ("dwidth", MPV_FORMAT_INT64), ("dheight", MPV_FORMAT_INT64),
            ("sub-delay", MPV_FORMAT_DOUBLE), ("audio-delay", MPV_FORMAT_DOUBLE),
            ("sub-visibility", MPV_FORMAT_FLAG), ("loop-file", MPV_FORMAT_STRING),
            ("video-zoom", MPV_FORMAT_DOUBLE), ("video-pan-x", MPV_FORMAT_DOUBLE),
            ("video-pan-y", MPV_FORMAT_DOUBLE), ("video-rotate", MPV_FORMAT_INT64),
            ("video-aspect-override", MPV_FORMAT_STRING),
        ]
        for (name, format) in observed {
            mpv_observe_property(h, 0, name, format)
        }

        let pump = MPVEventPump(handle: h) { [weak self] events in
            MainActor.assumeIsolated { self?.handle(events) }
        }
        self.pump = pump
        mpv_set_wakeup_callback(h, { ctx in
            guard let ctx else { return }
            Unmanaged<MPVEventPump>.fromOpaque(ctx).takeUnretainedValue().drain()
        }, Unmanaged.passUnretained(pump).toOpaque())

        postInit(h)

        if let pending = pendingLoad {
            pendingLoad = nil
            load(pending.url, start: pending.start, paused: pending.paused)
        }
    }

    public func shutdown() {
        guard let h = handle else { return }
        mpv_set_wakeup_callback(h, nil, nil)
        pump?.stop()
        #if os(macOS)
        renderLayer?.detach()
        renderLayer = nil
        #endif
        handle = nil
        pump = nil
        mpv_terminate_destroy(h)
    }

    // MARK: Events

    private func handle(_ events: [MPVEvent]) {
        for event in events {
            switch event {
            case .property(let name, let value):
                apply(name, value)
            case .startFile:
                isLoading = true
                lastError = nil
            case .fileLoaded:
                isLoading = false
                hasMedia = true
                eofReached = false
                refreshTracks()
                refreshChapters()
                onFileLoaded?()
            case .endFile(let reason, let message):
                isLoading = false
                if reason == .error { lastError = message ?? "Playback error" }
                onEndFile?(reason)
            case .seekDone:
                onSeekDone?()
            case .log(let text):
                log(text)
            case .shutdown:
                handle = nil
            }
        }
    }

    private func apply(_ name: String, _ value: MPVValue) {
        switch name {
        case "pause": isPaused = value.flag ?? true
        case "idle-active":
            let idle = value.flag ?? true
            hasMedia = !idle
            if idle { position = 0; duration = 0; tracks = []; chapters = []; videoSize = .zero }
        case "time-pos":
            let t = value.double ?? 0
            // Throttle to ~10 Hz while playing so SwiftUI isn't redrawn every frame.
            if isPaused || abs(t - position) >= 0.1 || t < position { position = t }
        case "duration": duration = value.double ?? 0
        case "volume": volume = value.double ?? volume
        case "mute": isMuted = value.flag ?? false
        case "speed": speed = value.double ?? 1
        case "media-title": mediaTitle = value.string ?? ""
        case "path": path = value.string
        case "track-list": refreshTracks()
        case "chapter-list": refreshChapters()
        case "ab-loop-a": abLoopA = value.double
        case "ab-loop-b": abLoopB = value.double
        case "paused-for-cache": isBuffering = value.flag ?? false
        case "eof-reached":
            let eof = value.flag ?? false
            if eof && !eofReached {
                eofReached = true
                onEOFReached?()
            } else {
                eofReached = eof
            }
        case "dwidth": videoSize.width = CGFloat(value.int ?? 0)
        case "dheight": videoSize.height = CGFloat(value.int ?? 0)
        case "sub-delay": subDelay = value.double ?? 0
        case "audio-delay": audioDelay = value.double ?? 0
        case "sub-visibility": subVisible = value.flag ?? true
        case "loop-file": loopFile = (value.string ?? "no") != "no"
        case "video-zoom": videoZoom = value.double ?? 0
        case "video-pan-x": panX = value.double ?? 0
        case "video-pan-y": panY = value.double ?? 0
        case "video-rotate": rotation = Int(value.int ?? 0)
        case "video-aspect-override": aspectOverride = value.string ?? "-1"
        default: break
        }
    }

    private func refreshTracks() {
        let count = getInt("track-list/count") ?? 0
        var result: [Track] = []
        for i in 0..<max(0, count) {
            let p = "track-list/\(i)/"
            guard let type = getString(p + "type"), let kind = TrackKind(rawValue: type),
                  let id = getInt(p + "id") else { continue }
            result.append(Track(
                kind: kind, trackID: id,
                title: getString(p + "title"), lang: getString(p + "lang"), codec: getString(p + "codec"),
                isExternal: getFlag(p + "external"), isDefault: getFlag(p + "default"),
                isSelected: getFlag(p + "selected")))
        }
        tracks = result
    }

    private func refreshChapters() {
        let count = getInt("chapter-list/count") ?? 0
        chapters = (0..<max(0, count)).map { i in
            Chapter(index: i,
                    title: getString("chapter-list/\(i)/title") ?? "Chapter \(i + 1)",
                    time: getDouble("chapter-list/\(i)/time") ?? 0)
        }
    }

    private func log(_ text: String) {
        logHandler?(text)
        #if DEBUG
        print("mpv:", text, terminator: text.hasSuffix("\n") ? "" : "\n")
        #endif
    }

    // MARK: Low-level access

    @discardableResult
    public func command(_ args: [String]) -> Int32 {
        guard let h = handle else { return -1 }
        var cargs: [UnsafePointer<CChar>?] = args.map { UnsafePointer(strdup($0)) }
        cargs.append(nil)
        defer { for p in cargs where p != nil { free(UnsafeMutablePointer(mutating: p)) } }
        let rc = mpv_command(h, &cargs)
        if rc < 0 { log("command \(args.first ?? "") failed: \(String(cString: mpv_error_string(rc)))") }
        return rc
    }

    /// Sets an option that must exist before initialization, or a runtime property afterwards.
    public func setOption(_ name: String, _ value: String) {
        if let h = handle {
            mpv_set_property_string(h, name, value)
        } else {
            pendingOptions.append((name, value))
        }
    }

    public func setString(_ name: String, _ value: String) {
        guard let h = handle else { return }
        mpv_set_property_string(h, name, value)
    }

    public func setDouble(_ name: String, _ value: Double) {
        guard let h = handle else { return }
        var v = value
        mpv_set_property(h, name, MPV_FORMAT_DOUBLE, &v)
    }

    public func setInt(_ name: String, _ value: Int) {
        guard let h = handle else { return }
        var v = Int64(value)
        mpv_set_property(h, name, MPV_FORMAT_INT64, &v)
    }

    public func setFlag(_ name: String, _ value: Bool) {
        guard let h = handle else { return }
        var v: Int32 = value ? 1 : 0
        mpv_set_property(h, name, MPV_FORMAT_FLAG, &v)
    }

    public func getString(_ name: String) -> String? {
        guard let h = handle, let c = mpv_get_property_string(h, name) else { return nil }
        defer { mpv_free(c) }
        return String(cString: c)
    }

    public func getDouble(_ name: String) -> Double? {
        guard let h = handle else { return nil }
        var v = 0.0
        return mpv_get_property(h, name, MPV_FORMAT_DOUBLE, &v) >= 0 ? v : nil
    }

    public func getInt(_ name: String) -> Int? {
        guard let h = handle else { return nil }
        var v: Int64 = 0
        return mpv_get_property(h, name, MPV_FORMAT_INT64, &v) >= 0 ? Int(v) : nil
    }

    public func getFlag(_ name: String) -> Bool {
        guard let h = handle else { return false }
        var v: Int32 = 0
        return mpv_get_property(h, name, MPV_FORMAT_FLAG, &v) >= 0 && v != 0
    }

    // MARK: Playback

    public func load(_ url: URL, start: Double? = nil, paused: Bool = false) {
        guard handle != nil else {
            pendingLoad = (url, start, paused)
            return
        }
        let target = url.isFileURL ? url.path : url.absoluteString
        var opts = ["pause=\(paused ? "yes" : "no")"]
        if let start, start > 0 { opts.append("start=\(String(format: "%.3f", start))") }
        // loadfile <url> <flags> <index> <options>  (mpv >= 0.38)
        command(["loadfile", target, "replace", "-1", opts.joined(separator: ",")])
        isLoading = true
    }

    public func play() { setFlag("pause", false) }
    public func pause() { setFlag("pause", true) }
    public func togglePause() { isPaused ? play() : pause() }

    /// Unloads the file (mpv goes idle).
    public func unload() { command(["stop"]) }

    public enum SeekMode: String { case exact, keyframes, auto = "" }

    public func seek(to seconds: Double, mode: SeekMode = .exact) {
        let flags = mode == .auto ? "absolute" : "absolute+\(mode.rawValue)"
        command(["seek", String(format: "%.3f", max(0, seconds)), flags])
        position = max(0, seconds)
    }

    public func seek(by seconds: Double, mode: SeekMode = .exact) {
        let flags = mode == .auto ? "relative" : "relative+\(mode.rawValue)"
        command(["seek", String(format: "%.3f", seconds), flags])
    }

    public func seekPercent(_ fraction: Double) {
        command(["seek", String(format: "%.4f", min(100, max(0, fraction * 100))), "absolute-percent+exact"])
    }

    public func frameStep() { command(["frame-step"]) }
    public func frameBackStep() { command(["frame-back-step"]) }

    public func setVolume(_ v: Double) { setDouble("volume", v) }
    public func setMuted(_ m: Bool) { setFlag("mute", m) }
    public func setSpeed(_ s: Double) { setDouble("speed", s) }

    public func selectTrack(_ kind: TrackKind, id: Int?) {
        let prop: String
        switch kind {
        case .audio: prop = "aid"
        case .sub: prop = "sid"
        case .video: prop = "vid"
        }
        setString(prop, id.map(String.init) ?? "no")
        refreshTracks()
    }

    public func addSubtitle(_ url: URL) {
        command(["sub-add", url.isFileURL ? url.path : url.absoluteString, "select"])
    }

    public func setABLoop(a: Double?, b: Double?) {
        setString("ab-loop-a", a.map { String(format: "%.3f", $0) } ?? "no")
        setString("ab-loop-b", b.map { String(format: "%.3f", $0) } ?? "no")
    }

    public func setLoopFile(_ on: Bool) { setString("loop-file", on ? "inf" : "no") }

    /// Grabs the current frame through `screenshot-raw` (no FFmpeg image encoder
    /// needed) and returns it as a CGImage; encoding is left to ImageIO.
    public func screenshotImage(withSubtitles: Bool) -> CGImage? {
        guard let h = handle else { return nil }
        let args = ["screenshot-raw", withSubtitles ? "subtitles" : "video"]
        var cargs: [UnsafePointer<CChar>?] = args.map { UnsafePointer(strdup($0)) }
        cargs.append(nil)
        defer { for p in cargs where p != nil { free(UnsafeMutablePointer(mutating: p)) } }
        var result = mpv_node()
        guard mpv_command_ret(h, &cargs, &result) >= 0 else { return nil }
        defer { mpv_free_node_contents(&result) }
        guard result.format == MPV_FORMAT_NODE_MAP, let list = result.u.list?.pointee else { return nil }

        var w = 0, ht = 0, stride = 0
        var format = ""
        var bytes: UnsafeMutableRawPointer?
        var size = 0
        for i in 0..<Int(list.num) {
            guard let keyPtr = list.keys?[i] else { continue }
            let key = String(cString: keyPtr)
            let node = list.values[i]
            switch key {
            case "w": w = Int(node.u.int64)
            case "h": ht = Int(node.u.int64)
            case "stride": stride = Int(node.u.int64)
            case "format": if let c = node.u.string { format = String(cString: c) }
            case "data":
                if node.format == MPV_FORMAT_BYTE_ARRAY, let ba = node.u.ba?.pointee {
                    bytes = ba.data
                    size = ba.size
                }
            default: break
            }
        }
        guard w > 0, ht > 0, stride > 0, let bytes, size >= stride * ht, format == "bgr0" || format == "bgra" else { return nil }
        let data = Data(bytes: bytes, count: stride * ht) as CFData
        guard let provider = CGDataProvider(data: data) else { return nil }
        let alpha: CGImageAlphaInfo = format == "bgra" ? .premultipliedFirst : .noneSkipFirst
        return CGImage(width: w, height: ht, bitsPerComponent: 8, bitsPerPixel: 32, bytesPerRow: stride,
                       space: CGColorSpace(name: CGColorSpace.sRGB)!,
                       bitmapInfo: CGBitmapInfo(rawValue: alpha.rawValue | CGBitmapInfo.byteOrder32Little.rawValue),
                       provider: provider, decode: nil, shouldInterpolate: false, intent: .defaultIntent)
    }

    public func applyFrameMode(_ mode: VideoFrameMode) {
        setString("keepaspect", mode == .stretch ? "no" : "yes")
        setString("video-unscaled", mode == .original ? "yes" : "no")
        switch mode {
        case .fill: setDouble("panscan", 1.0)
        case .zoom1: setDouble("panscan", 0.33)
        case .zoom2: setDouble("panscan", 0.66)
        default: setDouble("panscan", 0)
        }
    }

    /// Codec/format details for the Statistics panel and Properties.
    public func statistics() -> [(String, String)] {
        guard handle != nil, hasMedia else { return [] }
        var rows: [(String, String)] = []
        if let codec = getString("video-codec") {
            let w = getInt("video-params/w") ?? 0, h = getInt("video-params/h") ?? 0
            let fps = getDouble("estimated-vf-fps") ?? getDouble("container-fps") ?? 0
            rows.append(("Video", "\(codec)  \(w)×\(h)  \(String(format: "%.3f", fps)) fps"))
            if let hw = getString("hwdec-current"), hw != "no" { rows.append(("Decoder", "HW (\(hw))")) }
            else { rows.append(("Decoder", "Software")) }
        }
        if let a = getString("audio-codec-name") {
            let rate = getInt("audio-params/samplerate") ?? 0
            let ch = getInt("audio-params/channel-count") ?? 0
            rows.append(("Audio", "\(a)  \(rate) Hz  \(ch) ch"))
        }
        let vb = getDouble("video-bitrate") ?? 0, ab = getDouble("audio-bitrate") ?? 0
        if vb + ab > 0 { rows.append(("Bitrate", String(format: "V %.0f kb/s  A %.0f kb/s", vb / 1000, ab / 1000))) }
        if let drops = getInt("frame-drop-count") { rows.append(("Dropped", "\(drops) frames")) }
        if let fmt = getString("file-format") { rows.append(("Container", fmt)) }
        if let size = getInt("file-size") {
            rows.append(("File size", ByteCountFormatter.string(fromByteCount: Int64(size), countStyle: .file)))
        }
        return rows
    }
}
