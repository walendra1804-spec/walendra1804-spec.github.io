import Foundation

/// Remembers playback positions ("Remember file position" in MPC-BE) and the
/// recent-files list. Positions are keyed by file name + size so they survive
/// the path changes iOS makes when files are copied into the app inbox.
@MainActor
public final class PlaybackHistory {
    private let defaults: UserDefaults
    private let positionsKey = "MPCPlayer.Positions.v1"
    private let recentKey = "MPCPlayer.Recent.v1"
    private let maxPositions = 500
    public let maxRecent = 20

    public init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
    }

    public static func key(for url: URL) -> String {
        guard url.isFileURL else { return url.absoluteString }
        let size = (try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
        return "\(url.lastPathComponent)|\(size)"
    }

    public func position(for url: URL) -> Double? {
        let all = defaults.dictionary(forKey: positionsKey) as? [String: [String: Double]] ?? [:]
        return all[Self.key(for: url)]?["pos"]
    }

    public func setPosition(_ position: Double?, for url: URL) {
        var all = defaults.dictionary(forKey: positionsKey) as? [String: [String: Double]] ?? [:]
        let key = Self.key(for: url)
        if let position {
            all[key] = ["pos": position, "t": Date().timeIntervalSince1970]
        } else {
            all.removeValue(forKey: key)
        }
        if all.count > maxPositions {
            let oldest = all.sorted { ($0.value["t"] ?? 0) < ($1.value["t"] ?? 0) }.prefix(all.count - maxPositions)
            for (k, _) in oldest { all.removeValue(forKey: k) }
        }
        defaults.set(all, forKey: positionsKey)
    }

    // MARK: Recent files (stored as bookmarks so iOS security scope survives relaunch)

    public func recentURLs() -> [URL] {
        let items = defaults.array(forKey: recentKey) as? [Data] ?? []
        return items.compactMap { data in
            var stale = false
            return try? URL(resolvingBookmarkData: data, options: Self.bookmarkResolveOptions, bookmarkDataIsStale: &stale)
        }
    }

    public func addRecent(_ url: URL) {
        guard let data = try? url.bookmarkData(options: Self.bookmarkCreateOptions, includingResourceValuesForKeys: nil, relativeTo: nil) else { return }
        var items = defaults.array(forKey: recentKey) as? [Data] ?? []
        let existing = recentURLs()
        if let idx = existing.firstIndex(where: { $0.standardizedFileURL == url.standardizedFileURL }), idx < items.count {
            items.remove(at: idx)
        }
        items.insert(data, at: 0)
        defaults.set(Array(items.prefix(maxRecent)), forKey: recentKey)
    }

    public func clearRecent() { defaults.removeObject(forKey: recentKey) }

    #if os(macOS)
    private static let bookmarkCreateOptions: URL.BookmarkCreationOptions = []
    private static let bookmarkResolveOptions: URL.BookmarkResolutionOptions = [.withoutUI]
    #else
    private static let bookmarkCreateOptions: URL.BookmarkCreationOptions = []
    private static let bookmarkResolveOptions: URL.BookmarkResolutionOptions = []
    #endif
}

public enum MediaFiles {
    public static let videoExtensions: Set<String> = [
        "mp4", "m4v", "mov", "mkv", "webm", "avi", "flv", "wmv", "asf", "ts", "m2ts", "mts", "mpg", "mpeg",
        "vob", "3gp", "3g2", "ogv", "rm", "rmvb", "divx", "f4v", "mxf", "hevc", "h264", "264", "265", "y4m",
    ]
    public static let audioExtensions: Set<String> = [
        "mp3", "flac", "m4a", "aac", "ogg", "oga", "opus", "wav", "wma", "ape", "dts", "ac3", "eac3", "mka", "alac", "aiff", "tta", "wv",
    ]
    public static let subtitleExtensions: Set<String> = ["srt", "ass", "ssa", "sub", "idx", "vtt", "sup", "smi", "txt"]

    public static func isMedia(_ url: URL) -> Bool {
        let ext = url.pathExtension.lowercased()
        return videoExtensions.contains(ext) || audioExtensions.contains(ext)
    }

    public static func isSubtitle(_ url: URL) -> Bool {
        subtitleExtensions.contains(url.pathExtension.lowercased()) && url.pathExtension.lowercased() != "txt"
    }

    /// Media files in the same folder, sorted the way Finder/Explorer sorts names.
    public static func siblings(of url: URL) -> [URL] {
        guard url.isFileURL else { return [url] }
        let dir = url.deletingLastPathComponent()
        guard let items = try? FileManager.default.contentsOfDirectory(
            at: dir, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles]) else { return [url] }
        let media = items.filter(isMedia).sorted {
            $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending
        }
        return media.isEmpty ? [url] : media
    }
}
