import Foundation

/// Every action a hotkey, menu item, toolbar button or gesture can trigger.
/// Defaults follow MPC-BE's `CAppSettings::CreateCommands()` table, with
/// Ctrl mapped to ⌘ except where that clashes with standard macOS shortcuts.
public enum PlayerCommand: String, CaseIterable, Codable, Identifiable, Sendable {
    // File
    case openFile, openURL, loadSubtitle, reopen, closeFile, saveImage, autoSaveImage
    // Playback
    case playPause, stop, frameStep, frameStepBack, goTo
    case speedUp, speedDown, speedReset
    case jumpForwardSmall, jumpBackwardSmall, jumpForwardMedium, jumpBackwardMedium
    case jumpForwardLarge, jumpBackwardLarge, jumpForwardKeyframe, jumpBackwardKeyframe
    case seekBegin, next, previous, nextFile, previousFile
    case abMarkA, abMarkB, abClear, loopFile
    case audioDelayPlus, audioDelayMinus
    // View
    case fullscreen, fullscreenAlt, toggleSeekBar, toggleControls, toggleInfo, toggleStats
    case toggleStatus, togglePlaylist, presetMinimal, presetCompact, presetNormal
    case alwaysOnTop, options, remainingTime, osdFileName, osdLocalTime
    // Video
    case zoom50, zoom100, zoom200, zoomAutoFit, aspectNext, frameModeNext
    case panScanIncrease, panScanDecrease, panScanReset
    case panLeft, panRight, panUp, panDown, rotateCW, rotateCCW
    case brightnessUp, brightnessDown, contrastUp, contrastDown
    case saturationUp, saturationDown, colorReset
    // Audio
    case volumeUp, volumeDown, mute, audioNext, audioPrevious
    // Subtitles
    case subtitleNext, subtitlePrevious, subtitleToggle, subDelayDecrease, subDelayIncrease
    case subPositionUp, subPositionDown, subSizeIncrease, subSizeDecrease
    case subtitlePrevLine, subtitleNextLine
    // Misc
    case bossKey

    public var id: String { rawValue }

    public enum Category: String, CaseIterable, Identifiable, Sendable {
        case file = "File", playback = "Playback", navigate = "Navigate", view = "View"
        case video = "Video", audio = "Audio", subtitles = "Subtitles", misc = "Misc"
        public var id: String { rawValue }
    }

    public var category: Category {
        switch self {
        case .openFile, .openURL, .loadSubtitle, .reopen, .closeFile, .saveImage, .autoSaveImage:
            return .file
        case .playPause, .stop, .frameStep, .frameStepBack, .speedUp, .speedDown, .speedReset,
             .abMarkA, .abMarkB, .abClear, .loopFile, .audioDelayPlus, .audioDelayMinus:
            return .playback
        case .goTo, .jumpForwardSmall, .jumpBackwardSmall, .jumpForwardMedium, .jumpBackwardMedium,
             .jumpForwardLarge, .jumpBackwardLarge, .jumpForwardKeyframe, .jumpBackwardKeyframe,
             .seekBegin, .next, .previous, .nextFile, .previousFile:
            return .navigate
        case .fullscreen, .fullscreenAlt, .toggleSeekBar, .toggleControls, .toggleInfo, .toggleStats,
             .toggleStatus, .togglePlaylist, .presetMinimal, .presetCompact, .presetNormal,
             .alwaysOnTop, .options, .remainingTime, .osdFileName, .osdLocalTime:
            return .view
        case .zoom50, .zoom100, .zoom200, .zoomAutoFit, .aspectNext, .frameModeNext,
             .panScanIncrease, .panScanDecrease, .panScanReset, .panLeft, .panRight, .panUp, .panDown,
             .rotateCW, .rotateCCW, .brightnessUp, .brightnessDown, .contrastUp, .contrastDown,
             .saturationUp, .saturationDown, .colorReset:
            return .video
        case .volumeUp, .volumeDown, .mute, .audioNext, .audioPrevious:
            return .audio
        case .subtitleNext, .subtitlePrevious, .subtitleToggle, .subDelayDecrease, .subDelayIncrease,
             .subPositionUp, .subPositionDown, .subSizeIncrease, .subSizeDecrease,
             .subtitlePrevLine, .subtitleNextLine:
            return .subtitles
        case .bossKey:
            return .misc
        }
    }

    public var title: String {
        switch self {
        case .openFile: return "Open File..."
        case .openURL: return "Open URL..."
        case .loadSubtitle: return "Load Subtitle..."
        case .reopen: return "Reopen File"
        case .closeFile: return "Close"
        case .saveImage: return "Save Image..."
        case .autoSaveImage: return "Save Image (auto)"
        case .playPause: return "Play/Pause"
        case .stop: return "Stop"
        case .frameStep: return "Frame Step"
        case .frameStepBack: return "Frame Step Back"
        case .goTo: return "Go To..."
        case .speedUp: return "Increase Rate"
        case .speedDown: return "Decrease Rate"
        case .speedReset: return "Reset Rate"
        case .jumpForwardSmall: return "Jump Forward (small)"
        case .jumpBackwardSmall: return "Jump Backward (small)"
        case .jumpForwardMedium: return "Jump Forward (medium)"
        case .jumpBackwardMedium: return "Jump Backward (medium)"
        case .jumpForwardLarge: return "Jump Forward (large)"
        case .jumpBackwardLarge: return "Jump Backward (large)"
        case .jumpForwardKeyframe: return "Jump Forward (keyframe)"
        case .jumpBackwardKeyframe: return "Jump Backward (keyframe)"
        case .seekBegin: return "Seek to Beginning"
        case .next: return "Next"
        case .previous: return "Previous"
        case .nextFile: return "Next File"
        case .previousFile: return "Previous File"
        case .abMarkA: return "A-B Repeat: Set A"
        case .abMarkB: return "A-B Repeat: Set B"
        case .abClear: return "A-B Repeat: Clear"
        case .loopFile: return "Repeat File"
        case .audioDelayPlus: return "Audio Delay +10 ms"
        case .audioDelayMinus: return "Audio Delay -10 ms"
        case .fullscreen: return "Fullscreen"
        case .fullscreenAlt: return "Fullscreen (alt)"
        case .toggleSeekBar: return "Toggle Seek Bar"
        case .toggleControls: return "Toggle Controls"
        case .toggleInfo: return "Toggle Information"
        case .toggleStats: return "Toggle Statistics"
        case .toggleStatus: return "Toggle Status"
        case .togglePlaylist: return "Toggle Playlist"
        case .presetMinimal: return "View Minimal"
        case .presetCompact: return "View Compact"
        case .presetNormal: return "View Normal"
        case .alwaysOnTop: return "Always On Top"
        case .options: return "Options..."
        case .remainingTime: return "Toggle Remaining Time"
        case .osdFileName: return "OSD: Show File Name"
        case .osdLocalTime: return "OSD: Show Local Time"
        case .zoom50: return "Zoom 50%"
        case .zoom100: return "Zoom 100%"
        case .zoom200: return "Zoom 200%"
        case .zoomAutoFit: return "Zoom Auto Fit"
        case .aspectNext: return "Next Aspect Ratio"
        case .frameModeNext: return "Switch Video Frame Mode"
        case .panScanIncrease: return "Pan&Scan: Increase Size"
        case .panScanDecrease: return "Pan&Scan: Decrease Size"
        case .panScanReset: return "Pan&Scan: Reset"
        case .panLeft: return "Pan&Scan: Move Left"
        case .panRight: return "Pan&Scan: Move Right"
        case .panUp: return "Pan&Scan: Move Up"
        case .panDown: return "Pan&Scan: Move Down"
        case .rotateCW: return "Rotate Clockwise"
        case .rotateCCW: return "Rotate Counterclockwise"
        case .brightnessUp: return "Brightness +"
        case .brightnessDown: return "Brightness -"
        case .contrastUp: return "Contrast +"
        case .contrastDown: return "Contrast -"
        case .saturationUp: return "Saturation +"
        case .saturationDown: return "Saturation -"
        case .colorReset: return "Reset Color Controls"
        case .volumeUp: return "Volume Up"
        case .volumeDown: return "Volume Down"
        case .mute: return "Mute"
        case .audioNext: return "Next Audio Track"
        case .audioPrevious: return "Previous Audio Track"
        case .subtitleNext: return "Next Subtitle"
        case .subtitlePrevious: return "Previous Subtitle"
        case .subtitleToggle: return "Subtitles On/Off"
        case .subDelayDecrease: return "Subtitle Delay -"
        case .subDelayIncrease: return "Subtitle Delay +"
        case .subPositionUp: return "Subtitle Position Up"
        case .subPositionDown: return "Subtitle Position Down"
        case .subSizeIncrease: return "Subtitle Size +"
        case .subSizeDecrease: return "Subtitle Size -"
        case .subtitlePrevLine: return "Go To Previous Subtitle"
        case .subtitleNextLine: return "Go To Next Subtitle"
        case .bossKey: return "Boss Key"
        }
    }

    public var defaultBindings: [KeyBinding] {
        switch self {
        case .openFile: return [KeyBinding("o", .command)]
        case .openURL: return [KeyBinding("u", .command)]
        case .loadSubtitle: return [KeyBinding("l", .command)]
        case .reopen: return [KeyBinding("e", .command)]
        case .closeFile: return [KeyBinding("w", .command)]
        case .saveImage: return [KeyBinding("f5", .command)]
        case .autoSaveImage: return [KeyBinding("f5")]
        case .playPause: return [KeyBinding("space")]
        case .stop: return [KeyBinding(".")]
        case .frameStep: return [KeyBinding("right", .command)]
        case .frameStepBack: return [KeyBinding("left", .command)]
        case .goTo: return [KeyBinding("g", .command)]
        case .speedUp: return [KeyBinding("up", .command)]
        case .speedDown: return [KeyBinding("down", .command)]
        case .speedReset: return [KeyBinding("r", .command)]
        case .jumpForwardMedium: return [KeyBinding("right")]
        case .jumpBackwardMedium: return [KeyBinding("left")]
        case .jumpForwardKeyframe: return [KeyBinding("right", .shift)]
        case .jumpBackwardKeyframe: return [KeyBinding("left", .shift)]
        case .seekBegin: return [KeyBinding("home")]
        case .next: return [KeyBinding("pagedown")]
        case .previous: return [KeyBinding("pageup")]
        case .nextFile: return [KeyBinding("pagedown", .command)]
        case .previousFile: return [KeyBinding("pageup", .command)]
        case .abMarkA: return [KeyBinding("[")]
        case .abMarkB: return [KeyBinding("]")]
        case .abClear: return [KeyBinding("\\")]
        case .audioDelayPlus: return [KeyBinding("=")]
        case .audioDelayMinus: return [KeyBinding("-")]
        case .fullscreen: return [KeyBinding("return", .command), KeyBinding("f", [.command, .control])]
        case .fullscreenAlt: return [KeyBinding("return", .option)]
        case .toggleSeekBar: return [KeyBinding("1", .command)]
        case .toggleControls: return [KeyBinding("2", .command)]
        case .toggleInfo: return [KeyBinding("3", .command)]
        case .toggleStats: return [KeyBinding("4", .command)]
        case .toggleStatus: return [KeyBinding("5", .command)]
        case .togglePlaylist: return [KeyBinding("7", .command)]
        case .presetMinimal: return [KeyBinding("1")]
        case .presetCompact: return [KeyBinding("2")]
        case .presetNormal: return [KeyBinding("3")]
        case .alwaysOnTop: return [KeyBinding("a", .command)]
        case .options: return [KeyBinding("o"), KeyBinding(",", .command)]
        case .remainingTime: return [KeyBinding("i", .command)]
        case .osdFileName: return [KeyBinding("i", .shift)]
        case .osdLocalTime: return [KeyBinding("i", .option)]
        case .zoom50: return [KeyBinding("1", .option)]
        case .zoom100: return [KeyBinding("2", .option)]
        case .zoom200: return [KeyBinding("3", .option)]
        case .zoomAutoFit: return [KeyBinding("4", .option)]
        case .frameModeNext: return [KeyBinding("p")]
        case .panScanIncrease: return [KeyBinding("=", .option)]
        case .panScanDecrease: return [KeyBinding("-", .option)]
        case .panScanReset: return [KeyBinding("0", .option)]
        case .panLeft: return [KeyBinding("left", [.option, .command])]
        case .panRight: return [KeyBinding("right", [.option, .command])]
        case .panUp: return [KeyBinding("up", [.option, .command])]
        case .panDown: return [KeyBinding("down", [.option, .command])]
        case .rotateCW: return [KeyBinding("]", .option)]
        case .rotateCCW: return [KeyBinding("[", .option)]
        case .volumeUp: return [KeyBinding("up")]
        case .volumeDown: return [KeyBinding("down")]
        case .mute: return [KeyBinding("m")]
        case .audioNext: return [KeyBinding("a")]
        case .audioPrevious: return [KeyBinding("a", .shift)]
        case .subtitleNext: return [KeyBinding("s")]
        case .subtitlePrevious: return [KeyBinding("s", .shift)]
        case .subtitleToggle: return [KeyBinding("w")]
        case .subDelayDecrease: return [KeyBinding("f1")]
        case .subDelayIncrease: return [KeyBinding("f2")]
        case .subPositionUp: return [KeyBinding("up", [.command, .shift])]
        case .subPositionDown: return [KeyBinding("down", [.command, .shift])]
        case .subtitlePrevLine: return [KeyBinding("y")]
        case .subtitleNextLine: return [KeyBinding("u")]
        case .bossKey: return [KeyBinding("b")]
        default: return []
        }
    }
}

/// Resolves effective bindings (user overrides on top of the defaults).
public struct KeyMap: Sendable {
    public let bindings: [PlayerCommand: [KeyBinding]]
    private let lookup: [KeyBinding: PlayerCommand]

    public init(overrides: [String: [KeyBinding]]) {
        var b: [PlayerCommand: [KeyBinding]] = [:]
        var l: [KeyBinding: PlayerCommand] = [:]
        for cmd in PlayerCommand.allCases {
            let keys = overrides[cmd.rawValue] ?? cmd.defaultBindings
            b[cmd] = keys
            for k in keys where l[k] == nil { l[k] = cmd }
        }
        bindings = b
        lookup = l
    }

    public func command(for binding: KeyBinding) -> PlayerCommand? { lookup[binding] }
    public func keys(for command: PlayerCommand) -> [KeyBinding] { bindings[command] ?? [] }

    /// Bindings assigned to more than one command.
    public var conflicts: Set<KeyBinding> {
        var seen: [KeyBinding: Int] = [:]
        for keys in bindings.values { for k in keys { seen[k, default: 0] += 1 } }
        return Set(seen.filter { $0.value > 1 }.keys)
    }
}
