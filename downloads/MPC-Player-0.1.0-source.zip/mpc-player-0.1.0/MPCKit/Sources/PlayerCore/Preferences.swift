import Foundation
import Combine

public enum ThemePreset: String, Codable, CaseIterable, Identifiable, Sendable {
    case mpcbeDark = "MPC-BE Dark"
    case classic = "Classic (Light)"
    case midnight = "Midnight Blue"
    case amoled = "AMOLED Black"
    case custom = "Custom"
    public var id: String { rawValue }

    /// panel, panelText, accent, seekTrack, videoBackground
    public var palette: (panel: String, text: String, accent: String, track: String, video: String)? {
        switch self {
        case .mpcbeDark: return ("#202020", "#D4D4D4", "#3E8DE6", "#101010", "#000000")
        case .classic:   return ("#ECECEC", "#1A1A1A", "#2F7FDB", "#FFFFFF", "#000000")
        case .midnight:  return ("#141B2D", "#C9D3E8", "#F2A33A", "#0A0F1C", "#05070D")
        case .amoled:    return ("#000000", "#BDBDBD", "#18C964", "#111111", "#000000")
        case .custom:    return nil
        }
    }
}

public enum LoopMode: String, Codable, CaseIterable, Identifiable, Sendable {
    case none = "Off", file = "Repeat File", playlist = "Repeat Playlist"
    public var id: String { rawValue }
}

public enum AfterPlayback: String, Codable, CaseIterable, Identifiable, Sendable {
    case playNext = "Play next file", stop = "Do nothing", close = "Close file", quit = "Exit player"
    public var id: String { rawValue }
}

public enum OSDPosition: String, Codable, CaseIterable, Identifiable, Sendable {
    case topLeft = "Top Left", topRight = "Top Right", topCenter = "Top Center", bottomCenter = "Bottom Center"
    public var id: String { rawValue }
}

public enum SnapshotFormat: String, Codable, CaseIterable, Identifiable, Sendable {
    case png, jpg, heic
    public var id: String { rawValue }
}

/// MPC-BE "Video Frame" modes.
public enum VideoFrameMode: String, Codable, CaseIterable, Identifiable, Sendable {
    case fit = "Touch Window From Inside"
    case fill = "Touch Window From Outside"
    case stretch = "Stretch To Window"
    case zoom1 = "Zoom 1"
    case zoom2 = "Zoom 2"
    case original = "Normal Size (1:1)"
    public var id: String { rawValue }
}

public struct Preferences: Codable, Equatable, Sendable {
    // Interface / theme
    public var themePreset: ThemePreset = .mpcbeDark
    public var panelHex = "#202020"
    public var panelTextHex = "#D4D4D4"
    public var accentHex = "#3E8DE6"
    public var seekTrackHex = "#101010"
    public var videoBackgroundHex = "#000000"
    public var showSeekBar = true
    public var showControls = true
    public var showStatus = true
    public var showInfo = false
    public var showStats = false
    public var showPlaylist = false
    public var toolbarIconSize: Double = 15
    public var seekBarHeight: Double = 16
    public var showRemainingTime = false
    public var showLogo = true
    public var alwaysOnTop = false
    public var hideControlsInFullscreen = true

    // Player
    public var rememberPosition = true
    public var rememberVolume = true
    public var autoLoadFolder = true
    public var afterPlayback: AfterPlayback = .playNext
    public var loopMode: LoopMode = .none
    public var openPaused = false
    public var autoZoomWindow = true
    public var singleClickPlayPause = true
    public var doubleClickFullscreen = true
    public var scrollWheelVolume = true

    // Playback
    public var jumpSmallMs = 1000
    public var jumpMediumMs = 5000
    public var jumpLargeMs = 20000
    public var fastSeek = false
    public var volumeStep = 5
    public var maxVolume = 130
    public var volume: Double = 100
    public var speedStep: Double = 0.25
    public var audioDelayStepMs = 10
    public var preferredAudioLangs = ""

    // Video
    public var hardwareDecoding = true
    public var defaultFrameMode: VideoFrameMode = .fit
    public var deband = false
    public var interpolation = false

    // OSD
    public var osdEnabled = true
    public var osdFontSize: Double = 20
    public var osdDurationMs = 1500
    public var osdTextHex = "#FFFFFF"
    public var osdPosition: OSDPosition = .topLeft
    public var osdShowSeek = true
    public var osdShowVolume = true

    // Subtitles
    public var subAutoLoad = true
    public var preferredSubLangs = "ind,id,eng,en"
    public var subFontSize: Double = 46
    public var subTextHex = "#FFFFFF"
    public var subBorderHex = "#000000"
    public var subBorderSize: Double = 2.5
    public var subFont = ""
    public var subOverrideASS = false
    public var subDelayStepMs = 500

    // Snapshot
    public var snapshotFormat: SnapshotFormat = .png
    public var snapshotFolder = ""
    public var snapshotWithSubtitles = true

    // Touch (iOS / iPadOS)
    public var gestureSeek = true
    public var gestureVolume = true
    public var gestureBrightness = true
    public var doubleTapSeekSeconds = 10
    public var gestureSensitivity: Double = 1.0
    public var pinchToZoom = true
    public var controlsAutoHideSeconds: Double = 4

    // Keys: PlayerCommand.rawValue -> bindings (only commands the user changed)
    public var keyBindings: [String: [KeyBinding]] = [:]

    public init() {}

    public var keyMap: KeyMap { KeyMap(overrides: keyBindings) }

    public mutating func apply(preset: ThemePreset) {
        themePreset = preset
        guard let p = preset.palette else { return }
        panelHex = p.panel
        panelTextHex = p.text
        accentHex = p.accent
        seekTrackHex = p.track
        videoBackgroundHex = p.video
    }

    /// Decodes stored JSON on top of the defaults so new fields added in later
    /// versions keep their default values instead of failing to decode.
    public static func decodeMerged(from data: Data) -> Preferences {
        guard
            let stored = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
            let defaultsData = try? JSONEncoder().encode(Preferences()),
            var merged = try? JSONSerialization.jsonObject(with: defaultsData) as? [String: Any]
        else { return Preferences() }
        merged.merge(stored) { _, new in new }
        guard let mergedData = try? JSONSerialization.data(withJSONObject: merged),
              let prefs = try? JSONDecoder().decode(Preferences.self, from: mergedData)
        else { return Preferences() }
        return prefs
    }
}

@MainActor
public final class PreferencesStore: ObservableObject {
    private static let key = "MPCPlayer.Preferences.v1"
    private let defaults: UserDefaults

    @Published public var prefs: Preferences {
        didSet { if prefs != oldValue { save() } }
    }

    public init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        if let data = defaults.data(forKey: Self.key) {
            prefs = Preferences.decodeMerged(from: data)
        } else {
            prefs = Preferences()
        }
    }

    public func reset() { prefs = Preferences() }

    private func save() {
        if let data = try? JSONEncoder().encode(prefs) {
            defaults.set(data, forKey: Self.key)
        }
    }
}
