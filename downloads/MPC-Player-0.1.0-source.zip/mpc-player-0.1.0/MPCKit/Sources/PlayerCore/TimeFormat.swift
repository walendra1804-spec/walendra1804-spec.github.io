import Foundation

public enum TimeFormat {
    /// MPC-BE style "HH:MM:SS" (hours always shown, like the status bar).
    public static func clock(_ seconds: Double, alwaysHours: Bool = true) -> String {
        guard seconds.isFinite, seconds >= 0 else { return alwaysHours ? "00:00:00" : "00:00" }
        let total = Int(seconds.rounded(.down))
        let h = total / 3600, m = (total % 3600) / 60, s = total % 60
        if alwaysHours || h > 0 {
            return String(format: "%02d:%02d:%02d", h, m, s)
        }
        return String(format: "%02d:%02d", m, s)
    }

    /// Clock with milliseconds, used by frame-step OSD and the "Go To" dialog.
    public static func precise(_ seconds: Double) -> String {
        guard seconds.isFinite, seconds >= 0 else { return "00:00:00.000" }
        let ms = Int((seconds * 1000).rounded())
        return String(format: "%02d:%02d:%02d.%03d", ms / 3_600_000, (ms / 60_000) % 60, (ms / 1000) % 60, ms % 1000)
    }

    /// Parses "SS", "MM:SS", "HH:MM:SS" and optional ".mmm".
    public static func parse(_ text: String) -> Double? {
        let parts = text.trimmingCharacters(in: .whitespaces).split(separator: ":").map(String.init)
        guard !parts.isEmpty, parts.count <= 3 else { return nil }
        var total = 0.0
        for part in parts {
            guard let v = Double(part), v >= 0 else { return nil }
            total = total * 60 + v
        }
        return total
    }
}
