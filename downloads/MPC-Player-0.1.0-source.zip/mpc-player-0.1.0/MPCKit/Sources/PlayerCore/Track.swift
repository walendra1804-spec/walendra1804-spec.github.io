import Foundation

public enum TrackKind: String, Codable, Sendable {
    case video, audio, sub
}

public struct Track: Identifiable, Hashable, Sendable {
    public let kind: TrackKind
    public let trackID: Int
    public let title: String?
    public let lang: String?
    public let codec: String?
    public let isExternal: Bool
    public let isDefault: Bool
    public var isSelected: Bool

    public var id: String { "\(kind.rawValue)-\(trackID)" }

    /// Menu label in the MPC-BE style: "English [eng] (ass)".
    public var displayName: String {
        var parts: [String] = []
        if let title, !title.isEmpty { parts.append(title) }
        if let lang, !lang.isEmpty { parts.append("[\(lang)]") }
        if let codec, !codec.isEmpty { parts.append("(\(codec))") }
        if isExternal { parts.append("– external") }
        return parts.isEmpty ? "Track \(trackID)" : parts.joined(separator: " ")
    }
}

public struct Chapter: Identifiable, Hashable, Sendable {
    public let index: Int
    public let title: String
    public let time: Double
    public var id: Int { index }
}
