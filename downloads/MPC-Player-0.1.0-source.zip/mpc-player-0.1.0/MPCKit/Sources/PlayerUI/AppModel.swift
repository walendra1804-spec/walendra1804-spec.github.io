import SwiftUI
import Combine
import ImageIO
import UniformTypeIdentifiers
import PlayerCore

public struct PlaylistItem: Identifiable, Hashable {
    public let id = UUID()
    public let url: URL
    public var title: String { url.isFileURL ? url.lastPathComponent : url.absoluteString }
}

public struct OSDMessage: Equatable {
    public let id = UUID()
    public let text: String
}

public enum PromptKind: String, Identifiable {
    case openURL, goTo
    public var id: String { rawValue }
}

/// Platform shells (macOS window / iOS scene) plug their native behaviour in here.
public struct PlatformHooks {
    public var openFiles: () -> Void = {}
    public var openSubtitle: () -> Void = {}
    public var toggleFullscreen: () -> Void = {}
    public var openOptions: () -> Void = {}
    public var bossKey: () -> Void = {}
    public var setAlwaysOnTop: (Bool) -> Void = { _ in }
    /// nil = auto-fit the window to the video.
    public var setWindowScale: (Double?) -> Void = { _ in }
    public var saveImageAs: (_ suggestedName: String) -> Void = { _ in }
    public var quit: () -> Void = {}
    public var defaultSnapshotFolder: () -> URL = {
        FileManager.default.urls(for: .picturesDirectory, in: .userDomainMask).first!
            .appendingPathComponent("MPC Player", isDirectory: true)
    }
    public init() {}
}

/// Central command dispatcher shared by the macOS and iOS front ends.
@MainActor
public final class AppModel: ObservableObject {
    public let player = MPVPlayer()
    public let store: PreferencesStore
    public let history = PlaybackHistory()
    public let videoView = VideoView(frame: .zero)
    public var platform = PlatformHooks()

    @Published public var playlist: [PlaylistItem] = []
    @Published public var currentIndex: Int?
    @Published public private(set) var osd: OSDMessage?
    @Published public var isStopped = false
    @Published public var isFullscreen = false
    @Published public var frameMode: VideoFrameMode
    @Published public var prompt: PromptKind?
    @Published public var showOptions = false
    @Published public var showFileImporter = false
    @Published public var showSubtitleImporter = false
    @Published public var showPlaylistSheet = false

    private var cancellables: Set<AnyCancellable> = []
    private var scopedURLs: Set<URL> = []
    private var lastAppliedPrefs: Preferences?
    private var pendingResumeOSD: Double?

    public static let speedSteps: [Double] = [0.25, 0.5, 0.75, 1, 1.25, 1.5, 1.75, 2, 3, 4, 8]
    public static let aspectPresets: [(value: String, title: String)] = [
        ("-1", "Default"), ("4:3", "4:3"), ("5:4", "5:4"), ("16:9", "16:9"), ("16:10", "16:10"),
        ("1.85:1", "1.85:1"), ("2.35:1", "2.35:1"), ("2.39:1", "2.39:1"),
    ]

    public init(store: PreferencesStore? = nil) {
        let store = store ?? PreferencesStore()
        self.store = store
        self.frameMode = store.prefs.defaultFrameMode

        player.onFileLoaded = { [weak self] in self?.fileLoaded() }
        player.onEOFReached = { [weak self] in self?.endOfFile() }
        player.onEndFile = { [weak self] reason in
            if reason == .error, let self { self.showOSD("Cannot play: \(self.player.lastError ?? "unknown error")") }
        }

        store.$prefs
            .receive(on: RunLoop.main)
            .sink { [weak self] prefs in self?.applyRuntime(prefs) }
            .store(in: &cancellables)
    }

    public var prefs: Preferences { store.prefs }
    public var theme: Theme { Theme(store.prefs) }
    public var keyMap: KeyMap { store.prefs.keyMap }

    public var currentURL: URL? {
        guard let i = currentIndex, playlist.indices.contains(i) else { return nil }
        return playlist[i].url
    }

    public var windowTitle: String {
        guard player.hasMedia || player.isLoading else { return "MPC Player" }
        let name = player.mediaTitle.isEmpty ? (currentURL?.lastPathComponent ?? "") : player.mediaTitle
        return name.isEmpty ? "MPC Player" : name
    }

    public var statusText: String {
        if player.isLoading { return "Opening..." }
        if !player.hasMedia {
            if let err = player.lastError { return "Error: \(err)" }
            return currentURL == nil ? "" : "Closed"
        }
        var s: String
        if isStopped { s = "Stopped" }
        else if player.isBuffering { s = "Buffering..." }
        else { s = player.isPaused ? "Paused" : "Playing" }
        if abs(player.speed - 1) > 0.001 { s += String(format: " [%gx]", player.speed) }
        if player.abLoopA != nil || player.abLoopB != nil { s += " [A-B]" }
        if player.loopFile { s += " [Repeat]" }
        return s
    }

    // MARK: mpv options

    /// Options that must be set before mpv initializes.
    public func initialMPVOptions() -> [(String, String)] {
        var opts = runtimeOptions(prefs)
        opts.append(("volume", String(Int(prefs.rememberVolume ? prefs.volume : 100))))
        return opts
    }

    private func runtimeOptions(_ p: Preferences) -> [(String, String)] {
        var o: [(String, String)] = [
            ("hwdec", p.hardwareDecoding ? "videotoolbox" : "no"),
            ("volume-max", String(p.maxVolume)),
            ("sub-auto", p.subAutoLoad ? "fuzzy" : "no"),
            ("slang", p.preferredSubLangs),
            ("alang", p.preferredAudioLangs),
            ("sub-font-size", String(Int(p.subFontSize))),
            ("sub-color", p.subTextHex),
            ("sub-border-color", p.subBorderHex),
            ("sub-border-size", String(format: "%.1f", p.subBorderSize)),
            ("sub-ass-override", p.subOverrideASS ? "force" : "scale"),
            ("deband", p.deband ? "yes" : "no"),
            ("background-color", p.videoBackgroundHex),
        ]
        if !p.subFont.isEmpty { o.append(("sub-font", p.subFont)) }
        if p.interpolation {
            o.append(("video-sync", "display-resample"))
            o.append(("interpolation", "yes"))
        } else {
            o.append(("interpolation", "no"))
        }
        return o
    }

    func markRuntimeApplied() { lastAppliedPrefs = prefs }

    private func applyRuntime(_ p: Preferences) {
        defer { lastAppliedPrefs = p }
        guard player.isInitialized else { return }
        let old = lastAppliedPrefs.map(runtimeOptions) ?? []
        for (k, v) in runtimeOptions(p) where !old.contains(where: { $0.0 == k && $0.1 == v }) {
            player.setOption(k, v)
        }
        if lastAppliedPrefs?.alwaysOnTop != p.alwaysOnTop { platform.setAlwaysOnTop(p.alwaysOnTop) }
    }

    // MARK: Opening

    public func open(urls: [URL], append: Bool = false) {
        let subs = urls.filter(MediaFiles.isSubtitle)
        let media = urls.filter { !MediaFiles.isSubtitle($0) }
        for url in urls { startAccess(url) }

        if media.isEmpty {
            if player.hasMedia { subs.forEach(loadSubtitle) }
            return
        }
        if append {
            playlist.append(contentsOf: media.map { PlaylistItem(url: $0) })
            if currentIndex == nil { play(at: playlist.count - media.count) }
        } else {
            saveCurrentPosition()
            var list = media
            var start = 0
            if media.count == 1, prefs.autoLoadFolder, media[0].isFileURL {
                let siblings = MediaFiles.siblings(of: media[0])
                if siblings.count > 1, let idx = siblings.firstIndex(where: { $0.standardizedFileURL == media[0].standardizedFileURL }) {
                    list = siblings
                    start = idx
                }
            }
            playlist = list.map { PlaylistItem(url: $0) }
            play(at: start)
        }
        subs.forEach(loadSubtitle)
    }

    public func open(urlString: String) {
        let trimmed = urlString.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        let url = URL(string: trimmed) ?? URL(fileURLWithPath: trimmed)
        open(urls: [url])
    }

    public func play(at index: Int) {
        guard playlist.indices.contains(index) else { return }
        if index != currentIndex { saveCurrentPosition() }
        currentIndex = index
        let url = playlist[index].url
        var resume: Double?
        if prefs.rememberPosition, let pos = history.position(for: url) { resume = pos }
        pendingResumeOSD = resume
        isStopped = false
        player.load(url, start: resume, paused: prefs.openPaused)
        history.addRecent(url)
    }

    public func loadSubtitle(_ url: URL) {
        startAccess(url)
        player.addSubtitle(url)
        showOSD("Subtitle loaded: \(url.lastPathComponent)")
    }

    public func removeFromPlaylist(_ offsets: IndexSet) {
        let removingCurrent = currentIndex.map { offsets.contains($0) } ?? false
        playlist.remove(atOffsets: offsets)
        if removingCurrent {
            currentIndex = nil
        } else if let cur = currentIndex {
            currentIndex = cur - offsets.filter { $0 < cur }.count
        }
    }

    public func movePlaylist(from: IndexSet, to: Int) {
        let currentID = currentIndex.map { playlist[$0].id }
        playlist.move(fromOffsets: from, toOffset: to)
        if let currentID { currentIndex = playlist.firstIndex { $0.id == currentID } }
    }

    private func startAccess(_ url: URL) {
        guard url.isFileURL, !scopedURLs.contains(url) else { return }
        if url.startAccessingSecurityScopedResource() { scopedURLs.insert(url) }
    }

    // MARK: Player callbacks

    private func fileLoaded() {
        player.applyFrameMode(frameMode)
        if prefs.loopMode == .file { player.setLoopFile(true) }
        if let resume = pendingResumeOSD, resume > 0 {
            showOSD("Resumed at \(TimeFormat.clock(resume))")
        } else {
            showOSD(windowTitle)
        }
        pendingResumeOSD = nil
        if prefs.autoZoomWindow && !isFullscreen && player.videoSize.width > 0 {
            platform.setWindowScale(nil)
        }
    }

    private func endOfFile() {
        if let url = currentURL { history.setPosition(nil, for: url) }
        guard let idx = currentIndex else { return }
        if prefs.afterPlayback == .playNext && idx + 1 < playlist.count {
            play(at: idx + 1)
        } else if prefs.loopMode == .playlist && !playlist.isEmpty {
            play(at: (idx + 1) % playlist.count)
        } else {
            switch prefs.afterPlayback {
            case .close: closeFile()
            case .quit: platform.quit()
            default: break
            }
        }
    }

    public func saveCurrentPosition() {
        guard prefs.rememberPosition, let url = currentURL, player.hasMedia, player.duration > 0 else { return }
        let pos = player.position
        if pos > 5 && pos < player.duration - 5 {
            history.setPosition(pos, for: url)
        } else {
            history.setPosition(nil, for: url)
        }
    }

    /// Call when the app is about to quit or go to background.
    public func persistState() {
        saveCurrentPosition()
        if prefs.rememberVolume && player.isInitialized {
            store.prefs.volume = player.volume
        }
    }

    public func closeFile() {
        saveCurrentPosition()
        player.unload()
        currentIndex = nil
        isStopped = false
    }

    // MARK: OSD

    public func showOSD(_ text: String) {
        guard prefs.osdEnabled else { return }
        let msg = OSDMessage(text: text)
        osd = msg
        let delay = UInt64(max(300, prefs.osdDurationMs)) * 1_000_000
        Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: delay)
            if self?.osd?.id == msg.id { self?.osd = nil }
        }
    }

    private func positionOSD(_ prefix: String? = nil) {
        guard prefs.osdShowSeek else { return }
        let t = "\(TimeFormat.clock(player.position)) / \(TimeFormat.clock(player.duration))"
        showOSD(prefix.map { "\($0)  \(t)" } ?? t)
    }

    // MARK: Command dispatch

    public func perform(_ command: PlayerCommand) {
        let p = prefs
        switch command {
        // File
        case .openFile: platform.openFiles()
        case .openURL: prompt = .openURL
        case .loadSubtitle: platform.openSubtitle()
        case .reopen:
            if let i = currentIndex {
                saveCurrentPosition()
                play(at: i)
            }
        case .closeFile: closeFile()
        case .saveImage:
            guard player.hasMedia else { return }
            platform.saveImageAs(snapshotFileName())
        case .autoSaveImage: autoSaveImage()

        // Playback
        case .playPause:
            guard player.hasMedia else {
                if currentIndex == nil { platform.openFiles() } else if let i = currentIndex { play(at: i) }
                return
            }
            if isStopped { isStopped = false; player.play() } else { player.togglePause() }
        case .stop:
            guard player.hasMedia else { return }
            player.pause()
            player.seek(to: 0)
            isStopped = true
        case .frameStep:
            guard player.hasMedia else { return }
            player.frameStep()
            isStopped = false
            showOSD("Frame step  \(TimeFormat.precise(player.position))")
        case .frameStepBack:
            guard player.hasMedia else { return }
            player.frameBackStep()
            showOSD("Frame step back  \(TimeFormat.precise(player.position))")
        case .goTo: if player.hasMedia { prompt = .goTo }
        case .speedUp: changeSpeed(up: true)
        case .speedDown: changeSpeed(up: false)
        case .speedReset:
            player.setSpeed(1)
            showOSD("Speed: 1x")
        case .jumpForwardSmall: jump(Double(p.jumpSmallMs) / 1000)
        case .jumpBackwardSmall: jump(-Double(p.jumpSmallMs) / 1000)
        case .jumpForwardMedium: jump(Double(p.jumpMediumMs) / 1000)
        case .jumpBackwardMedium: jump(-Double(p.jumpMediumMs) / 1000)
        case .jumpForwardLarge: jump(Double(p.jumpLargeMs) / 1000)
        case .jumpBackwardLarge: jump(-Double(p.jumpLargeMs) / 1000)
        case .jumpForwardKeyframe: jump(Double(p.jumpMediumMs) / 1000, mode: .keyframes)
        case .jumpBackwardKeyframe: jump(-Double(p.jumpMediumMs) / 1000, mode: .keyframes)
        case .seekBegin:
            guard player.hasMedia else { return }
            player.seek(to: 0)
            positionOSD()
        case .next: navigate(forward: true, chaptersFirst: true)
        case .previous: navigate(forward: false, chaptersFirst: true)
        case .nextFile: navigate(forward: true, chaptersFirst: false)
        case .previousFile: navigate(forward: false, chaptersFirst: false)
        case .abMarkA:
            guard player.hasMedia else { return }
            player.setABLoop(a: player.position, b: player.abLoopB)
            showOSD("A-B Repeat: A = \(TimeFormat.precise(player.position))")
        case .abMarkB:
            guard player.hasMedia else { return }
            player.setABLoop(a: player.abLoopA ?? 0, b: player.position)
            showOSD("A-B Repeat: B = \(TimeFormat.precise(player.position))")
        case .abClear:
            player.setABLoop(a: nil, b: nil)
            showOSD("A-B Repeat: off")
        case .loopFile:
            player.setLoopFile(!player.loopFile)
            showOSD(player.loopFile ? "Repeat: off" : "Repeat: file")
        case .audioDelayPlus: adjustAudioDelay(+1)
        case .audioDelayMinus: adjustAudioDelay(-1)

        // View
        case .fullscreen, .fullscreenAlt: platform.toggleFullscreen()
        case .toggleSeekBar: store.prefs.showSeekBar.toggle()
        case .toggleControls: store.prefs.showControls.toggle()
        case .toggleInfo: store.prefs.showInfo.toggle()
        case .toggleStats: store.prefs.showStats.toggle()
        case .toggleStatus: store.prefs.showStatus.toggle()
        case .togglePlaylist:
            #if os(iOS)
            showPlaylistSheet.toggle()
            #else
            store.prefs.showPlaylist.toggle()
            #endif
        case .presetMinimal:
            setPanels(seek: false, controls: false, status: false)
        case .presetCompact:
            setPanels(seek: true, controls: true, status: false)
        case .presetNormal:
            setPanels(seek: true, controls: true, status: true)
        case .alwaysOnTop:
            store.prefs.alwaysOnTop.toggle()
            showOSD("Always on top: \(store.prefs.alwaysOnTop ? "on" : "off")")
        case .options: platform.openOptions()
        case .remainingTime:
            store.prefs.showRemainingTime.toggle()
            if player.hasMedia {
                showOSD("Remaining: -\(TimeFormat.clock(max(0, player.duration - player.position)))")
            }
        case .osdFileName: showOSD(currentURL?.lastPathComponent ?? windowTitle)
        case .osdLocalTime:
            let f = DateFormatter()
            f.timeStyle = .medium
            showOSD(f.string(from: Date()))

        // Video
        case .zoom50: platform.setWindowScale(0.5)
        case .zoom100: platform.setWindowScale(1)
        case .zoom200: platform.setWindowScale(2)
        case .zoomAutoFit: platform.setWindowScale(nil)
        case .aspectNext:
            let presets = Self.aspectPresets
            let idx = presets.firstIndex { $0.value == player.aspectOverride } ?? 0
            let next = presets[(idx + 1) % presets.count]
            setAspect(next.value)
        case .frameModeNext:
            let all = VideoFrameMode.allCases
            let idx = all.firstIndex(of: frameMode) ?? 0
            setFrameMode(all[(idx + 1) % all.count])
        case .panScanIncrease: adjust("video-zoom", by: 0.05, current: player.videoZoom, label: "Zoom")
        case .panScanDecrease: adjust("video-zoom", by: -0.05, current: player.videoZoom, label: "Zoom")
        case .panScanReset:
            player.setDouble("video-zoom", 0)
            player.setDouble("video-pan-x", 0)
            player.setDouble("video-pan-y", 0)
            showOSD("Pan&Scan: reset")
        case .panLeft: adjust("video-pan-x", by: -0.02, current: player.panX, label: "Pan X")
        case .panRight: adjust("video-pan-x", by: 0.02, current: player.panX, label: "Pan X")
        case .panUp: adjust("video-pan-y", by: -0.02, current: player.panY, label: "Pan Y")
        case .panDown: adjust("video-pan-y", by: 0.02, current: player.panY, label: "Pan Y")
        case .rotateCW: rotate(by: 90)
        case .rotateCCW: rotate(by: -90)
        case .brightnessUp: adjustColor("brightness", 2)
        case .brightnessDown: adjustColor("brightness", -2)
        case .contrastUp: adjustColor("contrast", 2)
        case .contrastDown: adjustColor("contrast", -2)
        case .saturationUp: adjustColor("saturation", 2)
        case .saturationDown: adjustColor("saturation", -2)
        case .colorReset:
            for name in ["brightness", "contrast", "saturation", "gamma", "hue"] { player.setInt(name, 0) }
            showOSD("Color controls reset")

        // Audio
        case .volumeUp: setVolume(player.volume + Double(p.volumeStep))
        case .volumeDown: setVolume(player.volume - Double(p.volumeStep))
        case .mute:
            player.setMuted(!player.isMuted)
            if p.osdShowVolume { showOSD(player.isMuted ? "Volume: \(Int(player.volume))%" : "Mute") }
        case .audioNext: cycleTrack(.audio, forward: true)
        case .audioPrevious: cycleTrack(.audio, forward: false)

        // Subtitles
        case .subtitleNext: cycleTrack(.sub, forward: true)
        case .subtitlePrevious: cycleTrack(.sub, forward: false)
        case .subtitleToggle:
            player.setFlag("sub-visibility", !player.subVisible)
            showOSD(player.subVisible ? "Subtitles: off" : "Subtitles: on")
        case .subDelayDecrease: adjustSubDelay(-1)
        case .subDelayIncrease: adjustSubDelay(+1)
        case .subPositionUp:
            player.command(["add", "sub-pos", "-1"])
            showOSD("Subtitle position: \(player.getInt("sub-pos") ?? 100)%")
        case .subPositionDown:
            player.command(["add", "sub-pos", "1"])
            showOSD("Subtitle position: \(player.getInt("sub-pos") ?? 100)%")
        case .subSizeIncrease:
            player.command(["add", "sub-scale", "0.1"])
            showOSD(String(format: "Subtitle size: %.0f%%", (player.getDouble("sub-scale") ?? 1) * 100))
        case .subSizeDecrease:
            player.command(["add", "sub-scale", "-0.1"])
            showOSD(String(format: "Subtitle size: %.0f%%", (player.getDouble("sub-scale") ?? 1) * 100))
        case .subtitlePrevLine: player.command(["sub-seek", "-1"])
        case .subtitleNextLine: player.command(["sub-seek", "1"])

        case .bossKey:
            player.pause()
            platform.bossKey()
        }
    }

    // MARK: Command helpers

    public func seek(toFraction f: Double) {
        guard player.duration > 0 else { return }
        player.seek(to: f * player.duration, mode: prefs.fastSeek ? .keyframes : .exact)
        isStopped = false
    }

    public func jump(_ seconds: Double, mode: MPVPlayer.SeekMode? = nil) {
        guard player.hasMedia else { return }
        player.seek(by: seconds, mode: mode ?? (prefs.fastSeek ? .keyframes : .exact))
        isStopped = false
        let target = min(max(0, player.position + seconds), player.duration)
        if prefs.osdShowSeek {
            showOSD("\(TimeFormat.clock(target)) / \(TimeFormat.clock(player.duration))")
        }
    }

    public func setVolume(_ v: Double) {
        let clamped = min(Double(prefs.maxVolume), max(0, v.rounded()))
        player.setVolume(clamped)
        if player.isMuted { player.setMuted(false) }
        if prefs.rememberVolume { store.prefs.volume = clamped }
        if prefs.osdShowVolume { showOSD("Volume: \(Int(clamped))%") }
    }

    public func setSpeed(_ s: Double) {
        let clamped = min(8, max(0.1, s))
        player.setSpeed(clamped)
        showOSD(String(format: "Speed: %gx", clamped))
    }

    private func changeSpeed(up: Bool) {
        let cur = player.speed
        if prefs.speedStep <= 0 {
            let steps = Self.speedSteps
            let next = up ? steps.first { $0 > cur + 0.001 } : steps.last { $0 < cur - 0.001 }
            setSpeed(next ?? cur)
        } else {
            let v = ((cur + (up ? prefs.speedStep : -prefs.speedStep)) * 100).rounded() / 100
            setSpeed(v)
        }
    }

    public func setFrameMode(_ mode: VideoFrameMode) {
        frameMode = mode
        player.applyFrameMode(mode)
        showOSD(mode.rawValue)
    }

    public func setAspect(_ value: String) {
        player.setString("video-aspect-override", value)
        let title = Self.aspectPresets.first { $0.value == value }?.title ?? value
        showOSD("Aspect Ratio: \(title)")
    }

    private func setPanels(seek: Bool, controls: Bool, status: Bool) {
        store.prefs.showSeekBar = seek
        store.prefs.showControls = controls
        store.prefs.showStatus = status
    }

    private func navigate(forward: Bool, chaptersFirst: Bool) {
        if chaptersFirst, player.chapters.count > 1, player.hasMedia {
            let cur = player.getInt("chapter") ?? 0
            let target = cur + (forward ? 1 : -1)
            if target >= 0 && target < player.chapters.count {
                player.setInt("chapter", target)
                showOSD("Chapter: \(player.chapters[target].title)")
                return
            }
        }
        guard let idx = currentIndex, !playlist.isEmpty else { return }
        var target = idx + (forward ? 1 : -1)
        if prefs.loopMode == .playlist { target = (target + playlist.count) % playlist.count }
        if playlist.indices.contains(target) { play(at: target) }
    }

    private func cycleTrack(_ kind: TrackKind, forward: Bool) {
        let list = player.tracks.filter { $0.kind == kind }
        guard !list.isEmpty else {
            showOSD(kind == .audio ? "No audio tracks" : "No subtitles")
            return
        }
        // Subtitles include an "off" slot, as in MPC-BE.
        var slots: [Track?] = list
        if kind == .sub { slots.insert(nil, at: 0) }
        let cur = slots.firstIndex { $0?.isSelected ?? !list.contains { $0.isSelected } } ?? 0
        let next = slots[(cur + (forward ? 1 : slots.count - 1)) % slots.count]
        player.selectTrack(kind, id: next?.trackID)
        let label = kind == .audio ? "Audio" : "Subtitle"
        showOSD("\(label): \(next?.displayName ?? "off")")
    }

    public func selectTrack(_ track: Track?, kind: TrackKind) {
        player.selectTrack(kind, id: track?.trackID)
        showOSD("\(kind == .audio ? "Audio" : "Subtitle"): \(track?.displayName ?? "off")")
    }

    private func adjustSubDelay(_ sign: Double) {
        let v = player.subDelay + sign * Double(prefs.subDelayStepMs) / 1000
        player.setDouble("sub-delay", v)
        showOSD(String(format: "Subtitle delay: %.0f ms", v * 1000))
    }

    private func adjustAudioDelay(_ sign: Double) {
        let v = player.audioDelay + sign * Double(prefs.audioDelayStepMs) / 1000
        player.setDouble("audio-delay", v)
        showOSD(String(format: "Audio delay: %.0f ms", v * 1000))
    }

    private func adjust(_ prop: String, by delta: Double, current: Double, label: String) {
        let v = current + delta
        player.setDouble(prop, v)
        showOSD(String(format: "%@: %.2f", label, v))
    }

    private func rotate(by deg: Int) {
        let v = ((player.rotation + deg) % 360 + 360) % 360
        player.setInt("video-rotate", v)
        showOSD("Rotation: \(v)°")
    }

    private func adjustColor(_ prop: String, _ delta: Int) {
        let v = min(100, max(-100, (player.getInt(prop) ?? 0) + delta))
        player.setInt(prop, v)
        showOSD("\(prop.capitalized): \(v)")
    }

    // MARK: Snapshots

    public func snapshotFileName() -> String {
        let base = currentURL?.deletingPathExtension().lastPathComponent ?? "snapshot"
        let pos = TimeFormat.clock(player.position).replacingOccurrences(of: ":", with: ".")
        let f = DateFormatter()
        f.dateFormat = "yyyy.MM.dd_HH.mm.ss"
        return "\(base)_snapshot_\(pos)_[\(f.string(from: Date()))].\(prefs.snapshotFormat.rawValue)"
    }

    public var snapshotFolder: URL {
        prefs.snapshotFolder.isEmpty
            ? platform.defaultSnapshotFolder()
            : URL(fileURLWithPath: (prefs.snapshotFolder as NSString).expandingTildeInPath, isDirectory: true)
    }

    public func autoSaveImage() {
        guard player.hasMedia else { return }
        let folder = snapshotFolder
        try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        saveImage(to: folder.appendingPathComponent(snapshotFileName()))
    }

    public func saveImage(to url: URL) {
        if let image = player.screenshotImage(withSubtitles: prefs.snapshotWithSubtitles),
           Self.write(image, to: url) {
            showOSD("Image saved: \(url.lastPathComponent)")
        } else {
            showOSD("Could not save image")
        }
    }

    static func write(_ image: CGImage, to url: URL) -> Bool {
        let type: UTType
        switch url.pathExtension.lowercased() {
        case "jpg", "jpeg": type = .jpeg
        case "heic": type = .heic
        default: type = .png
        }
        guard let dest = CGImageDestinationCreateWithURL(url as CFURL, type.identifier as CFString, 1, nil) else { return false }
        CGImageDestinationAddImage(dest, image, [kCGImageDestinationLossyCompressionQuality: 0.92] as CFDictionary)
        return CGImageDestinationFinalize(dest)
    }
}
