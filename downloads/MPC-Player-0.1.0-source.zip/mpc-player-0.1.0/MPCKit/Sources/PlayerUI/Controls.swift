import SwiftUI
import PlayerCore

// MARK: - Seek bar

/// MPC-BE style seek bar: a sunken channel, accent fill, rectangular thumb,
/// chapter ticks, A-B markers and a time tooltip on hover.
public struct SeekBar: View {
    @EnvironmentObject private var model: AppModel
    @EnvironmentObject private var player: MPVPlayer
    @Environment(\.mpcTheme) private var theme
    @State private var dragFraction: Double?
    @State private var hoverX: CGFloat?
    @State private var lastLiveSeek = Date.distantPast
    var touchHeight: CGFloat?

    public init(touchHeight: CGFloat? = nil) { self.touchHeight = touchHeight }

    private let inset: CGFloat = 4

    public var body: some View {
        GeometryReader { geo in
            let usable = max(1, geo.size.width - inset * 2)
            let fraction = dragFraction ?? (player.duration > 0 ? min(1, player.position / player.duration) : 0)
            let channelH = max(4, geo.size.height * 0.45)
            ZStack(alignment: .leading) {
                // channel
                RoundedRectangle(cornerRadius: 2)
                    .fill(theme.track)
                    .overlay(RoundedRectangle(cornerRadius: 2).stroke(theme.separator, lineWidth: 1))
                    .frame(width: usable, height: channelH)
                    .offset(x: inset)
                // A-B range
                if let a = player.abLoopA, player.duration > 0 {
                    let b = player.abLoopB ?? player.duration
                    Rectangle()
                        .fill(Color.yellow.opacity(0.35))
                        .frame(width: max(2, usable * CGFloat((b - a) / player.duration)), height: channelH)
                        .offset(x: inset + usable * CGFloat(a / player.duration))
                }
                // progress fill
                RoundedRectangle(cornerRadius: 2)
                    .fill(LinearGradient(colors: [theme.accent.opacity(0.85), theme.accent], startPoint: .top, endPoint: .bottom))
                    .frame(width: usable * CGFloat(fraction), height: channelH)
                    .offset(x: inset)
                // chapter ticks
                if player.duration > 0 {
                    ForEach(player.chapters.dropFirst()) { ch in
                        Rectangle()
                            .fill(theme.panelText.opacity(0.7))
                            .frame(width: 1, height: channelH + 4)
                            .offset(x: inset + usable * CGFloat(ch.time / player.duration))
                    }
                }
                // thumb
                if player.hasMedia {
                    RoundedRectangle(cornerRadius: 2)
                        .fill(LinearGradient(colors: [theme.panelText, theme.panelText.opacity(0.75)], startPoint: .top, endPoint: .bottom))
                        .overlay(RoundedRectangle(cornerRadius: 2).stroke(Color.black.opacity(0.4), lineWidth: 0.5))
                        .frame(width: touchHeight == nil ? 8 : 14, height: geo.size.height - 2)
                        .offset(x: inset + usable * CGFloat(fraction) - (touchHeight == nil ? 4 : 7))
                }
            }
            .frame(maxHeight: .infinity)
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { v in
                        guard player.duration > 0 else { return }
                        let f = Double(min(max(0, (v.location.x - inset) / usable), 1))
                        dragFraction = f
                        // Live seek while dragging (keyframe-fast), throttled.
                        if Date().timeIntervalSince(lastLiveSeek) > 0.08 {
                            lastLiveSeek = Date()
                            player.seek(to: f * player.duration, mode: .keyframes)
                        }
                    }
                    .onEnded { v in
                        guard player.duration > 0 else { dragFraction = nil; return }
                        let f = Double(min(max(0, (v.location.x - inset) / usable), 1))
                        model.seek(toFraction: f)
                        dragFraction = nil
                    }
            )
            #if os(macOS)
            .onContinuousHover { phase in
                switch phase {
                case .active(let p): hoverX = p.x
                case .ended: hoverX = nil
                }
            }
            .overlay(alignment: .topLeading) {
                if let x = hoverX ?? (dragFraction.map { inset + usable * CGFloat($0) }), player.duration > 0 {
                    let t = Double(min(max(0, (x - inset) / usable), 1)) * player.duration
                    Text(TimeFormat.clock(t))
                        .font(.system(size: 11).monospacedDigit())
                        .padding(.horizontal, 5).padding(.vertical, 2)
                        .background(RoundedRectangle(cornerRadius: 3).fill(Color.black.opacity(0.85)))
                        .foregroundStyle(.white)
                        .fixedSize()
                        .offset(x: min(max(0, x - 28), geo.size.width - 60), y: -22)
                        .allowsHitTesting(false)
                }
            }
            #endif
        }
        .frame(height: touchHeight ?? theme.seekBarHeight)
        .padding(.vertical, touchHeight == nil ? 3 : 0)
        .accessibilityLabel("Seek bar")
        .accessibilityValue(TimeFormat.clock(player.position))
    }
}

// MARK: - Volume wedge

/// The classic Media Player Classic triangular volume control.
public struct VolumeWedge: View {
    @EnvironmentObject private var model: AppModel
    @EnvironmentObject private var player: MPVPlayer
    @Environment(\.mpcTheme) private var theme
    var width: CGFloat = 64
    var height: CGFloat = 16

    public init(width: CGFloat = 64, height: CGFloat = 16) {
        self.width = width
        self.height = height
    }

    public var body: some View {
        let frac = CGFloat(min(1, max(0, player.volume / 100)))
        ZStack(alignment: .leading) {
            Wedge().fill(theme.track)
            Wedge().fill(player.isMuted ? theme.dimText : theme.accent)
                .mask(alignment: .leading) { Rectangle().frame(width: width * frac) }
            Wedge().stroke(theme.separator, lineWidth: 1)
        }
        .frame(width: width, height: height)
        .contentShape(Rectangle())
        .gesture(DragGesture(minimumDistance: 0).onChanged { v in
            let f = min(max(0, v.location.x / width), 1)
            model.setVolume(Double(f * 100))
        })
        .help("Volume: \(Int(player.volume))%")
        .accessibilityLabel("Volume")
        .accessibilityValue("\(Int(player.volume)) percent")
    }

    struct Wedge: Shape {
        func path(in r: CGRect) -> Path {
            var p = Path()
            p.move(to: CGPoint(x: r.minX, y: r.maxY))
            p.addLine(to: CGPoint(x: r.maxX, y: r.maxY))
            p.addLine(to: CGPoint(x: r.maxX, y: r.minY))
            p.closeSubpath()
            return p
        }
    }
}

// MARK: - Toolbar

struct ToolbarButtonStyle: ButtonStyle {
    let theme: Theme
    var active = false
    @State private var hovering = false

    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .foregroundStyle(active ? theme.accent : theme.panelText)
            .frame(width: theme.iconSize + 12, height: theme.iconSize + 10)
            .background(
                RoundedRectangle(cornerRadius: 3)
                    .fill(configuration.isPressed ? theme.hover.opacity(2) : (hovering ? theme.hover : .clear))
            )
            .contentShape(Rectangle())
            #if os(macOS)
            .onHover { hovering = $0 }
            #endif
    }
}

struct ToolButton: View {
    @EnvironmentObject private var model: AppModel
    @Environment(\.mpcTheme) private var theme
    let symbol: String
    let command: PlayerCommand
    var active = false

    var body: some View {
        Button { model.perform(command) } label: {
            Image(systemName: symbol).font(.system(size: theme.iconSize * 0.85, weight: .medium))
        }
        .buttonStyle(ToolbarButtonStyle(theme: theme, active: active))
        .help(helpText)
        .accessibilityLabel(command.title)
    }

    private var helpText: String {
        let keys = model.keyMap.keys(for: command).map(\.displayString)
        return keys.isEmpty ? command.title : "\(command.title)  (\(keys.joined(separator: ", ")))"
    }
}

struct ToolSeparator: View {
    @Environment(\.mpcTheme) private var theme
    var body: some View {
        Rectangle().fill(theme.separator).frame(width: 1, height: theme.iconSize + 4).padding(.horizontal, 3)
    }
}

/// Audio / subtitle track pickers shared by the toolbar, context menus and iOS.
struct TrackMenuContent: View {
    @EnvironmentObject private var model: AppModel
    @EnvironmentObject private var player: MPVPlayer
    let kind: TrackKind

    var body: some View {
        let list = player.tracks.filter { $0.kind == kind }
        if kind == .sub {
            Button { model.selectTrack(nil, kind: .sub) } label: {
                checkLabel("Off", checked: !list.contains { $0.isSelected })
            }
        }
        ForEach(list) { t in
            Button { model.selectTrack(t, kind: kind) } label: { checkLabel(t.displayName, checked: t.isSelected) }
        }
        if list.isEmpty && kind == .audio { Text("No audio tracks") }
        if kind == .sub {
            Divider()
            Button("Load Subtitle...") { model.perform(.loadSubtitle) }
            Button(player.subVisible ? "Hide Subtitles" : "Show Subtitles") { model.perform(.subtitleToggle) }
        }
    }
}

func checkLabel(_ title: String, checked: Bool) -> some View {
    HStack {
        if checked { Image(systemName: "checkmark") }
        Text(title)
    }
}

/// The MPC-BE main toolbar row.
public struct ControlBar: View {
    @EnvironmentObject private var model: AppModel
    @EnvironmentObject private var player: MPVPlayer
    @Environment(\.mpcTheme) private var theme

    public init() {}

    public var body: some View {
        HStack(spacing: 1) {
            ToolButton(symbol: "play.fill", command: .playPause, active: player.hasMedia && !player.isPaused && !model.isStopped)
            ToolButton(symbol: "pause.fill", command: .playPause, active: player.hasMedia && player.isPaused && !model.isStopped)
            ToolButton(symbol: "stop.fill", command: .stop, active: model.isStopped)
            ToolSeparator()
            ToolButton(symbol: "backward.end.fill", command: .previous)
            ToolButton(symbol: "backward.fill", command: .speedDown)
            ToolButton(symbol: "forward.fill", command: .speedUp)
            ToolButton(symbol: "forward.end.fill", command: .next)
            ToolSeparator()
            ToolButton(symbol: "forward.frame.fill", command: .frameStep)
            ToolSeparator()
            trackMenu(kind: .audio, symbol: "waveform")
            trackMenu(kind: .sub, symbol: "captions.bubble")
            Spacer(minLength: 8)
            Button { model.perform(.mute) } label: {
                Image(systemName: player.isMuted ? "speaker.slash.fill" : "speaker.wave.2.fill")
                    .font(.system(size: theme.iconSize * 0.8))
            }
            .buttonStyle(ToolbarButtonStyle(theme: theme, active: player.isMuted))
            .help("Mute")
            VolumeWedge()
                .padding(.trailing, 6)
        }
        .padding(.horizontal, 4)
        .padding(.vertical, 2)
    }

    private func trackMenu(kind: TrackKind, symbol: String) -> some View {
        Menu {
            TrackMenuContent(kind: kind)
        } label: {
            Image(systemName: symbol).font(.system(size: theme.iconSize * 0.8))
                .foregroundStyle(theme.panelText)
        }
        #if os(macOS)
        .menuStyle(.borderlessButton)
        .menuIndicator(.hidden)
        #endif
        .frame(width: theme.iconSize + 14)
        .help(kind == .audio ? "Audio track" : "Subtitles")
    }
}

// MARK: - Status / info / statistics bars

public struct StatusBar: View {
    @EnvironmentObject private var model: AppModel
    @EnvironmentObject private var player: MPVPlayer
    @EnvironmentObject private var store: PreferencesStore
    @Environment(\.mpcTheme) private var theme

    public init() {}

    public var body: some View {
        HStack(spacing: 8) {
            Text(model.statusText)
                .lineLimit(1)
                .foregroundStyle(theme.panelText)
            Spacer()
            if player.hasMedia {
                Text(timeText)
                    .monospacedDigit()
                    .foregroundStyle(theme.panelText)
                    .onTapGesture { store.prefs.showRemainingTime.toggle() }
                    .help("Click to toggle remaining time")
            }
        }
        .font(.system(size: 11))
        .padding(.horizontal, 8)
        .frame(height: 20)
    }

    private var timeText: String {
        let pos = store.prefs.showRemainingTime
            ? "-" + TimeFormat.clock(max(0, player.duration - player.position))
            : TimeFormat.clock(player.position)
        return "\(pos) / \(TimeFormat.clock(player.duration))"
    }
}

struct InfoBar: View {
    @EnvironmentObject private var model: AppModel
    @EnvironmentObject private var player: MPVPlayer
    @Environment(\.mpcTheme) private var theme

    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            row("Title", player.mediaTitle.isEmpty ? "-" : player.mediaTitle)
            row("Author", player.getString("metadata/by-key/artist") ?? "-")
            row("Location", model.currentURL?.isFileURL == true ? (model.currentURL?.path ?? "-") : (model.currentURL?.absoluteString ?? "-"))
        }
        .padding(.horizontal, 8).padding(.vertical, 4)
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func row(_ k: String, _ v: String) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 6) {
            Text(k + ":").foregroundStyle(theme.dimText).frame(width: 70, alignment: .leading)
            Text(v).foregroundStyle(theme.panelText).lineLimit(1).truncationMode(.middle)
        }
        .font(.system(size: 11))
    }
}

struct StatsBar: View {
    @EnvironmentObject private var player: MPVPlayer
    @Environment(\.mpcTheme) private var theme

    var body: some View {
        TimelineView(.periodic(from: .now, by: 1)) { _ in
            let rows = player.statistics()
            VStack(alignment: .leading, spacing: 2) {
                if rows.isEmpty {
                    Text("No statistics").foregroundStyle(theme.dimText)
                }
                ForEach(rows, id: \.0) { r in
                    HStack(spacing: 6) {
                        Text(r.0 + ":").foregroundStyle(theme.dimText).frame(width: 70, alignment: .leading)
                        Text(r.1).foregroundStyle(theme.panelText).lineLimit(1)
                    }
                }
            }
            .font(.system(size: 11).monospacedDigit())
            .padding(.horizontal, 8).padding(.vertical, 4)
            .frame(maxWidth: .infinity, alignment: .leading)
        }
    }
}

/// Bottom chrome stack in MPC-BE order: seek bar, toolbar, info, statistics, status.
public struct ChromeStack: View {
    @EnvironmentObject private var store: PreferencesStore
    @Environment(\.mpcTheme) private var theme

    public init() {}

    public var body: some View {
        let p = store.prefs
        VStack(spacing: 0) {
            if p.showSeekBar { SeekBar().padding(.horizontal, 2) }
            if p.showControls { ControlBar() }
            if p.showInfo { Divider().overlay(theme.separator); InfoBar() }
            if p.showStats { Divider().overlay(theme.separator); StatsBar() }
            if p.showStatus { Rectangle().fill(theme.separator).frame(height: 1); StatusBar() }
        }
        .background(
            LinearGradient(colors: [theme.panel.opacity(0.92), theme.panel], startPoint: .top, endPoint: .bottom)
                .overlay(alignment: .top) { Rectangle().fill(theme.bevelLight).frame(height: 1) }
        )
    }
}

// MARK: - OSD and idle logo

public struct OSDOverlay: View {
    @EnvironmentObject private var model: AppModel
    @EnvironmentObject private var store: PreferencesStore

    public init() {}

    public var body: some View {
        let p = store.prefs
        ZStack(alignment: alignment(p.osdPosition)) {
            Color.clear
            if let msg = model.osd {
                Text(msg.text)
                    .font(.system(size: p.osdFontSize, weight: .semibold))
                    .foregroundStyle(Color(hex: p.osdTextHex))
                    .shadow(color: .black, radius: 0, x: 1, y: 1)
                    .shadow(color: .black.opacity(0.8), radius: 3)
                    .padding(.horizontal, 10).padding(.vertical, 5)
                    .background(RoundedRectangle(cornerRadius: 4).fill(Color.black.opacity(0.35)))
                    .padding(14)
                    .id(msg.id)
                    .transition(.opacity)
            }
        }
        .animation(.easeOut(duration: 0.15), value: model.osd)
        .allowsHitTesting(false)
    }

    private func alignment(_ pos: OSDPosition) -> Alignment {
        switch pos {
        case .topLeft: return .topLeading
        case .topRight: return .topTrailing
        case .topCenter: return .top
        case .bottomCenter: return .bottom
        }
    }
}

public struct IdleLogo: View {
    @Environment(\.mpcTheme) private var theme
    public init() {}
    public var body: some View {
        VStack(spacing: 10) {
            ZStack {
                RoundedRectangle(cornerRadius: 14)
                    .fill(LinearGradient(colors: [theme.accent, theme.accent.opacity(0.55)], startPoint: .topLeading, endPoint: .bottomTrailing))
                    .frame(width: 84, height: 84)
                Image(systemName: "play.fill").font(.system(size: 38, weight: .bold)).foregroundStyle(.white)
            }
            Text("MPC Player").font(.system(size: 22, weight: .bold)).foregroundStyle(.white.opacity(0.85))
            Text("Black Edition style").font(.system(size: 12)).foregroundStyle(.white.opacity(0.45))
        }
        .allowsHitTesting(false)
    }
}
