#if os(macOS)
import AppKit
import PlayerCore

/// NSMenuItem that runs a closure, so menus can be built declaratively.
public final class ClosureMenuItem: NSMenuItem {
    private let handler: () -> Void

    public init(_ title: String, checked: Bool = false, enabled: Bool = true, key: KeyBinding? = nil, handler: @escaping () -> Void) {
        self.handler = handler
        super.init(title: title, action: #selector(run), keyEquivalent: "")
        target = self
        state = checked ? .on : .off
        isEnabled = enabled
        if let key, let ch = key.character {
            keyEquivalent = String(ch)
            var mask: NSEvent.ModifierFlags = []
            if key.modifiers.contains(.command) { mask.insert(.command) }
            if key.modifiers.contains(.shift) { mask.insert(.shift) }
            if key.modifiers.contains(.option) { mask.insert(.option) }
            if key.modifiers.contains(.control) { mask.insert(.control) }
            keyEquivalentModifierMask = mask
        }
    }

    public required init(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    @objc private func run() { handler() }
}

/// Builds the right-click menu, mirroring MPC-BE's main popup menu.
@MainActor
enum MacContextMenu {
    static func build(_ model: AppModel) -> NSMenu {
        let player = model.player
        let p = model.prefs
        let keys = model.keyMap
        let has = player.hasMedia
        let menu = NSMenu()
        menu.autoenablesItems = false

        func item(_ cmd: PlayerCommand, title: String? = nil, checked: Bool = false, enabled: Bool = true) -> NSMenuItem {
            ClosureMenuItem(title ?? cmd.title, checked: checked, enabled: enabled, key: keys.keys(for: cmd).first) {
                model.perform(cmd)
            }
        }
        func sub(_ title: String, _ items: [NSMenuItem]) -> NSMenuItem {
            let m = NSMenu(title: title)
            m.autoenablesItems = false
            items.forEach(m.addItem)
            let it = NSMenuItem(title: title, action: nil, keyEquivalent: "")
            it.submenu = m
            return it
        }

        // File
        menu.addItem(sub("Open", [item(.openFile), item(.openURL), item(.loadSubtitle, enabled: has)]))
        let recent = model.history.recentURLs()
        if !recent.isEmpty {
            var items = recent.prefix(10).map { url in
                ClosureMenuItem(url.lastPathComponent) { model.open(urls: [url]) } as NSMenuItem
            }
            items.append(.separator())
            items.append(ClosureMenuItem("Clear List") { model.history.clearRecent() })
            menu.addItem(sub("Recent Files", items))
        }
        menu.addItem(item(.closeFile, enabled: has))
        menu.addItem(.separator())

        // Play
        menu.addItem(item(.playPause, title: player.isPaused || model.isStopped ? "Play" : "Pause"))
        menu.addItem(item(.stop, enabled: has))
        menu.addItem(item(.frameStep, enabled: has))
        menu.addItem(item(.frameStepBack, enabled: has))

        let speeds = AppModel.speedSteps.map { s in
            ClosureMenuItem(String(format: "%gx", s), checked: abs(player.speed - s) < 0.001) { model.setSpeed(s) } as NSMenuItem
        }
        menu.addItem(sub("Playback Rate", speeds + [.separator(), item(.speedUp), item(.speedDown), item(.speedReset)]))
        menu.addItem(sub("A-B Repeat", [
            item(.abMarkA, enabled: has), item(.abMarkB, enabled: has),
            item(.abClear, enabled: player.abLoopA != nil || player.abLoopB != nil),
        ]))
        menu.addItem(item(.loopFile, checked: player.loopFile, enabled: has))

        var nav: [NSMenuItem] = [item(.previous), item(.next), item(.previousFile), item(.nextFile), item(.goTo, enabled: has)]
        if !player.chapters.isEmpty {
            nav.append(.separator())
            let current = player.getInt("chapter") ?? -1
            nav += player.chapters.map { ch in
                ClosureMenuItem("\(TimeFormat.clock(ch.time))  \(ch.title)", checked: ch.index == current) {
                    player.setInt("chapter", ch.index)
                } as NSMenuItem
            }
        }
        menu.addItem(sub("Navigate", nav))
        menu.addItem(.separator())

        // Streams
        let audio = player.audioTracks.map { t in
            ClosureMenuItem(t.displayName, checked: t.isSelected) { model.selectTrack(t, kind: .audio) } as NSMenuItem
        }
        menu.addItem(sub("Audio", (audio.isEmpty ? [ClosureMenuItem("No audio", enabled: false) {}] : audio)
                         + [.separator(), item(.audioDelayPlus), item(.audioDelayMinus)]))

        var subs: [NSMenuItem] = [ClosureMenuItem("Off", checked: !player.subtitleTracks.contains { $0.isSelected }) {
            model.selectTrack(nil, kind: .sub)
        }]
        subs += player.subtitleTracks.map { t in
            ClosureMenuItem(t.displayName, checked: t.isSelected) { model.selectTrack(t, kind: .sub) } as NSMenuItem
        }
        subs += [.separator(), item(.loadSubtitle, enabled: has), item(.subtitleToggle, checked: player.subVisible),
                 item(.subDelayDecrease), item(.subDelayIncrease), item(.subSizeIncrease), item(.subSizeDecrease)]
        menu.addItem(sub("Subtitles", subs))

        // Video frame / aspect / pan&scan
        let modes = VideoFrameMode.allCases.map { m in
            ClosureMenuItem(m.rawValue, checked: model.frameMode == m) { model.setFrameMode(m) } as NSMenuItem
        }
        menu.addItem(sub("Video Frame", modes))
        let aspects = AppModel.aspectPresets.map { a in
            ClosureMenuItem(a.title, checked: player.aspectOverride == a.value) { model.setAspect(a.value) } as NSMenuItem
        }
        menu.addItem(sub("Aspect Ratio", aspects))
        menu.addItem(sub("Pan&Scan", [
            item(.panScanIncrease), item(.panScanDecrease), item(.panScanReset), .separator(),
            item(.panLeft), item(.panRight), item(.panUp), item(.panDown), .separator(),
            item(.rotateCW), item(.rotateCCW),
        ]))
        menu.addItem(sub("Color Controls", [
            item(.brightnessUp), item(.brightnessDown), item(.contrastUp), item(.contrastDown),
            item(.saturationUp), item(.saturationDown), .separator(), item(.colorReset),
        ]))
        menu.addItem(.separator())

        // View
        menu.addItem(sub("View", [
            item(.toggleSeekBar, title: "Seek Bar", checked: p.showSeekBar),
            item(.toggleControls, title: "Controls", checked: p.showControls),
            item(.toggleInfo, title: "Information", checked: p.showInfo),
            item(.toggleStats, title: "Statistics", checked: p.showStats),
            item(.toggleStatus, title: "Status", checked: p.showStatus),
            item(.togglePlaylist, title: "Playlist", checked: p.showPlaylist),
            .separator(),
            item(.presetMinimal, title: "Minimal"), item(.presetCompact, title: "Compact"), item(.presetNormal, title: "Normal"),
            .separator(),
            item(.zoom50), item(.zoom100), item(.zoom200), item(.zoomAutoFit),
        ]))
        menu.addItem(item(.alwaysOnTop, checked: p.alwaysOnTop))
        menu.addItem(item(.fullscreen, checked: model.isFullscreen))
        menu.addItem(item(.autoSaveImage, title: "Take Snapshot", enabled: has))
        menu.addItem(item(.saveImage, enabled: has))
        menu.addItem(.separator())
        menu.addItem(item(.options))
        menu.addItem(ClosureMenuItem("Exit") { model.platform.quit() })
        return menu
    }
}
#endif
