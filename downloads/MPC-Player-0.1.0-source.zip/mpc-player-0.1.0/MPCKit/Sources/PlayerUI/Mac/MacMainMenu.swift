#if os(macOS)
import AppKit
import PlayerCore

/// Rebuilds a menu's items every time it opens, so check marks and
/// user-edited shortcuts are always current.
final class DynamicMenu: NSMenu, NSMenuDelegate {
    private let builder: (DynamicMenu) -> Void

    init(_ title: String, builder: @escaping (DynamicMenu) -> Void) {
        self.builder = builder
        super.init(title: title)
        autoenablesItems = false
        delegate = self
        builder(self)
    }

    required init(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    func menuNeedsUpdate(_ menu: NSMenu) {
        removeAllItems()
        builder(self)
    }
}

/// The macOS menu bar, laid out like MPC-BE's File / Play / Navigate / View / Video / Audio / Subtitles menus.
@MainActor
public enum MacMainMenu {
    public static func build(model: AppModel, openOptions: @escaping () -> Void) -> NSMenu {
        let main = NSMenu()

        func cmdItem(_ cmd: PlayerCommand, _ title: String? = nil, checked: Bool = false, enabled: Bool = true) -> NSMenuItem {
            // Only ⌘ chords become key equivalents; plain keys are handled by the
            // player window's key monitor so they never steal typing elsewhere.
            let key = model.keyMap.keys(for: cmd).first { $0.modifiers.contains(.command) }
            return ClosureMenuItem(title ?? cmd.title, checked: checked, enabled: enabled, key: key) {
                if cmd == .options { openOptions() } else { model.perform(cmd) }
            }
        }

        func top(_ title: String, _ fill: @escaping (DynamicMenu) -> Void) {
            let item = NSMenuItem(title: title, action: nil, keyEquivalent: "")
            item.submenu = DynamicMenu(title, builder: fill)
            main.addItem(item)
        }

        // App menu
        top("MPC Player") { m in
            m.addItem(withTitle: "About MPC Player", action: #selector(NSApplication.orderFrontStandardAboutPanel(_:)), keyEquivalent: "")
            m.addItem(.separator())
            m.addItem(cmdItem(.options, "Options…"))
            m.addItem(.separator())
            m.addItem(withTitle: "Hide MPC Player", action: #selector(NSApplication.hide(_:)), keyEquivalent: "h")
            let others = m.addItem(withTitle: "Hide Others", action: #selector(NSApplication.hideOtherApplications(_:)), keyEquivalent: "h")
            others.keyEquivalentModifierMask = [.command, .option]
            m.addItem(withTitle: "Show All", action: #selector(NSApplication.unhideAllApplications(_:)), keyEquivalent: "")
            m.addItem(.separator())
            m.addItem(withTitle: "Quit MPC Player", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        }

        top("File") { m in
            let has = model.player.hasMedia
            m.addItem(cmdItem(.openFile))
            m.addItem(cmdItem(.openURL))
            let recent = model.history.recentURLs()
            let recentItem = NSMenuItem(title: "Recent Files", action: nil, keyEquivalent: "")
            let recentMenu = NSMenu(title: "Recent Files")
            for url in recent.prefix(15) {
                recentMenu.addItem(ClosureMenuItem(url.lastPathComponent) { model.open(urls: [url]) })
            }
            if !recent.isEmpty {
                recentMenu.addItem(.separator())
                recentMenu.addItem(ClosureMenuItem("Clear List") { model.history.clearRecent() })
            } else {
                recentMenu.addItem(ClosureMenuItem("No recent files", enabled: false) {})
            }
            recentItem.submenu = recentMenu
            m.addItem(recentItem)
            m.addItem(cmdItem(.reopen, enabled: model.currentURL != nil))
            m.addItem(.separator())
            m.addItem(cmdItem(.loadSubtitle, enabled: has))
            m.addItem(cmdItem(.saveImage, enabled: has))
            m.addItem(cmdItem(.autoSaveImage, enabled: has))
            m.addItem(.separator())
            m.addItem(cmdItem(.closeFile, "Close File", enabled: has))
            m.addItem(withTitle: "Close Window", action: #selector(NSWindow.performClose(_:)), keyEquivalent: "")
        }

        top("Edit") { m in
            m.addItem(withTitle: "Cut", action: #selector(NSText.cut(_:)), keyEquivalent: "x")
            m.addItem(withTitle: "Copy", action: #selector(NSText.copy(_:)), keyEquivalent: "c")
            m.addItem(withTitle: "Paste", action: #selector(NSText.paste(_:)), keyEquivalent: "v")
            m.addItem(withTitle: "Select All", action: #selector(NSText.selectAll(_:)), keyEquivalent: "a")
            m.items.forEach { $0.isEnabled = true }
        }

        top("Play") { m in
            let p = model.player
            m.addItem(cmdItem(.playPause, p.isPaused || model.isStopped ? "Play" : "Pause"))
            m.addItem(cmdItem(.stop))
            m.addItem(cmdItem(.frameStep))
            m.addItem(cmdItem(.frameStepBack))
            m.addItem(.separator())
            m.addItem(cmdItem(.speedUp))
            m.addItem(cmdItem(.speedDown))
            m.addItem(cmdItem(.speedReset))
            m.addItem(.separator())
            m.addItem(cmdItem(.abMarkA))
            m.addItem(cmdItem(.abMarkB))
            m.addItem(cmdItem(.abClear))
            m.addItem(cmdItem(.loopFile, checked: p.loopFile))
            m.addItem(.separator())
            m.addItem(cmdItem(.audioDelayPlus))
            m.addItem(cmdItem(.audioDelayMinus))
            m.addItem(.separator())
            let after = NSMenuItem(title: "After Playback", action: nil, keyEquivalent: "")
            let afterMenu = NSMenu(title: "After Playback")
            for option in AfterPlayback.allCases {
                afterMenu.addItem(ClosureMenuItem(option.rawValue, checked: model.prefs.afterPlayback == option) {
                    model.store.prefs.afterPlayback = option
                })
            }
            after.submenu = afterMenu
            m.addItem(after)
        }

        top("Navigate") { m in
            m.addItem(cmdItem(.previous))
            m.addItem(cmdItem(.next))
            m.addItem(cmdItem(.previousFile))
            m.addItem(cmdItem(.nextFile))
            m.addItem(.separator())
            m.addItem(cmdItem(.jumpBackwardMedium))
            m.addItem(cmdItem(.jumpForwardMedium))
            m.addItem(cmdItem(.jumpBackwardKeyframe))
            m.addItem(cmdItem(.jumpForwardKeyframe))
            m.addItem(cmdItem(.seekBegin))
            m.addItem(cmdItem(.goTo))
        }

        top("View") { m in
            let p = model.prefs
            m.addItem(cmdItem(.toggleSeekBar, "Seek Bar", checked: p.showSeekBar))
            m.addItem(cmdItem(.toggleControls, "Controls", checked: p.showControls))
            m.addItem(cmdItem(.toggleInfo, "Information", checked: p.showInfo))
            m.addItem(cmdItem(.toggleStats, "Statistics", checked: p.showStats))
            m.addItem(cmdItem(.toggleStatus, "Status", checked: p.showStatus))
            m.addItem(cmdItem(.togglePlaylist, "Playlist", checked: p.showPlaylist))
            m.addItem(.separator())
            m.addItem(cmdItem(.presetMinimal, "Minimal"))
            m.addItem(cmdItem(.presetCompact, "Compact"))
            m.addItem(cmdItem(.presetNormal, "Normal"))
            m.addItem(.separator())
            m.addItem(cmdItem(.zoom50))
            m.addItem(cmdItem(.zoom100))
            m.addItem(cmdItem(.zoom200))
            m.addItem(cmdItem(.zoomAutoFit))
            m.addItem(.separator())
            m.addItem(cmdItem(.alwaysOnTop, checked: p.alwaysOnTop))
            m.addItem(cmdItem(.fullscreen, checked: model.isFullscreen))
            m.addItem(.separator())
            m.addItem(cmdItem(.options, "Options…"))
        }

        top("Video") { m in
            for mode in VideoFrameMode.allCases {
                m.addItem(ClosureMenuItem(mode.rawValue, checked: model.frameMode == mode) { model.setFrameMode(mode) })
            }
            m.addItem(cmdItem(.frameModeNext))
            m.addItem(.separator())
            let aspect = NSMenuItem(title: "Aspect Ratio", action: nil, keyEquivalent: "")
            let aspectMenu = NSMenu(title: "Aspect Ratio")
            for a in AppModel.aspectPresets {
                aspectMenu.addItem(ClosureMenuItem(a.title, checked: model.player.aspectOverride == a.value) { model.setAspect(a.value) })
            }
            aspect.submenu = aspectMenu
            m.addItem(aspect)
            m.addItem(.separator())
            for c: PlayerCommand in [.panScanIncrease, .panScanDecrease, .panScanReset, .rotateCW, .rotateCCW] {
                m.addItem(cmdItem(c))
            }
            m.addItem(.separator())
            for c: PlayerCommand in [.brightnessUp, .brightnessDown, .contrastUp, .contrastDown, .saturationUp, .saturationDown, .colorReset] {
                m.addItem(cmdItem(c))
            }
        }

        top("Audio") { m in
            let tracks = model.player.audioTracks
            for t in tracks {
                m.addItem(ClosureMenuItem(t.displayName, checked: t.isSelected) { model.selectTrack(t, kind: .audio) })
            }
            if !tracks.isEmpty { m.addItem(.separator()) }
            m.addItem(cmdItem(.volumeUp))
            m.addItem(cmdItem(.volumeDown))
            m.addItem(cmdItem(.mute, checked: model.player.isMuted))
            m.addItem(cmdItem(.audioNext))
            m.addItem(cmdItem(.audioPrevious))
        }

        top("Subtitles") { m in
            let tracks = model.player.subtitleTracks
            m.addItem(ClosureMenuItem("Off", checked: !tracks.contains { $0.isSelected }) { model.selectTrack(nil, kind: .sub) })
            for t in tracks {
                m.addItem(ClosureMenuItem(t.displayName, checked: t.isSelected) { model.selectTrack(t, kind: .sub) })
            }
            m.addItem(.separator())
            m.addItem(cmdItem(.loadSubtitle, enabled: model.player.hasMedia))
            m.addItem(cmdItem(.subtitleToggle, checked: model.player.subVisible))
            for c: PlayerCommand in [.subtitleNext, .subtitlePrevious, .subDelayDecrease, .subDelayIncrease,
                                     .subSizeIncrease, .subSizeDecrease, .subPositionUp, .subPositionDown,
                                     .subtitlePrevLine, .subtitleNextLine] {
                m.addItem(cmdItem(c))
            }
        }

        let windowItem = NSMenuItem(title: "Window", action: nil, keyEquivalent: "")
        let windowMenu = NSMenu(title: "Window")
        windowMenu.addItem(withTitle: "Minimize", action: #selector(NSWindow.performMiniaturize(_:)), keyEquivalent: "m")
        windowMenu.addItem(withTitle: "Zoom", action: #selector(NSWindow.performZoom(_:)), keyEquivalent: "")
        windowItem.submenu = windowMenu
        main.addItem(windowItem)
        NSApp.windowsMenu = windowMenu

        return main
    }
}
#endif
