#if os(macOS)
import SwiftUI
import PlayerCore

/// The MPC-BE main window: video area (+ docked playlist) above the chrome stack.
public struct MacPlayerView: View {
    @ObservedObject private var model: AppModel
    @ObservedObject private var player: MPVPlayer
    @ObservedObject private var store: PreferencesStore
    @State private var showFullscreenChrome = false
    @State private var promptText = ""

    public init(model: AppModel) {
        self.model = model
        self.player = model.player
        self.store = model.store
    }

    public var body: some View {
        let theme = Theme(store.prefs)
        let p = store.prefs
        let overlayChrome = model.isFullscreen && p.hideControlsInFullscreen

        VStack(spacing: 0) {
            HStack(spacing: 0) {
                videoArea(theme)
                if p.showPlaylist && !model.isFullscreen {
                    Rectangle().fill(theme.separator).frame(width: 1)
                    PlaylistPanel().frame(width: 260)
                }
            }
            if !overlayChrome {
                ChromeStack()
            }
        }
        .overlay(alignment: .bottom) {
            if overlayChrome && showFullscreenChrome {
                ChromeStack().transition(.move(edge: .bottom).combined(with: .opacity))
            }
        }
        .onContinuousHover { phase in
            guard overlayChrome else { return }
            if case .active(let pt) = phase {
                // The hover location is in the window's coordinate space (top-left origin).
                let height = NSApp.keyWindow?.contentView?.bounds.height ?? 0
                withAnimation(.easeOut(duration: 0.15)) { showFullscreenChrome = pt.y > height - 110 }
            } else {
                showFullscreenChrome = false
            }
        }
        .background(theme.video)
        .environment(\.mpcTheme, theme)
        .environmentObject(model)
        .environmentObject(player)
        .environmentObject(store)
        .onChange(of: model.windowTitle) { _, title in
            model.videoView.window?.title = title
        }
        .alert(promptTitle, isPresented: Binding(get: { model.prompt != nil }, set: { if !$0 { model.prompt = nil } })) {
            TextField(model.prompt == .goTo ? "HH:MM:SS" : "https://…", text: $promptText)
            Button("OK") { submitPrompt() }
            Button("Cancel", role: .cancel) { model.prompt = nil }
        } message: {
            Text(model.prompt == .goTo
                 ? "Enter a time (current \(TimeFormat.clock(player.position)) of \(TimeFormat.clock(player.duration)))."
                 : "Enter a URL or file path to open.")
        }
        .onChange(of: model.prompt) { _, kind in
            promptText = kind == .goTo ? TimeFormat.clock(player.position) : ""
        }
        .dropDestination(for: URL.self) { urls, _ in
            model.open(urls: MacWindowController.expandFolders(urls))
            return true
        }
    }

    private var promptTitle: String { model.prompt == .goTo ? "Go To" : "Open URL" }

    private func submitPrompt() {
        switch model.prompt {
        case .goTo:
            if let t = TimeFormat.parse(promptText) { player.seek(to: t); model.isStopped = false }
        case .openURL:
            model.open(urlString: promptText)
        case nil:
            break
        }
        model.prompt = nil
    }

    private func videoArea(_ theme: Theme) -> some View {
        ZStack {
            theme.video
            VideoSurface(model: model)
            if !player.hasMedia && !player.isLoading && store.prefs.showLogo {
                IdleLogo()
            }
            OSDOverlay()
        }
        .frame(minWidth: 200, minHeight: 120)
    }
}
#endif
