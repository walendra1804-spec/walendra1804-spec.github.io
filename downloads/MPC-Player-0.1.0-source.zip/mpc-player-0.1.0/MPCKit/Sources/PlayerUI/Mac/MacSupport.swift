#if os(macOS)
import AppKit
import SwiftUI
import UniformTypeIdentifiers
import PlayerCore

extension KeyBinding {
    /// Converts a keyDown event into a binding, using the unshifted base key.
    public static func from(event: NSEvent) -> KeyBinding? {
        let flags = event.modifierFlags.intersection(.deviceIndependentFlagsMask)
        var mods: KeyModifiers = []
        if flags.contains(.command) { mods.insert(.command) }
        if flags.contains(.control) { mods.insert(.control) }
        if flags.contains(.option) { mods.insert(.option) }
        if flags.contains(.shift) { mods.insert(.shift) }
        let base = event.characters(byApplyingModifiers: []) ?? event.charactersIgnoringModifiers
        guard let ch = base?.first, let name = KeyBinding.keyName(for: ch) else { return nil }
        return KeyBinding(name, mods)
    }
}

/// Glue between AppModel and the NSWindow hosting the player.
@MainActor
public final class MacWindowController: NSObject {
    weak var window: NSWindow?
    private weak var model: AppModel?
    private var keyMonitor: Any?
    private var observers: [NSObjectProtocol] = []

    public override init() { super.init() }

    public func attach(window: NSWindow, model: AppModel, openOptions: @escaping () -> Void) {
        guard self.window !== window else { return }
        self.window = window
        self.model = model
        window.collectionBehavior.insert(.fullScreenPrimary)
        window.backgroundColor = .black
        window.minSize = NSSize(width: 360, height: 240)
        if model.prefs.alwaysOnTop { window.level = .floating }
        if window.frame.width < 500 {
            window.setContentSize(NSSize(width: 800, height: 520))
            window.center()
        }

        var hooks = model.platform
        hooks.openFiles = { [weak self] in self?.openFiles() }
        hooks.openSubtitle = { [weak self] in self?.openSubtitle() }
        hooks.toggleFullscreen = { [weak self] in self?.window?.toggleFullScreen(nil) }
        hooks.openOptions = openOptions
        hooks.bossKey = { NSApp.hide(nil) }
        hooks.setAlwaysOnTop = { [weak self] on in self?.window?.level = on ? .floating : .normal }
        hooks.setWindowScale = { [weak self] scale in self?.setWindowScale(scale) }
        hooks.saveImageAs = { [weak self] name in self?.saveImageAs(name) }
        hooks.quit = { NSApp.terminate(nil) }
        model.platform = hooks

        let nc = NotificationCenter.default
        observers.append(nc.addObserver(forName: NSWindow.didEnterFullScreenNotification, object: window, queue: .main) { [weak model] _ in
            MainActor.assumeIsolated { model?.isFullscreen = true }
        })
        observers.append(nc.addObserver(forName: NSWindow.didExitFullScreenNotification, object: window, queue: .main) { [weak model] _ in
            MainActor.assumeIsolated { model?.isFullscreen = false }
        })

        let video = model.videoView
        video.onSingleClick = { [weak model] in
            guard let model, model.prefs.singleClickPlayPause, model.player.hasMedia else { return }
            model.perform(.playPause)
        }
        video.onDoubleClick = { [weak model] in
            guard let model, model.prefs.doubleClickFullscreen else { return }
            // The first click of the double-click already toggled pause; undo it like MPC-BE.
            if model.prefs.singleClickPlayPause && model.player.hasMedia { model.perform(.playPause) }
            model.perform(.fullscreen)
        }
        video.menuProvider = { [weak model] in model.map(MacContextMenu.build) }
        video.onScroll = { [weak model] step in
            guard let model, model.prefs.scrollWheelVolume else { return }
            model.perform(step > 0 ? .volumeUp : .volumeDown)
        }
        video.onDropURLs = { [weak model] urls in model?.open(urls: Self.expandFolders(urls)) }

        installKeyMonitor()
    }

    private func installKeyMonitor() {
        guard keyMonitor == nil else { return }
        keyMonitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { [weak self] event in
            guard let self, let model = self.model, let window = self.window,
                  event.window === window, NSApp.keyWindow === window else { return event }
            if window.firstResponder is NSText { return event } // typing in a field
            guard let binding = KeyBinding.from(event: event),
                  let cmd = model.keyMap.command(for: binding) else { return event }
            model.perform(cmd)
            return nil
        }
    }

    // MARK: Panels

    func openFiles() {
        let panel = NSOpenPanel()
        panel.allowsMultipleSelection = true
        panel.canChooseDirectories = true
        panel.canChooseFiles = true
        panel.title = "Open"
        guard panel.runModal() == .OK else { return }
        model?.open(urls: Self.expandFolders(panel.urls))
    }

    func openSubtitle() {
        let panel = NSOpenPanel()
        panel.allowsMultipleSelection = false
        panel.allowedContentTypes = MediaFiles.subtitleExtensions.compactMap { UTType(filenameExtension: $0) }
        panel.title = "Load Subtitle"
        if let dir = model?.currentURL?.deletingLastPathComponent(), dir.isFileURL { panel.directoryURL = dir }
        guard panel.runModal() == .OK, let url = panel.url else { return }
        model?.loadSubtitle(url)
    }

    func saveImageAs(_ name: String) {
        guard let model else { return }
        let panel = NSSavePanel()
        panel.nameFieldStringValue = name
        panel.directoryURL = model.snapshotFolder
        panel.allowedContentTypes = [.png, .jpeg, .heic]
        guard panel.runModal() == .OK, let url = panel.url else { return }
        model.saveImage(to: url)
    }

    static func expandFolders(_ urls: [URL]) -> [URL] {
        urls.flatMap { url -> [URL] in
            var isDir: ObjCBool = false
            guard FileManager.default.fileExists(atPath: url.path, isDirectory: &isDir), isDir.boolValue else { return [url] }
            let items = (try? FileManager.default.contentsOfDirectory(at: url, includingPropertiesForKeys: nil, options: [.skipsHiddenFiles])) ?? []
            return items.filter(MediaFiles.isMedia).sorted {
                $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending
            }
        }
    }

    // MARK: Window sizing (Zoom 50/100/200%, Auto Fit)

    func setWindowScale(_ scale: Double?) {
        guard let window, let model, !model.isFullscreen,
              let contentView = window.contentView else { return }
        let video = model.player.videoSize
        guard video.width > 0, video.height > 0 else { return }
        let videoBounds = model.videoView.bounds.size
        let chromeW = contentView.bounds.width - videoBounds.width
        let chromeH = contentView.bounds.height - videoBounds.height
        let screen = (window.screen ?? NSScreen.main)?.visibleFrame ?? .zero
        let titleH = window.frame.height - contentView.bounds.height

        var target: CGSize
        if let scale {
            target = CGSize(width: video.width * scale, height: video.height * scale)
        } else {
            // Auto fit: 1:1 if it fits, otherwise shrink to 90% of the screen.
            let maxW = screen.width * 0.9 - chromeW, maxH = screen.height * 0.9 - chromeH - titleH
            let f = min(1, maxW / video.width, maxH / video.height)
            target = CGSize(width: video.width * f, height: video.height * f)
        }
        let content = NSSize(width: max(360, target.width + chromeW), height: max(200, target.height + chromeH))
        var frame = window.frameRect(forContentRect: NSRect(origin: .zero, size: content))
        frame.origin = NSPoint(x: window.frame.midX - frame.width / 2, y: window.frame.maxY - frame.height)
        if frame.maxX > screen.maxX { frame.origin.x = screen.maxX - frame.width }
        if frame.minX < screen.minX { frame.origin.x = screen.minX }
        if frame.minY < screen.minY { frame.origin.y = screen.minY }
        window.setFrame(frame, display: true, animate: true)
    }
}

/// Finds the NSWindow that hosts a SwiftUI view.
struct WindowAccessor: NSViewRepresentable {
    let onWindow: (NSWindow) -> Void

    func makeNSView(context: Context) -> NSView {
        let v = NSView()
        DispatchQueue.main.async { [weak v] in
            if let w = v?.window { onWindow(w) }
        }
        return v
    }

    func updateNSView(_ nsView: NSView, context: Context) {
        if let w = nsView.window { DispatchQueue.main.async { onWindow(w) } }
    }
}
#endif
