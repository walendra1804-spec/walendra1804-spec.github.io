import SwiftUI
import PlayerCore
#if os(macOS)
import AppKit
#endif

/// The "Keys" page: every command with its key chords, record / remove / reset,
/// and conflict highlighting — the equivalent of MPC-BE's Options › Keys table.
struct HotkeyEditor: View {
    @Binding var bindings: [String: [KeyBinding]]
    @State private var filter = ""
    @State private var recordingFor: PlayerCommand?
    @StateObject private var recorder = KeyRecorder()

    private var keyMap: KeyMap { KeyMap(overrides: bindings) }

    var body: some View {
        let conflicts = keyMap.conflicts
        VStack(spacing: 0) {
            HStack {
                TextField("Search commands or keys", text: $filter)
                    .textFieldStyle(.roundedBorder)
                Button("Reset All Keys") { bindings = [:] }
            }
            .padding(10)

            if let cmd = recordingFor {
                HStack(spacing: 8) {
                    Image(systemName: "record.circle").foregroundStyle(.red)
                    Text("Press a key combination for “\(cmd.title)”…  (Esc to cancel)")
                    Spacer()
                    Button("Cancel") { stopRecording() }
                }
                .font(.callout)
                .padding(.horizontal, 10).padding(.vertical, 6)
                .background(Color.red.opacity(0.12))
            }

            List {
                ForEach(PlayerCommand.Category.allCases) { category in
                    let cmds = PlayerCommand.allCases.filter { $0.category == category && matches($0) }
                    if !cmds.isEmpty {
                        Section(category.rawValue) {
                            ForEach(cmds) { cmd in
                                row(cmd, conflicts: conflicts)
                            }
                        }
                    }
                }
            }
            #if os(macOS)
            .listStyle(.inset(alternatesRowBackgrounds: true))
            #endif
        }
        .background(KeyCaptureView(recorder: recorder))
        .onReceive(recorder.$captured.compactMap { $0 }) { binding in
            guard let cmd = recordingFor else { return }
            if binding.key == "escape" && binding.modifiers.isEmpty {
                stopRecording()
                return
            }
            var keys = keyMap.keys(for: cmd)
            if !keys.contains(binding) { keys.append(binding) }
            bindings[cmd.rawValue] = keys
            stopRecording()
        }
    }

    private func row(_ cmd: PlayerCommand, conflicts: Set<KeyBinding>) -> some View {
        let keys = keyMap.keys(for: cmd)
        let overridden = bindings[cmd.rawValue] != nil
        return HStack(spacing: 6) {
            Text(cmd.title)
                .fontWeight(overridden ? .semibold : .regular)
                .frame(minWidth: 200, alignment: .leading)
            Spacer()
            ForEach(keys, id: \.self) { key in
                HStack(spacing: 3) {
                    Text(key.displayString).font(.system(.callout, design: .monospaced))
                    Button {
                        bindings[cmd.rawValue] = keys.filter { $0 != key }
                    } label: { Image(systemName: "xmark.circle.fill") }
                        .buttonStyle(.plain)
                        .foregroundStyle(.secondary)
                        .help("Remove this key")
                }
                .padding(.horizontal, 6).padding(.vertical, 2)
                .background(RoundedRectangle(cornerRadius: 4)
                    .fill(conflicts.contains(key) ? Color.red.opacity(0.25) : Color.gray.opacity(0.18)))
                .help(conflicts.contains(key) ? "This key is assigned to more than one command" : "")
            }
            Button {
                recordingFor = cmd
                recorder.start()
            } label: {
                Image(systemName: recordingFor == cmd ? "record.circle.fill" : "plus.circle")
            }
            .buttonStyle(.plain)
            .foregroundStyle(recordingFor == cmd ? .red : .accentColor)
            .help("Add a key")
            Button {
                bindings.removeValue(forKey: cmd.rawValue)
            } label: { Image(systemName: "arrow.uturn.backward.circle") }
                .buttonStyle(.plain)
                .foregroundStyle(.secondary)
                .opacity(overridden ? 1 : 0)
                .disabled(!overridden)
                .help("Reset to default")
        }
    }

    private func matches(_ cmd: PlayerCommand) -> Bool {
        guard !filter.isEmpty else { return true }
        let q = filter.lowercased()
        return cmd.title.lowercased().contains(q)
            || keyMap.keys(for: cmd).contains { $0.displayString.lowercased().contains(q) }
    }

    private func stopRecording() {
        recordingFor = nil
        recorder.stop()
    }
}

/// Captures the next key chord, including ⌘ chords that menus would otherwise eat.
@MainActor
final class KeyRecorder: ObservableObject {
    @Published var captured: KeyBinding?
    @Published private(set) var isRecording = false
    #if os(macOS)
    private var monitor: Any?
    #endif

    func start() {
        captured = nil
        isRecording = true
        #if os(macOS)
        if monitor == nil {
            monitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { [weak self] event in
                guard let self, self.isRecording, let b = KeyBinding.from(event: event) else { return event }
                self.captured = b
                return nil
            }
        }
        #endif
    }

    func stop() {
        isRecording = false
        #if os(macOS)
        if let monitor { NSEvent.removeMonitor(monitor) }
        monitor = nil
        #endif
    }

    func capture(_ binding: KeyBinding) {
        guard isRecording else { return }
        captured = binding
    }
}

/// On iOS / iPadOS a hardware keyboard is read through SwiftUI's onKeyPress.
struct KeyCaptureView: View {
    @ObservedObject var recorder: KeyRecorder
    @FocusState private var focused: Bool

    var body: some View {
        #if os(iOS)
        Color.clear
            .focusable()
            .focused($focused)
            .onChange(of: recorder.isRecording) { _, rec in focused = rec }
            .onKeyPress(phases: .down) { press in
                guard recorder.isRecording, let b = KeyBinding.from(press: press) else { return .ignored }
                recorder.capture(b)
                return .handled
            }
        #else
        Color.clear
        #endif
    }
}

extension KeyBinding {
    /// Converts a SwiftUI key press (hardware keyboard) into a binding.
    public static func from(press: KeyPress) -> KeyBinding? {
        var mods: KeyModifiers = []
        if press.modifiers.contains(.command) { mods.insert(.command) }
        if press.modifiers.contains(.control) { mods.insert(.control) }
        if press.modifiers.contains(.option) { mods.insert(.option) }
        if press.modifiers.contains(.shift) { mods.insert(.shift) }
        guard let name = KeyBinding.keyName(for: press.key.character) else { return nil }
        return KeyBinding(name, mods)
    }
}
