import SwiftUI
import PlayerCore

enum OptionsPage: String, CaseIterable, Identifiable {
    case player = "Player"
    case playback = "Playback"
    case keys = "Keys"
    case interface = "Interface & Theme"
    case osd = "OSD"
    case subtitles = "Subtitles"
    case video = "Video"
    case snapshot = "Snapshot"
    case touch = "Touch Gestures"

    var id: String { rawValue }

    var symbol: String {
        switch self {
        case .player: return "play.rectangle"
        case .playback: return "forward"
        case .keys: return "keyboard"
        case .interface: return "paintpalette"
        case .osd: return "text.bubble"
        case .subtitles: return "captions.bubble"
        case .video: return "film"
        case .snapshot: return "camera"
        case .touch: return "hand.draw"
        }
    }

    static var visible: [OptionsPage] {
        #if os(macOS)
        return allCases.filter { $0 != .touch }
        #else
        return allCases
        #endif
    }
}

/// MPC-BE style Options dialog: page tree on the left, OK / Cancel / Apply.
/// Edits a draft copy so Cancel really discards changes.
public struct OptionsView: View {
    @ObservedObject private var store: PreferencesStore
    @State private var draft: Preferences
    @State private var page: OptionsPage? = .player
    private let onClose: () -> Void

    public init(store: PreferencesStore, onClose: @escaping () -> Void) {
        self.store = store
        self.onClose = onClose
        _draft = State(initialValue: store.prefs)
    }

    private var dirty: Bool { draft != store.prefs }

    public var body: some View {
        #if os(macOS)
        VStack(spacing: 0) {
            HStack(spacing: 0) {
                List(OptionsPage.visible, selection: $page) { pg in
                    Label(pg.rawValue, systemImage: pg.symbol).tag(pg)
                }
                .listStyle(.sidebar)
                .frame(width: 190)
                Divider()
                pageView(page ?? .player)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            Divider()
            HStack {
                Button("Reset All…") { draft = Preferences() }
                Spacer()
                Button("OK") { store.prefs = draft; onClose() }
                    .keyboardShortcut(.defaultAction)
                Button("Cancel") { draft = store.prefs; onClose() }
                    .keyboardShortcut(.cancelAction)
                Button("Apply") { store.prefs = draft }
                    .disabled(!dirty)
            }
            .padding(12)
        }
        .frame(minWidth: 760, minHeight: 540)
        .onReceive(store.$prefs) { newValue in
            // Keep the draft in sync with changes made from the player (hotkeys, menus).
            if !dirty { draft = newValue }
        }
        #else
        NavigationStack {
            List(OptionsPage.visible) { pg in
                NavigationLink(value: pg) { Label(pg.rawValue, systemImage: pg.symbol) }
            }
            .navigationTitle("Options")
            .navigationDestination(for: OptionsPage.self) { pg in
                pageView(pg).navigationTitle(pg.rawValue)
            }
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { draft = store.prefs; onClose() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") { store.prefs = draft; onClose() }.bold()
                }
                ToolbarItem(placement: .bottomBar) {
                    Button("Reset All", role: .destructive) { draft = Preferences() }
                }
            }
        }
        #endif
    }

    @ViewBuilder
    private func pageView(_ pg: OptionsPage) -> some View {
        switch pg {
        case .keys:
            HotkeyEditor(bindings: $draft.keyBindings)
        default:
            Form { formContent(pg) }
                .formStyle(.grouped)
        }
    }

    @ViewBuilder
    private func formContent(_ pg: OptionsPage) -> some View {
        switch pg {
        case .player:
            Section("Open options") {
                Toggle("Remember file position", isOn: $draft.rememberPosition)
                Toggle("Remember volume", isOn: $draft.rememberVolume)
                Toggle("Auto-load files from the same folder", isOn: $draft.autoLoadFolder)
                Toggle("Open files paused", isOn: $draft.openPaused)
                #if os(macOS)
                Toggle("Auto-zoom window to video size", isOn: $draft.autoZoomWindow)
                #endif
            }
            Section("After playback") {
                Picker("When a file ends", selection: $draft.afterPlayback) {
                    ForEach(AfterPlayback.allCases) { Text($0.rawValue).tag($0) }
                }
                Picker("Repeat", selection: $draft.loopMode) {
                    ForEach(LoopMode.allCases) { Text($0.rawValue).tag($0) }
                }
            }
            #if os(macOS)
            Section("Mouse") {
                Toggle("Left click: Play/Pause", isOn: $draft.singleClickPlayPause)
                Toggle("Double click: Fullscreen", isOn: $draft.doubleClickFullscreen)
                Toggle("Wheel: Volume", isOn: $draft.scrollWheelVolume)
            }
            #endif
        case .playback:
            Section("Jump distances") {
                Stepper("Small: \(draft.jumpSmallMs) ms", value: $draft.jumpSmallMs, in: 100...60_000, step: 100)
                Stepper("Medium: \(draft.jumpMediumMs) ms", value: $draft.jumpMediumMs, in: 500...300_000, step: 500)
                Stepper("Large: \(draft.jumpLargeMs) ms", value: $draft.jumpLargeMs, in: 1000...600_000, step: 1000)
                Toggle("Fast seek (seek to nearest keyframe)", isOn: $draft.fastSeek)
            }
            Section("Volume") {
                Stepper("Volume step: \(draft.volumeStep)%", value: $draft.volumeStep, in: 1...20)
                Stepper("Maximum volume (boost): \(draft.maxVolume)%", value: $draft.maxVolume, in: 100...300, step: 10)
            }
            Section("Speed") {
                Picker("Speed step", selection: $draft.speedStep) {
                    Text("Auto (0.25 … 8x presets)").tag(0.0)
                    Text("0.05x").tag(0.05)
                    Text("0.1x").tag(0.1)
                    Text("0.25x").tag(0.25)
                    Text("0.5x").tag(0.5)
                }
                Stepper("Audio delay step: \(draft.audioDelayStepMs) ms", value: $draft.audioDelayStepMs, in: 1...500)
                TextField("Preferred audio languages", text: $draft.preferredAudioLangs, prompt: Text("jpn,eng"))
            }
        case .keys:
            EmptyView()
        case .interface:
            Section("Theme") {
                Picker("Preset", selection: Binding(get: { draft.themePreset }, set: { draft.apply(preset: $0) })) {
                    ForEach(ThemePreset.allCases) { Text($0.rawValue).tag($0) }
                }
                colorRow("Panel background", \.panelHex)
                colorRow("Panel text / icons", \.panelTextHex)
                colorRow("Accent (seek bar, volume)", \.accentHex)
                colorRow("Seek bar channel", \.seekTrackHex)
                colorRow("Video background", \.videoBackgroundHex)
                ThemePreview(prefs: draft)
            }
            Section("Layout") {
                Toggle("Seek bar", isOn: $draft.showSeekBar)
                Toggle("Controls (toolbar)", isOn: $draft.showControls)
                Toggle("Information panel", isOn: $draft.showInfo)
                Toggle("Statistics panel", isOn: $draft.showStats)
                Toggle("Status bar", isOn: $draft.showStatus)
                #if os(macOS)
                Toggle("Playlist panel", isOn: $draft.showPlaylist)
                Toggle("Hide controls in fullscreen (show on hover)", isOn: $draft.hideControlsInFullscreen)
                Toggle("Always on top", isOn: $draft.alwaysOnTop)
                #endif
                Toggle("Show logo when idle", isOn: $draft.showLogo)
                Toggle("Status bar shows remaining time", isOn: $draft.showRemainingTime)
                slider("Toolbar icon size", value: $draft.toolbarIconSize, range: 11...30, format: "%.0f pt")
                slider("Seek bar height", value: $draft.seekBarHeight, range: 8...32, format: "%.0f pt")
            }
        case .osd:
            Section("On-screen display") {
                Toggle("Show OSD messages", isOn: $draft.osdEnabled)
                Toggle("Show position when seeking", isOn: $draft.osdShowSeek)
                Toggle("Show volume changes", isOn: $draft.osdShowVolume)
                Picker("Position", selection: $draft.osdPosition) {
                    ForEach(OSDPosition.allCases) { Text($0.rawValue).tag($0) }
                }
                slider("Font size", value: $draft.osdFontSize, range: 10...48, format: "%.0f pt")
                Stepper("Duration: \(draft.osdDurationMs) ms", value: $draft.osdDurationMs, in: 300...10_000, step: 100)
                colorRow("Text color", \.osdTextHex)
            }
        case .subtitles:
            Section("Loading") {
                Toggle("Auto-load external subtitles", isOn: $draft.subAutoLoad)
                TextField("Preferred subtitle languages", text: $draft.preferredSubLangs, prompt: Text("ind,eng"))
                Stepper("Delay step: \(draft.subDelayStepMs) ms", value: $draft.subDelayStepMs, in: 10...5000, step: 10)
            }
            Section("Default style (SRT and plain text)") {
                TextField("Font", text: $draft.subFont, prompt: Text("System default"))
                slider("Font size", value: $draft.subFontSize, range: 20...100, format: "%.0f")
                colorRow("Text color", \.subTextHex)
                colorRow("Outline color", \.subBorderHex)
                slider("Outline width", value: $draft.subBorderSize, range: 0...8, format: "%.1f")
                Toggle("Override ASS/SSA styles", isOn: $draft.subOverrideASS)
            }
        case .video:
            Section("Decoding") {
                Toggle("Hardware decoding (VideoToolbox)", isOn: $draft.hardwareDecoding)
            }
            Section("Rendering") {
                Picker("Default video frame", selection: $draft.defaultFrameMode) {
                    ForEach(VideoFrameMode.allCases) { Text($0.rawValue).tag($0) }
                }
                Toggle("Deband", isOn: $draft.deband)
                Toggle("Frame interpolation (smooth motion)", isOn: $draft.interpolation)
            }
        case .snapshot:
            Section("Snapshot") {
                Picker("Format", selection: $draft.snapshotFormat) {
                    ForEach(SnapshotFormat.allCases) { Text($0.rawValue.uppercased()).tag($0) }
                }
                Toggle("Include subtitles", isOn: $draft.snapshotWithSubtitles)
                #if os(macOS)
                TextField("Folder", text: $draft.snapshotFolder, prompt: Text("~/Pictures/MPC Player"))
                #else
                Text("Snapshots are saved to the app's Documents/Snapshots folder (visible in the Files app).")
                    .font(.footnote).foregroundStyle(.secondary)
                #endif
            }
        case .touch:
            Section("Gestures") {
                Toggle("Swipe horizontally to seek", isOn: $draft.gestureSeek)
                Toggle("Swipe right side for volume", isOn: $draft.gestureVolume)
                Toggle("Swipe left side for brightness", isOn: $draft.gestureBrightness)
                Toggle("Pinch to fill / fit", isOn: $draft.pinchToZoom)
                Stepper("Double-tap seek: \(draft.doubleTapSeekSeconds) s", value: $draft.doubleTapSeekSeconds, in: 1...120)
                slider("Swipe sensitivity", value: $draft.gestureSensitivity, range: 0.25...3, format: "%.2fx")
                slider("Auto-hide controls after", value: $draft.controlsAutoHideSeconds, range: 1...15, format: "%.0f s")
            }
        }
    }

    private func colorRow(_ title: String, _ key: WritableKeyPath<Preferences, String>) -> some View {
        ColorPicker(title, selection: Binding(
            get: { Color(hex: draft[keyPath: key]) },
            set: { newColor in
                draft[keyPath: key] = newColor.hexString
                if [\Preferences.panelHex, \.panelTextHex, \.accentHex, \.seekTrackHex, \.videoBackgroundHex].contains(key) {
                    draft.themePreset = .custom
                }
            }
        ), supportsOpacity: false)
    }

    private func slider(_ title: String, value: Binding<Double>, range: ClosedRange<Double>, format: String) -> some View {
        VStack(alignment: .leading) {
            HStack {
                Text(title)
                Spacer()
                Text(String(format: format, value.wrappedValue)).monospacedDigit().foregroundStyle(.secondary)
            }
            Slider(value: value, in: range)
        }
    }
}

/// Live preview of the chrome colors inside the Interface page.
struct ThemePreview: View {
    let prefs: Preferences

    var body: some View {
        let t = Theme(prefs)
        VStack(spacing: 0) {
            ZStack {
                t.video
                Text("Video").foregroundStyle(.white.opacity(0.4)).font(.caption)
            }
            .frame(height: 60)
            VStack(spacing: 4) {
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 2).fill(t.track).frame(height: 7)
                    RoundedRectangle(cornerRadius: 2).fill(t.accent).frame(width: 140, height: 7)
                }
                HStack(spacing: 10) {
                    ForEach(["play.fill", "pause.fill", "stop.fill", "backward.end.fill", "forward.end.fill"], id: \.self) {
                        Image(systemName: $0)
                    }
                    Spacer()
                    VolumeWedge.Wedge().fill(t.accent).frame(width: 50, height: 12)
                }
                .foregroundStyle(t.panelText)
                .font(.system(size: 12))
                HStack {
                    Text("Playing")
                    Spacer()
                    Text("00:12:34 / 01:30:00").monospacedDigit()
                }
                .font(.system(size: 10))
                .foregroundStyle(t.panelText)
            }
            .padding(8)
            .background(t.panel)
        }
        .clipShape(RoundedRectangle(cornerRadius: 6))
        .overlay(RoundedRectangle(cornerRadius: 6).stroke(Color.gray.opacity(0.3)))
        .padding(.vertical, 4)
    }
}
