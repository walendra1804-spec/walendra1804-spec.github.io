import SwiftUI
import PlayerCore

/// MPC-BE style playlist: current item marked with ▶, double-click to play.
public struct PlaylistPanel: View {
    @EnvironmentObject private var model: AppModel
    @Environment(\.mpcTheme) private var theme
    @State private var selection: Set<UUID> = []

    public init() {}

    public var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("Playlist").font(.system(size: 12, weight: .semibold))
                Spacer()
                Text("\(model.playlist.count) item\(model.playlist.count == 1 ? "" : "s")")
                    .font(.system(size: 11)).foregroundStyle(theme.dimText)
            }
            .foregroundStyle(theme.panelText)
            .padding(.horizontal, 8).padding(.vertical, 5)

            List(selection: $selection) {
                ForEach(Array(model.playlist.enumerated()), id: \.element.id) { idx, item in
                    row(idx: idx, item: item)
                        .tag(item.id)
                        .listRowBackground(idx == model.currentIndex ? theme.accent.opacity(0.22) : Color.clear)
                        .contextMenu {
                            Button("Play") { model.play(at: idx) }
                            Button("Remove") { model.removeFromPlaylist(IndexSet(integer: idx)) }
                        }
                }
                .onMove { model.movePlaylist(from: $0, to: $1) }
                .onDelete { model.removeFromPlaylist($0) }
            }
            .listStyle(.plain)
            .scrollContentBackground(.hidden)
            .background(theme.track.opacity(0.6))

            HStack(spacing: 2) {
                Button { model.perform(.openFile) } label: { Image(systemName: "plus") }
                    .help("Add files")
                Button {
                    let idx = IndexSet(model.playlist.enumerated().filter { selection.contains($0.element.id) }.map(\.offset))
                    model.removeFromPlaylist(idx)
                    selection.removeAll()
                } label: { Image(systemName: "minus") }
                    .disabled(selection.isEmpty)
                    .help("Remove selected")
                Button {
                    let currentID = model.currentIndex.map { model.playlist[$0].id }
                    model.playlist.shuffle()
                    model.currentIndex = model.playlist.firstIndex { $0.id == currentID }
                } label: { Image(systemName: "shuffle") }
                    .help("Shuffle")
                Spacer()
                Button {
                    model.playlist.removeAll()
                    model.currentIndex = nil
                } label: { Image(systemName: "trash") }
                    .disabled(model.playlist.isEmpty)
                    .help("Clear playlist")
            }
            .buttonStyle(ToolbarButtonStyle(theme: theme))
            .font(.system(size: 11))
            .padding(4)
        }
        .background(theme.panel)
    }

    private func row(idx: Int, item: PlaylistItem) -> some View {
        HStack(spacing: 6) {
            Image(systemName: "play.fill")
                .font(.system(size: 8))
                .opacity(idx == model.currentIndex ? 1 : 0)
                .foregroundStyle(theme.accent)
            Text(item.title).lineLimit(1).truncationMode(.middle)
            Spacer(minLength: 0)
        }
        .font(.system(size: 12))
        .foregroundStyle(theme.panelText)
        .contentShape(Rectangle())
        .onTapGesture(count: 2) { model.play(at: idx) }
        #if os(iOS)
        .onTapGesture { model.play(at: idx) }
        #endif
    }
}
