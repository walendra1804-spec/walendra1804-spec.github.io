import SwiftUI
import PlayerCore
#if os(macOS)
import AppKit
typealias PlatformColor = NSColor
#else
import UIKit
typealias PlatformColor = UIColor
#endif

extension Color {
    /// Accepts "#RRGGBB" or "#AARRGGBB".
    public init(hex: String) {
        var s = hex.trimmingCharacters(in: .whitespacesAndNewlines)
        if s.hasPrefix("#") { s.removeFirst() }
        var value: UInt64 = 0
        Scanner(string: s).scanHexInt64(&value)
        let a, r, g, b: Double
        if s.count == 8 {
            a = Double((value >> 24) & 0xFF) / 255
            r = Double((value >> 16) & 0xFF) / 255
            g = Double((value >> 8) & 0xFF) / 255
            b = Double(value & 0xFF) / 255
        } else {
            a = 1
            r = Double((value >> 16) & 0xFF) / 255
            g = Double((value >> 8) & 0xFF) / 255
            b = Double(value & 0xFF) / 255
        }
        self.init(.sRGB, red: r, green: g, blue: b, opacity: a)
    }

    public var hexString: String {
        #if os(macOS)
        guard let c = NSColor(self).usingColorSpace(.sRGB) else { return "#000000" }
        let r = c.redComponent, g = c.greenComponent, b = c.blueComponent
        #else
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        UIColor(self).getRed(&r, green: &g, blue: &b, alpha: &a)
        #endif
        func h(_ v: CGFloat) -> Int { Int((min(1, max(0, v)) * 255).rounded()) }
        return String(format: "#%02X%02X%02X", h(r), h(g), h(b))
    }

    /// Simple luminance test used to pick readable overlay colors.
    var isDark: Bool {
        #if os(macOS)
        guard let c = NSColor(self).usingColorSpace(.sRGB) else { return true }
        let r = c.redComponent, g = c.greenComponent, b = c.blueComponent
        #else
        var r: CGFloat = 0, g: CGFloat = 0, b: CGFloat = 0, a: CGFloat = 0
        UIColor(self).getRed(&r, green: &g, blue: &b, alpha: &a)
        #endif
        return (0.299 * r + 0.587 * g + 0.114 * b) < 0.5
    }
}

/// Resolved colors for the MPC-BE-style chrome, derived from Preferences.
public struct Theme: Equatable {
    public var panel: Color
    public var panelText: Color
    public var accent: Color
    public var track: Color
    public var video: Color
    public var iconSize: CGFloat
    public var seekBarHeight: CGFloat

    public init(_ p: Preferences) {
        panel = Color(hex: p.panelHex)
        panelText = Color(hex: p.panelTextHex)
        accent = Color(hex: p.accentHex)
        track = Color(hex: p.seekTrackHex)
        video = Color(hex: p.videoBackgroundHex)
        iconSize = CGFloat(p.toolbarIconSize)
        seekBarHeight = CGFloat(p.seekBarHeight)
    }

    public var dimText: Color { panelText.opacity(0.6) }
    public var separator: Color { panel.isDark ? Color.white.opacity(0.08) : Color.black.opacity(0.12) }
    public var bevelLight: Color { panel.isDark ? Color.white.opacity(0.06) : Color.white.opacity(0.9) }
    public var hover: Color { panel.isDark ? Color.white.opacity(0.08) : Color.black.opacity(0.07) }
}

private struct ThemeKey: EnvironmentKey {
    static let defaultValue = Theme(Preferences())
}

extension EnvironmentValues {
    public var mpcTheme: Theme {
        get { self[ThemeKey.self] }
        set { self[ThemeKey.self] = newValue }
    }
}
