import SwiftUI
import PlayerCore

#if os(macOS)
import AppKit

/// Layer-hosting view whose OpenGL layer mpv renders into (libmpv render API).
/// One instance lives for the whole app (owned by AppModel) so SwiftUI
/// re-renders never give mpv a new, unknown surface.
public final class VideoView: NSView {
    public let renderLayer = MPVOpenGLLayer()
    var onSingleClick: (() -> Void)?
    var onDoubleClick: (() -> Void)?
    var menuProvider: (() -> NSMenu?)?
    var onScroll: ((Int) -> Void)?
    var onDropURLs: (([URL]) -> Void)?
    private var scrollAccumulator: CGFloat = 0

    override init(frame: NSRect) {
        super.init(frame: frame)
        layer = renderLayer
        wantsLayer = true
        layerContentsRedrawPolicy = .duringViewResize
        registerForDraggedTypes([.fileURL])
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    public override var acceptsFirstResponder: Bool { true }
    public override func acceptsFirstMouse(for event: NSEvent?) -> Bool { true }

    public override func viewDidChangeBackingProperties() {
        super.viewDidChangeBackingProperties()
        renderLayer.contentsScale = window?.backingScaleFactor ?? 2
        renderLayer.setNeedsDisplay()
    }

    public override func mouseDown(with event: NSEvent) {
        window?.makeFirstResponder(self)
        if event.clickCount == 2 {
            onDoubleClick?()
        } else if event.clickCount == 1 {
            onSingleClick?()
        }
    }

    public override func rightMouseDown(with event: NSEvent) {
        guard let menu = menuProvider?() else { return }
        NSMenu.popUpContextMenu(menu, with: event, for: self)
    }

    public override func scrollWheel(with event: NSEvent) {
        guard let onScroll else { return }
        let dy = event.hasPreciseScrollingDeltas ? event.scrollingDeltaY / 12 : event.scrollingDeltaY
        scrollAccumulator += dy
        while abs(scrollAccumulator) >= 1 {
            let step = scrollAccumulator > 0 ? 1 : -1
            onScroll(step)
            scrollAccumulator -= CGFloat(step)
        }
    }

    public override func draggingEntered(_ sender: NSDraggingInfo) -> NSDragOperation { .copy }

    public override func performDragOperation(_ sender: NSDraggingInfo) -> Bool {
        let urls = sender.draggingPasteboard.readObjects(forClasses: [NSURL.self], options: [.urlReadingFileURLsOnly: true]) as? [URL] ?? []
        guard !urls.isEmpty else { return false }
        onDropURLs?(urls)
        return true
    }
}

public struct VideoSurface: NSViewRepresentable {
    let model: AppModel
    public init(model: AppModel) { self.model = model }

    public func makeNSView(context: Context) -> VideoView {
        model.ensurePlayerSetup()
        return model.videoView
    }

    public func updateNSView(_ nsView: VideoView, context: Context) {}
}

#else
import UIKit

public final class VideoView: UIView {
    public override class var layerClass: AnyClass { MPVMetalLayer.self }
    public var metalLayer: MPVMetalLayer { layer as! MPVMetalLayer }

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .black
        metalLayer.framebufferOnly = true
        metalLayer.backgroundColor = UIColor.black.cgColor
        isUserInteractionEnabled = false
    }

    required init?(coder: NSCoder) { fatalError("init(coder:) is not supported") }

    public override func layoutSubviews() {
        super.layoutSubviews()
        let scale = window?.screen.nativeScale ?? traitCollection.displayScale
        metalLayer.contentsScale = scale
        metalLayer.drawableSize = CGSize(width: bounds.width * scale, height: bounds.height * scale)
    }
}

public struct VideoSurface: UIViewRepresentable {
    let model: AppModel
    public init(model: AppModel) { self.model = model }

    public func makeUIView(context: Context) -> VideoView {
        model.ensurePlayerSetup()
        return model.videoView
    }

    public func updateUIView(_ uiView: VideoView, context: Context) {}
}
#endif

extension AppModel {
    /// Creates the mpv core on first use, rendering into the shared video view.
    public func ensurePlayerSetup() {
        guard !player.isInitialized else { return }
        #if os(macOS)
        player.setup(renderLayer: videoView.renderLayer, options: initialMPVOptions())
        #else
        player.setup(layer: videoView.metalLayer, options: initialMPVOptions())
        #endif
        markRuntimeApplied()
    }
}
