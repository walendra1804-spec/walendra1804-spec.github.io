# MPC Player (macOS)

A video player for macOS that looks and behaves like MPC-BE (Media Player Classic – Black Edition).
Engine: libmpv via [MPVKit](https://github.com/mpvkit/MPVKit) 1.1.0 (LGPL build, statically linked).
It plays MKV/AVI/WebM/HEVC/AV1 and renders ASS subtitles through libass.

## Features

- MPC-BE layout: seek bar, toolbar with volume wedge, status/info/statistics bars, a docked playlist,
  and View presets (Minimal / Compact / Normal)
- MPC-BE style right-click menu and menu bar (File, Play, Navigate, View, Video, Audio, Subtitles)
- Every hotkey can be remapped (Options › Keys) and conflicts are highlighted
- Options window with OK / Cancel / Apply
  - Player, Playback, Keys, Interface & Theme (presets plus custom colors, with live preview), OSD, Subtitles, Video, Snapshot
- Remembers the playback position for each file, keeps a recent-files list, and adds the rest of the folder to the playlist
- External subtitles load automatically (Indonesian preferred by default)
- A-B repeat, frame stepping, speed control, audio and subtitle delay, pan & scan, zoom, rotation, color controls
- Snapshots in PNG / JPEG / HEIC
- Hardware decoding (VideoToolbox)

## Requirements

- macOS 14 or later, Apple Silicon or Intel
- Swift 5.9+ from the Command Line Tools (`xcode-select --install`). Xcode is not needed.

## Build & run

```bash
scripts/build-macos-app.sh release
open "build/MPC Player.app"
```

The first build downloads the MPVKit binary frameworks (several hundred MB) into `MPCKit/.build`.
The output is `build/MPC Player.app`. To install it, copy it to `/Applications`.

Optionally, make it the default app for video files:

```bash
swift scripts/set-default-player.swift mp4 m4v mov mkv avi webm wmv flv ts m2ts mpg vob 3gp ogv rmvb divx asf
```

## Default keys (MPC-BE layout, Ctrl → ⌘)

| Action | Key |
|---|---|
| Play/Pause | Space, left click |
| Stop | . |
| Jump ±5 s / keyframe | ← → / ⇧← ⇧→ |
| Frame step / back | ⌘→ / ⌘← |
| Speed + / − / reset | ⌘↑ / ⌘↓ / ⌘R |
| Volume / mute | ↑ ↓, wheel / M |
| Next/prev audio, subtitle | A / ⇧A, S / ⇧S, W = subtitle on/off |
| Subtitle delay | F1 / F2 |
| A-B repeat | [ ] , \ clears it |
| Fullscreen | ⌘↩, ⌥↩, double click |
| Panels: seek/controls/info/stats/status/playlist | ⌘1 ⌘2 ⌘3 ⌘4 ⌘5 ⌘7 |
| View minimal/compact/normal | 1 / 2 / 3 |
| Snapshot (auto / save as) | F5 / ⌘F5 |
| Options | O or ⌘, |

## Project layout

```
MPCKit/                    Swift package
  Sources/PlayerCore/      mpv wrapper, OpenGL video layer, preferences, commands/hotkeys, resume history
  Sources/PlayerUI/        SwiftUI chrome (seek bar, toolbar, bars, playlist, OSD, Options) and AppKit glue
  Sources/MPCPlayerMac/    AppKit app entry point and self-test
macOS/Info.plist           App bundle metadata and video/subtitle document types
scripts/                   App build, test-video generator, default-app registration
TestMedia/                 Generated test pattern MP4 with ASS and SRT subtitles
docs/PROBLEM-SOLVING.md    Problems encountered and how they were solved (Indonesian)
```

## How video is drawn

On macOS, mpv renders through the libmpv render API (`vo=libmpv`) into a `CAOpenGLLayer`
(`PlayerCore/MPVOpenGLLayer.swift`), the same approach IINA uses. Every frame is drawn at the layer's
current size, so the picture follows window resizes and layout changes. The earlier `wid` + Vulkan/MoltenVK path
only reads the size when the video reconfigures, which cropped the picture. See
[docs/PROBLEM-SOLVING.md](docs/PROBLEM-SOLVING.md).

## Self-test (no Screen Recording permission needed)

```bash
BIN="build/MPC Player.app/Contents/MacOS/MPCPlayer"
# run commands, then save a composite snapshot
"$BIN" TestMedia/test-pattern.mp4 --perform toggleStats --snapshot /tmp/shot.png --quit-after 8
# one command per second, logging view/layer size vs the size mpv renders at
"$BIN" TestMedia/test-pattern.mp4 --steps start,presetMinimal,togglePlaylist,playPause --quit-after 8
```

Command names are the `PlayerCommand` cases. `--steps` also accepts `set:<mpv-property>=<value>`.

## License notes

MPC-BE (GPL-3.0) was used only as a reference for the UI and features. No code was copied.
libmpv and FFmpeg are LGPL in this build and are linked statically. If you redistribute the binary, the LGPL
requires you to provide the object files or source needed to relink it.
This project's own license has not been chosen yet. Add a `LICENSE` file before publishing.
