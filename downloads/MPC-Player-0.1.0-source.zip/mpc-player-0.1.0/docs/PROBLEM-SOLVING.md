# Catatan Problem Solving

Catatan masalah yang ketemu selama MPC Player dibangun: gejalanya, penyebabnya, cara nemu penyebabnya, dan solusinya.
Urutannya dari yang paling penting.

---

## 1. Ukuran video nggak ngikutin layout (video kepotong)

**Gejala.** Video tampil benar waktu baru dibuka. Begitu layout MPC-BE diganti (preset Minimal/Compact/Normal, buka-tutup
playlist, panel Info/Stats), ukuran area video berubah tapi gambarnya nggak ikut berubah. Hasilnya gambar
kepotong atau posisinya nggak pas dengan area video.

**Cara nemu penyebabnya.**
1. Bikin mode self-test `--steps a,b,c`. Mode ini menjalankan satu perintah per detik, lalu mencatat ukuran view,
   ukuran layer, dan ukuran yang *dipakai mpv* (`osd-dimensions`).
2. Hasilnya: view dan `drawableSize` layer berubah (misalnya jadi 1078×896), tapi `osd-dimensions` mpv
   **tetap 1600×896**, baik saat video jalan maupun di-pause. Jadi mpv nggak pernah tahu ukurannya berubah.
3. Baca source context MoltenVK di MPVKit
   (`Sources/BuildScripts/patch/libmpv/0001-player-add-moltenvk-context.patch`):
   - `moltenvk_reconfig()` baca `layer.drawableSize`, tapi cuma dipanggil waktu *video reconfig* (format video berubah).
   - `moltenvk_control()` cuma `return VO_NOTIMPL`, jadi nggak ada jalur untuk resize.
4. Jalur resize resmi mpv, `VOCTRL_EXTERNAL_RESIZE`, cuma dipicu oleh opsi `android-surface-size` /
   `d3d11-composition-size`. Kedua opsi itu cuma dikompilasi untuk Android/Windows.
5. Akal-akalan seperti mengubah `video-rotate` memang memaksa reconfig, tapi bikin gambar berkedip dan bentrok
   dengan fitur rotate. Jadi nggak dipakai.

**Penyebab.** Mode `wid` + Vulkan/MoltenVK di MPVKit nggak mendukung resize setelah video mulai.

**Solusi.** Di macOS, video sekarang dirender lewat **libmpv render API** (`vo=libmpv`) ke `CAOpenGLLayer`,
cara yang sama dengan IINA (`MPCKit/Sources/PlayerCore/MPVOpenGLLayer.swift`):
- Setiap frame digambar ke framebuffer seukuran layer saat itu, jadi mpv selalu tahu ukuran terbaru.
- Kalau ukuran layer berubah, langsung digambar ulang walaupun video lagi di-pause.
- `MPVPlayer.setup(renderLayer:options:)` dipakai di macOS. Jalur lama `setup(layer:)` (wid) masih ada untuk iOS.
- Peringatan deprecation OpenGL dimatikan pakai `-Xcc -DGL_SILENCE_DEPRECATION` di `Package.swift`.

**Verifikasi.** `--steps` diulang. Ukuran mpv sama dengan ukuran layer di semua kasus: video jalan, pause, preset,
playlist, zoom 50/100/200%, masuk-keluar fullscreen, tutup file, dan keluar aplikasi. Hardware decode
(videotoolbox) tetap aktif.

```bash
MPCKit/.build/debug/MPCPlayer TestMedia/test-pattern.mp4 --steps start,presetMinimal,togglePlaylist,playPause,presetNormal --quit-after 10
```

**Kompromi.** OpenGL di macOS sudah deprecated (tapi masih jalan, IINA juga masih pakai). HDR/EDR penuh
nggak bisa lewat jalur ini.

---

## 2. Snapshot gagal setelah pindah ke render API

**Gejala.** Setelah pindah ke `vo=libmpv`, snapshot (F5) gagal dengan error
`Input image format videotoolbox not supported by libswscale`.

**Penyebab.** Di `vo_libmpv.c`, `VOCTRL_SCREENSHOT` cuma dijalankan di render thread kalau
`MPV_RENDER_PARAM_ADVANCED_CONTROL` aktif. Kalau nggak aktif, mpv mencoba mengonversi frame hardware
(videotoolbox) lewat swscale, dan itu gagal.

**Solusi.** Render context dibuat dengan `ADVANCED_CONTROL = 1`. Konsekuensinya, `mpv_render_context_update()`
*wajib* dipanggil setiap kali callback update datang. Panggilannya ditaruh di render queue (dengan GL context
aktif), bukan di `canDraw`, supaya antrean mpv nggak pernah macet walaupun Core Animation lagi nggak menggambar.
Snapshot dan panel Statistics jalan lagi.

---

## 3. Gambar berkedip / drawable 1×1 di MoltenVK

**Gejala.** Di jalur Vulkan/MoltenVK, gambar kadang berkedip, dan `drawableSize` bisa nyangkut di 1×1.

**Penyebab.** MoltenVK sengaja mengubah `drawableSize` ke 1×1 untuk memaksa presentasi selesai (mpv PR #13651).

**Solusi.** `MPVMetalLayer` (subclass `CAMetalLayer`) menolak ukuran ≤ 1. Ini fix yang sama dengan demo MPVKit.
Sekarang cuma dipakai di jalur iOS.

---

## 4. Jendela nggak muncul waktu file dibuka dari argumen / Finder

**Gejala.** Dengan lifecycle SwiftUI (`App` + `Window` scene), jendela utama nggak pernah muncul kalau aplikasi
dijalankan dengan path file di argv.

**Solusi.** Pindah ke lifecycle AppKit murni: `main.swift` → `AppDelegate` → `NSWindow` berisi
`NSHostingView(MacPlayerView)`, plus menu bar `NSMenu` buatan sendiri. File dari argv dan dari event "open"
(Finder / `open`) ditangani di `AppDelegate`.

Masalah ikutannya, `main.swift` error "main actor-isolated init". Solusinya, semua setup dibungkus
`MainActor.assumeIsolated { ... }`.

---

## 5. Simpan snapshot ke file gagal

**Gejala.** Perintah `screenshot-to-file` mpv gagal: `Could not open libavcodec encoder for saving images`.

**Penyebab.** Build FFmpeg di MPVKit nggak menyertakan encoder gambar (PNG/JPEG).

**Solusi.** Pakai `screenshot-raw` (mpv mengembalikan buffer piksel bgr0), diubah ke `CGImage`, lalu ditulis
lewat ImageIO. Bonusnya bisa simpan ke PNG, JPEG, dan HEIC (`AppModel.saveImage`, `MPVPlayer.screenshotImage`).

---

## 6. Nggak bisa ambil screenshot layar untuk testing

**Gejala.** `screencapture` gagal ("could not create image") karena aplikasi terminal nggak punya izin
Screen Recording. Izin keamanan ini sengaja nggak diubah.

**Solusi.** Self-test dibangun langsung di aplikasinya (`MPCKit/Sources/MPCPlayerMac/SelfTest.swift`):
- `--perform cmd1,cmd2`: jalankan perintah player (nama `PlayerCommand`).
- `--steps a,b,c`: satu perintah per detik, lalu catat geometri video. `set:<properti>=<nilai>` untuk set properti mpv.
- `--snapshot path.png`: gabungkan tampilan SwiftUI dengan frame video dari `screenshot-raw`.
- `--delay N`, `--quit-after N`.

---

## 7. Hotkey: tombol biasa "mencuri" ketikan

**Masalah.** Kalau tombol tanpa modifier (Space, M, A, …) dijadikan key equivalent di menu, tombol itu ikut
tertangkap waktu mengetik di kolom teks (misalnya dialog Go To / Open URL, kotak cari di Options).

**Solusi.**
- Cuma chord ⌘ yang dipasang sebagai key equivalent di menu.
- Tombol lain ditangani oleh `NSEvent` local key monitor di jendela player, yang meneruskan `PlayerCommand`
  dari `KeyMap`. Monitor ini cuma aktif kalau jendela player sedang aktif, dan dilewati kalau fokus ada di
  kolom teks (`NSText`).
- Di editor hotkey, merekam chord ⌘ juga lewat `NSEvent` monitor, supaya nggak keburu dimakan menu.

---

## 8. Jadi aplikasi default untuk file video

**Masalah.** `NSWorkspace.setDefaultApplication(at:toOpen:)` dari skrip nggak berpengaruh apa-apa.

**Solusi.**
- Pakai `LSSetDefaultRoleHandlerForContentType` langsung (`scripts/set-default-player.swift`).
  Untuk mp4, kadang perlu dipanggil dua kali, atau tunggu sebentar sampai LaunchServices menyebarkan perubahannya.
- Format tanpa UTI sistem (mkv, vob, ogv, divx, rmvb, …) didaftarkan lewat `CFBundleDocumentTypes` "Video (other)"
  berbasis ekstensi di `macOS/Info.plist`.

---

## 9. Masalah build dan alat

| Masalah | Penyebab | Solusi |
|---|---|---|
| `XCFramework Info.plist not found` setelah package dipindah ke `MPCKit/` | Cache `.build` lama menunjuk path lama | `rm -rf .build`, lalu build ulang (artefak diambil dari cache SwiftPM) |
| Generator video tes macet | `AVAssetWriter` menunggu interleaving audio/video | Audio ditulis bergantian per frame video (`scripts/make-test-video.swift`) |
| Banjir event `time-pos` dari mpv | Update per frame ke main thread | Event dikuras di queue background, dikirim per batch ke main, `time-pos` dibatasi sekitar 10 Hz |
| Preferensi lama gagal di-decode setelah field baru ditambah | `Codable` ketat | `Preferences.decodeMerged`: JSON lama digabung di atas nilai default |
| Target iOS | Xcode/`simctl` belum terpasang, XcodeGen nggak ada | iOS dihentikan dulu; kode `#if os(iOS)` dibiarkan |

---

## Masalah yang masih terbuka

- **Zoom 200%** pada video besar bisa membuat jendela lebih besar dari layar (belum di-clamp).
- **HDR/EDR** belum didukung di jalur OpenGL.
- **Belum dites dengan input nyata:** tekan tombol fisik, menu klik-kanan, drag & drop, file MKV/AVI asli.
  Semua pengujian di atas lewat self-test.
- **Lisensi:** libmpv/FFmpeg di build ini LGPL dan di-link statis. Kalau binary-nya didistribusikan, wajib sediakan
  object file atau source untuk relink. Lisensi untuk kode proyek ini sendiri belum dipilih.
