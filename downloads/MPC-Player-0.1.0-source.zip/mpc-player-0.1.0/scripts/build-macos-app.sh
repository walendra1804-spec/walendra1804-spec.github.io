#!/bin/zsh
# Builds "MPC Player.app" with SwiftPM (works with just the Command Line Tools).
# Usage: scripts/build-macos-app.sh [debug|release]
set -euo pipefail
ROOT="${0:A:h}/.."
CONFIG="${1:-release}"
cd "$ROOT/MPCKit"
swift build -c "$CONFIG" --product MPCPlayer
BIN="$(swift build -c "$CONFIG" --show-bin-path)/MPCPlayer"
APP="$ROOT/build/MPC Player.app"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp "$BIN" "$APP/Contents/MacOS/MPCPlayer"
cp "$ROOT/macOS/Info.plist" "$APP/Contents/Info.plist"
[[ -f "$ROOT/macOS/AppIcon.icns" ]] && cp "$ROOT/macOS/AppIcon.icns" "$APP/Contents/Resources/"
codesign --force --sign - --timestamp=none "$APP" >/dev/null
echo "Built: $APP"
