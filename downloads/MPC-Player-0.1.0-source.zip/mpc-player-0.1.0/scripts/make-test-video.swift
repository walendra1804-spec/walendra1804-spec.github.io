// Generates TestMedia/test-pattern.mp4 (20 s, 1280x720 H.264 + AAC tone) without ffmpeg.
// Usage: swift scripts/make-test-video.swift TestMedia/test-pattern.mp4
import AVFoundation
import CoreGraphics
import CoreText
import Foundation

let out = URL(fileURLWithPath: CommandLine.arguments[1])
let seconds = 20, fps = 30, W = 1280, H = 720
try? FileManager.default.removeItem(at: out)
let writer = try AVAssetWriter(outputURL: out, fileType: .mp4)
let vIn = AVAssetWriterInput(mediaType: .video, outputSettings: [
    AVVideoCodecKey: AVVideoCodecType.h264, AVVideoWidthKey: W, AVVideoHeightKey: H])
let adaptor = AVAssetWriterInputPixelBufferAdaptor(assetWriterInput: vIn, sourcePixelBufferAttributes: [
    kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32BGRA, kCVPixelBufferWidthKey as String: W, kCVPixelBufferHeightKey as String: H])
let sampleRate = 48000.0
let aIn = AVAssetWriterInput(mediaType: .audio, outputSettings: [
    AVFormatIDKey: kAudioFormatMPEG4AAC, AVSampleRateKey: sampleRate, AVNumberOfChannelsKey: 2, AVEncoderBitRateKey: 128000])
writer.add(vIn); writer.add(aIn)
writer.startWriting(); writer.startSession(atSourceTime: .zero)

func drawText(_ ctx: CGContext, _ s: String, x: CGFloat, y: CGFloat, size: CGFloat) {
    let font = CTFontCreateWithName("Helvetica-Bold" as CFString, size, nil)
    let attr = NSAttributedString(string: s, attributes: [kCTFontAttributeName as NSAttributedString.Key: font,
        kCTForegroundColorAttributeName as NSAttributedString.Key: CGColor(red: 1, green: 1, blue: 1, alpha: 1)])
    let line = CTLineCreateWithAttributedString(attr)
    ctx.textPosition = CGPoint(x: x, y: y)
    CTLineDraw(line, ctx)
}

// Audio: 440 Hz tone with a 880 Hz beep at the start of every second.
var fmt = AudioStreamBasicDescription(mSampleRate: sampleRate, mFormatID: kAudioFormatLinearPCM,
    mFormatFlags: kAudioFormatFlagIsSignedInteger | kAudioFormatFlagIsPacked, mBytesPerPacket: 4, mFramesPerPacket: 1,
    mBytesPerFrame: 4, mChannelsPerFrame: 2, mBitsPerChannel: 16, mReserved: 0)
var fdesc: CMAudioFormatDescription?
CMAudioFormatDescriptionCreate(allocator: nil, asbd: &fmt, layoutSize: 0, layout: nil, magicCookieSize: 0, magicCookie: nil, extensions: nil, formatDescriptionOut: &fdesc)
let chunk = 4800
var frame = 0
let total = Int(sampleRate) * seconds
func writeAudio(until limit: Int) {
 while frame < min(limit, total) {
    while !aIn.isReadyForMoreMediaData { usleep(1000) }
    let n = min(chunk, total - frame)
    var samples = [Int16](repeating: 0, count: n * 2)
    for i in 0..<n {
        let ts = Double(frame + i) / sampleRate
        let beep = ts.truncatingRemainder(dividingBy: 1) < 0.1
        let v = Int16(sin(2 * .pi * (beep ? 880 : 440) * ts) * (beep ? 9000 : 2500))
        samples[i * 2] = v; samples[i * 2 + 1] = v
    }
    var block: CMBlockBuffer?
    let bytes = n * 4
    CMBlockBufferCreateWithMemoryBlock(allocator: nil, memoryBlock: nil, blockLength: bytes, blockAllocator: nil, customBlockSource: nil, offsetToData: 0, dataLength: bytes, flags: 0, blockBufferOut: &block)
    samples.withUnsafeBytes { CMBlockBufferReplaceDataBytes(with: $0.baseAddress!, blockBuffer: block!, offsetIntoDestination: 0, dataLength: bytes) }
    var sb: CMSampleBuffer?
    CMAudioSampleBufferCreateReadyWithPacketDescriptions(allocator: nil, dataBuffer: block!, formatDescription: fdesc!, sampleCount: n, presentationTimeStamp: CMTime(value: CMTimeValue(frame), timescale: CMTimeScale(sampleRate)), packetDescriptions: nil, sampleBufferOut: &sb)
    aIn.append(sb!)
    frame += n
}
}
let colors: [(CGFloat, CGFloat, CGFloat)] = [(0.75,0.75,0.75),(0.75,0.75,0),(0,0.75,0.75),(0,0.75,0),(0.75,0,0.75),(0.75,0,0),(0,0,0.75)]
for f in 0..<(seconds * fps) {
    writeAudio(until: Int(Double(f + 1) / Double(fps) * sampleRate))
    while !vIn.isReadyForMoreMediaData { usleep(1000) }
    var pb: CVPixelBuffer?
    CVPixelBufferPoolCreatePixelBuffer(nil, adaptor.pixelBufferPool!, &pb)
    let buf = pb!
    CVPixelBufferLockBaseAddress(buf, [])
    let ctx = CGContext(data: CVPixelBufferGetBaseAddress(buf), width: W, height: H, bitsPerComponent: 8,
                        bytesPerRow: CVPixelBufferGetBytesPerRow(buf), space: CGColorSpaceCreateDeviceRGB(),
                        bitmapInfo: CGImageAlphaInfo.premultipliedFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue)!
    let bw = CGFloat(W) / 7
    for (i, c) in colors.enumerated() {
        ctx.setFillColor(red: c.0, green: c.1, blue: c.2, alpha: 1)
        ctx.fill(CGRect(x: CGFloat(i) * bw, y: CGFloat(H) * 0.35, width: bw, height: CGFloat(H) * 0.65))
    }
    ctx.setFillColor(red: 0.08, green: 0.08, blue: 0.1, alpha: 1)
    ctx.fill(CGRect(x: 0, y: 0, width: W, height: Int(Double(H) * 0.35)))
    // moving box
    let t = Double(f) / Double(fps)
    ctx.setFillColor(red: 1, green: 0.55, blue: 0.1, alpha: 1)
    ctx.fill(CGRect(x: CGFloat(t / Double(seconds)) * CGFloat(W - 80), y: 150, width: 80, height: 80))
    let ms = Int(t * 1000)
    drawText(ctx, String(format: "%02d:%02d.%03d  frame %03d", ms / 60000, (ms / 1000) % 60, ms % 1000, f), x: 40, y: 40, size: 56)
    drawText(ctx, "MPC Player test pattern", x: 40, y: CGFloat(H) - 80, size: 40)
    CVPixelBufferUnlockBaseAddress(buf, [])
    adaptor.append(buf, withPresentationTime: CMTime(value: CMTimeValue(f), timescale: CMTimeScale(fps)))
}
vIn.markAsFinished()
writeAudio(until: total)

aIn.markAsFinished()
let sem = DispatchSemaphore(value: 0)
writer.finishWriting { sem.signal() }
sem.wait()
print(writer.status == .completed ? "ok \(out.path)" : "failed \(String(describing: writer.error))")
