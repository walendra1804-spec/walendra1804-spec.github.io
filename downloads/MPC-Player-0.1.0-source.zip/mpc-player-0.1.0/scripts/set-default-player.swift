// Makes MPC Player the default app for the given file extensions (LaunchServices).
// Usage: swift scripts/set-default-player.swift mp4 m4v mov mkv avi webm wmv flv ts m2ts mpg vob 3gp ogv rmvb divx asf
// NSWorkspace.setDefaultApplication(at:toOpen:) did not take effect from a script, so this
// uses LSSetDefaultRoleHandlerForContentType directly. Finder may need a moment to pick it up.
import CoreServices
import UniformTypeIdentifiers

let bundleID = "com.walendra.mpcplayer"
var seen = Set<String>()
for ext in CommandLine.arguments.dropFirst() {
    guard let type = UTType(filenameExtension: ext), seen.insert(type.identifier).inserted else { continue }
    let rc = LSSetDefaultRoleHandlerForContentType(type.identifier as CFString, .all, bundleID as CFString)
    print(ext, type.identifier, rc == noErr ? "ok" : "error \(rc)")
}
