# Terabox Downloader (MVP)

Program terminal untuk membaca seluruh isi link share Terabox (folder, subfolder, file) lalu men-download-nya.
Hanya butuh Python 3, tanpa `pip install`.

## Cara pakai

Mode interaktif (paste link, pilih nomor file, pilih folder tujuan):

```bash
python3 terabox.py
```

Lihat isi link saja (rekursif sampai subfolder terdalam):

```bash
python3 terabox.py list "https://1024terabox.com/s/LINK_KAMU"
```

Download semua file tanpa konfirmasi:

```bash
python3 terabox.py download "https://1024terabox.com/s/LINK_KAMU" -y
```

Download sebagian file saja (nomor sesuai hasil `list`), ke folder tertentu:

```bash
python3 terabox.py download "https://1024terabox.com/s/LINK_KAMU" --only "1,3,5-8" -o ~/Movies/terabox
```

- Struktur folder dari Terabox dipertahankan di dalam folder `downloads/`.
- Download yang terputus (Ctrl+C / koneksi putus) disimpan sebagai `.part` dan **dilanjutkan** saat dijalankan ulang.
- File yang sudah lengkap otomatis di-skip.

## Simpan & streaming (tanpa download)

Simpan "link stream" ke Perpustakaan. Yang disimpan cuma teks kecil, bukan isi file:

```bash
python3 terabox.py save "https://1024terabox.com/s/LINK_KAMU"
```

Setiap file menjadi `Perpustakaan/<folder asli>/<nama file>.tblink`. Isinya link share + ID file,
**bukan** link unduhan langsung (yang itu kedaluwarsa sekitar 1 jam). Link segar diminta otomatis setiap kali diputar.

Putar dari Perpustakaan:

```bash
python3 terabox.py library
```

Atau putar langsung dari link tanpa menyimpan:

```bash
python3 terabox.py play "https://1024terabox.com/s/LINK_KAMU"
```

Program menjalankan server streaming kecil di `127.0.0.1` dan membuka player di browser.
Fitur lompat/seek berfungsi. Tekan Ctrl+C untuk berhenti.

- **Video** diputar lewat streaming HLS resmi Terabox, jalur yang sama dengan player di web mereka.
  Video sudah diubah Terabox ke H.264, jadi `.mkv` dan format lain juga bisa diputar.
  Kualitas default 720p dan otomatis turun ke 480p/360p kalau tidak tersedia. Bisa dipilih manual:
  `play <link> --kualitas 480`. **Butuh cookie login.**
- **Audio dan file lain** diputar dari file aslinya. Kalau gagal, audio otomatis pindah ke HLS.
- Alamat "Langsung" yang ditampilkan bisa dibuka di VLC/IINA/mpv.

## Cookie (kalau download ditolak)

Menampilkan isi folder selalu bisa tanpa login. Untuk download, Terabox mengizinkan sebagian file
diunduh tamu, tapi file lain ditolak dengan pesan `butuh cookie login Terabox (ndus)`.
Kalau itu terjadi:

1. Login ke https://www.terabox.app di browser (akun gratis cukup). Pakai domain `terabox.app`, karena program juga memakai domain itu.
2. Buka DevTools (Safari: Option+Command+I, Chrome: F12), lalu tab Penyimpanan/Storage, lalu Cookie, lalu `www.terabox.app`.
3. Salin nilai cookie bernama `ndus`.
4. Simpan dengan salah satu cara berikut:
   - buat file `cookie.txt` di folder ini berisi `ndus=NILAI_KAMU`, atau
   - `export TERABOX_COOKIE="ndus=NILAI_KAMU"`, atau
   - tambahkan `--cookie "ndus=NILAI_KAMU"` di perintah.

> `ndus` sama dengan sesi login akunmu. Jangan dibagikan ke siapa pun.

## Error `400141 need verify`

Ini pembatasan anti-bot dari Terabox yang sifatnya sementara, dan bisa muncul kalau request terlalu sering.
Program otomatis mencoba ulang. Kalau daftar folder tetap ditolak, program memakai data folder utama
dari `shorturlinfo` atau mencoba sebagai tamu. Kalau masih gagal, tunggu beberapa menit lalu coba lagi.

## Cara kerja singkat

1. Buka halaman share untuk mendapatkan cookie sesi dan `jsToken`.
2. `/api/shorturlinfo` mengembalikan `shareid`, `uk`, `sign`, `timestamp`, dan `randsk`.
3. `/share/list` dipanggil rekursif per folder (dengan paging) untuk membangun daftar file.
4. `/api/sharedownload` mengembalikan `dlink` per file (berlaku sekitar 1 jam, diminta tepat sebelum tiap file diunduh).
5. File diunduh lewat `dlink` dengan Range/resume.

## Aplikasi Mac: Terabox Stream

Versi aplikasi dari program ini ada di folder `TeraboxStream/`. Isinya sama dengan CLI
(lihat isi link, Simpan ke Perpustakaan, Unduh, dan putar), tapi semuanya di satu jendela.

![Isi link](docs/tree.png)

### Cara build

Butuh Xcode 26 dan macOS 26. Jalankan di Terminal dari folder ini:

```bash
cd TeraboxStream && xcodebuild -project TeraboxStream.xcodeproj -scheme TeraboxStream -configuration Release -derivedDataPath build/DerivedData build
```

Hasilnya: `TeraboxStream/build/DerivedData/Build/Products/Release/Terabox Stream.app`.

### Cara buka

```bash
open "TeraboxStream/build/DerivedData/Build/Products/Release/Terabox Stream.app"
```

Supaya gampang, seret `Terabox Stream.app` dari Finder ke folder Aplikasi (Applications) atau ke Dock.
Proyek ini juga bisa dibuka di Xcode (`TeraboxStream/TeraboxStream.xcodeproj`), lalu tekan ⌘R.

### Cara pakai

- **Buka link:** tempel link share di kolom atas, lalu tekan Return (atau ⇧⌘V untuk langsung membuka link dari papan klip).
  Semua folder dan subfolder tampil sebagai pohon. Link berkode akses akan meminta kodenya.
- **Putar:** klik dua kali file di daftar. Video diputar lewat HLS Terabox, dan kualitasnya bisa dipilih di toolbar
  atau di menu Pemutaran. Spasi untuk putar/jeda, ⌘← dan ⌘→ untuk lompat 10 detik.
- **Grid dan thumbnail:** tombol Daftar/Grid di toolbar (atau ⌘1 dan ⌘2) mengganti tampilan isi link.
  Di grid, file dikelompokkan per folder, dan gambar serta video tampil dengan thumbnail dari Terabox.
  Arahkan kursor ke video dan diamkan sebentar: video diputar tanpa suara, 4 detik di 1/5, 2/5, 3/5, dan 4/5 durasinya,
  lalu 4 detik terakhir, kemudian kembali ke 1/5. Pratinjau ini di-stream (resolusi 360p), tidak diunduh.
- **Centang dan unduh dari Perpustakaan:** di halaman Perpustakaan (daftar atau grid), klik kartu atau kotak
  centangnya untuk mencentang file; folder juga bisa dicentang (artinya semua isinya). Kotak "Pilih semua" di
  bawah mencentang semuanya, lalu klik Unduh (⌘D) atau Unduh ke… (⌘⌥D). Klik dua kali kartu tetap memutarnya.
  Klik "Semua yang Disimpan" atau sebuah folder di Perpustakaan untuk melihat item yang disimpan sebagai grid juga.
  Thumbnail disimpan di `~/Library/Caches/com.walendra.TeraboxStream`, jadi cukup diambil sekali.
- **Simpan (⌘S):** menulis file `.tblink` ke Perpustakaan. Formatnya sama persis dengan `python3 terabox.py save`,
  jadi aplikasi dan CLI bisa berbagi Perpustakaan yang sama. Default aplikasi: `~/Terabox Stream/Perpustakaan`; CLI: folder `Perpustakaan/` di sebelah `terabox.py`. Samakan lewat Pengaturan (⌘,).
  Klik item di sidebar Perpustakaan untuk langsung memutarnya. File `.tblink` juga bisa dibuka dengan klik dua kali di Finder.
- **Unduh (⌘D, atau ⌥⌘D untuk memilih folder):** file diunduh satu per satu dengan progres, bisa dihentikan
  dan dilanjutkan (resume dari `.part`). Folder tujuan default `~/Downloads/Terabox`. Ini bisa diganti di Pengaturan (⌘,).
- **Akun:** menu Akun, lalu Masuk ke Terabox, untuk login di dalam aplikasi. Bisa juga lewat Akun, lalu Impor cookie.txt.
  Cookie disimpan di Keychain dan tidak pernah ditampilkan. Keluar dari Akun menghapusnya.

### Cara kerja streaming di aplikasi

Sama seperti CLI: aplikasi menjalankan server kecil di `127.0.0.1` khusus untuk pemutar (AVPlayer).
Server ini menyisipkan cookie, meminta link baru kalau yang lama kedaluwarsa, dan meneruskan Range untuk seek.
Audio yang ternyata berformat MP4 DASH (misalnya hasil unduhan YouTube yang diberi nama `.mp3`) tidak bisa di-seek,
jadi aplikasi otomatis memutar versi HLS MP3 dari Terabox.

## Rencana berikutnya

- Putar satu folder sebagai playlist.
- Download paralel beberapa file sekaligus.
