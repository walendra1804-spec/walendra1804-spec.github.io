# Terabox Stream

A native macOS app (SwiftUI) and a small Python script for Terabox share links:

- open a share link and see every folder and file, as a tree or a grid with thumbnails;
- stream video and audio inside the app, with seeking, and preview videos by hovering;
- save links as tiny `.tblink` files to stream later, instead of downloading;
- download with resume, one file at a time, keeping the folder structure.

The full story of how it was built, including every problem we hit and how it was solved, is in the article:
https://walendra1804-spec.github.io/2026/11/07/terabox-stream-a-native-mac-app-for-terabox-share-links/

Bahasa Indonesia: see [README.id.md](README.id.md). The app's interface is in Indonesian.

![The app showing a test share as a file tree](docs/tree.png)

> Unofficial. Not affiliated with Terabox. It uses the same web API as Terabox's website, as it was in November 2026, so it can break when Terabox changes it. Use it for files you are allowed to access. Your `ndus` cookie is your login session: never share it.

## What's in here

| Path | What it is |
|---|---|
| `TeraboxStream/` | The Mac app. Xcode project, `Sources/Core` (Terabox API, local stream server, `.tblink` format), `Sources/App` (state, player, downloads, self-test), `Sources/UI` (SwiftUI views) |
| `terabox.py` | The command-line version. Python 3 standard library only. Shares the `.tblink` format with the app |
| `README.id.md` | The original Indonesian README, with more detail on the CLI and on getting a cookie by hand |

## The Mac app

### Requirements

macOS 26 or later. To build: Xcode 26.

### Build and run

```bash
cd TeraboxStream
xcodebuild -project TeraboxStream.xcodeproj -scheme TeraboxStream \
  -configuration Release -derivedDataPath build/DerivedData build
open "build/DerivedData/Build/Products/Release/Terabox Stream.app"
```

The project is signed ad hoc (`CODE_SIGN_IDENTITY = "-"`), so it builds without an Apple developer account. If you set your own team and a development certificate, macOS stops asking for Keychain access after each rebuild.

### Using it

| Task | How |
|---|---|
| Open a share | Paste the link in the top field and press Return. ⇧⌘V opens the link on the clipboard. Access codes are asked for, or read from `?pwd=` |
| List or grid | Toolbar control, ⌘1 / ⌘2 |
| Play | Double-click a file. ‹ or ⌘[ goes back to the same scroll position |
| Hover preview | Rest the pointer on a video card: 4 s at 1/5, 2/5, 3/5, 4/5, the last 4 s, then loop. Videos under 20 s loop whole |
| Video quality | Toolbar menu, or Pemutaran › Kualitas Video. Automatic tries 720p, then 480p, then 360p |
| Save to library | ⌘S. Writes `.tblink` files to the library (default `~/Terabox Stream/Perpustakaan`, changeable in Settings) |
| Tick and download from the library | Click cards or checkboxes, "Pilih semua" selects all, then Unduh (⌘D) or Unduh ke… (⌥⌘D) |
| Download from a share | Select files (or none for all), then ⌘D. Default folder `~/Downloads/Terabox`. Resumes from `.part`, skips complete files |
| Log in | Akun › Masuk ke Terabox. Only the `ndus` cookie is kept, in the Keychain. Akun › Impor cookie.txt also works. Akun › Keluar removes it |

Browsing works without logging in. Some files refuse to download or stream as a guest (errno 31045 "user not exists"). HLS video needs a login.

### How playback works

AVPlayer plays from a small HTTP server inside the app, bound to `127.0.0.1`. The server adds the cookies and the `Referer` header Terabox needs, renews download links that expired (they last about an hour), passes Range requests through for seeking, and rewrites HLS playlists so their segments go through it as well.

- **Video:** Terabox's HLS (`M3U8_AUTO_720`, then 480, then 360; 720 returned errno 130 for our account), or the original file. Before using HLS, the app checks that the playlist is complete and as long as the original file. If not, it plays the original file.
- **Audio:** the original file. If the file is really fragmented MP4 (common for "MP3s" saved from YouTube), AVPlayer can't seek in it, so the app uses Terabox's `M3U8_MP3_128` instead.

### Self-test

The app has a built-in test mode that runs the real app against a real share link, mutes audio and writes a report:

```bash
SELFTEST_LINK="https://1024terabox.com/s/XXXXXXXX" SELFTEST_REPORT=/tmp/report.txt \
SELFTEST_LIBRARY=/tmp/lib SELFTEST_DOWNLOADS=/tmp/dl SELFTEST_QUIT=1 \
"build/DerivedData/Build/Products/Release/Terabox Stream.app/Contents/MacOS/Terabox Stream" -selftest
```

`SELFTEST_STEPS` picks the steps (default `tree,save,download,play,hls,livp`; also `thumbs`, `grid`, `range`, `preview`, `libdl`, `back`, `keychain`, `login`, `ui`). The report ends with `SELESAI gagal=0` when nothing failed. See `Sources/App/SelfTest.swift`. Keep runs small: Terabox answers bursts of requests with errno 400141 "need verify".

## The command-line script

```bash
python3 terabox.py                      # interactive: paste a link, pick files, pick a folder
python3 terabox.py list <link>          # list everything, recursively
python3 terabox.py download <link> -y   # download all (-o DIR, --only "1,3,5-8")
python3 terabox.py save <link>          # save .tblink files to Perpustakaan/ next to the script
python3 terabox.py play <link | file.tblink>   # stream through a local server, in the browser
python3 terabox.py library              # pick and play from Perpustakaan/
```

Cookie, if a file is refused: `--cookie "ndus=..."`, the `TERABOX_COOKIE` environment variable, or a `cookie.txt` file next to the script containing `ndus=...`. `--pwd` gives an access code. `--kualitas 480` picks the video quality.

## The `.tblink` format

One JSON file per saved item. It stores the permanent address of the file, never a download link:

```json
{
  "type": "terabox-stream",
  "version": 1,
  "name": "video.mp4",
  "path": "Folder/Sub/video.mp4",
  "size": 123456789,
  "md5": "…",
  "category": 1,
  "fs_id": 123456789012345,
  "share_link": "https://1024terabox.com/s/XXXXXXXX",
  "pwd": "",
  "shareid": 0,
  "uk": 0,
  "saved_at": "2026-11-07T12:00:00+00:00"
}
```

The app and the script write it byte for byte the same way (key order, two-space indent, non-ASCII kept as is). The access code, if any, is stored in plain text.

## License

MIT. See [LICENSE](LICENSE). Written by Panca Walendra Putra with Claude Opus 5.5 (Anthropic).
