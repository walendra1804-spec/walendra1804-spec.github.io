import AppKit
import Foundation
import Observation

enum SidebarItem: Hashable {
    case share
    case downloads
    case nowPlaying
    case library(URL)
    case libraryFolder(URL)

    /// Pemutar menutupi halaman; halaman lain (isi link, unduhan, grid) adalah "halaman".
    var isPlayer: Bool {
        switch self {
        case .nowPlaying, .library: true
        default: false
        }
    }
}

@Observable @MainActor
final class AppModel {
    let account = AccountStore()
    let library: LibraryStore
    let downloads = DownloadManager()
    let player = PlayerController()
    let preview = PreviewPlayer()

    var linkText = ""
    private(set) var browser: ShareBrowser?
    var sidebar: SidebarItem? = .share {
        didSet {
            if let sidebar, !sidebar.isPlayer, page != sidebar { page = sidebar }
        }
    }
    /// Halaman terakhir sebelum pemutar dibuka. Halaman ini tetap hidup di bawah
    /// pemutar, jadi Kembali memulihkan posisi scroll, pilihan, dan folder yang terbuka.
    private(set) var page: SidebarItem = .share

    var isShowingPlayer: Bool { sidebar?.isPlayer ?? false }

    func goBack() {
        guard isShowingPlayer else { return }
        sidebar = page
    }
    var showInspector = false
    var showLogin = false
    var showPasswordSheet = false
    var errorMessage: String?
    private(set) var notice: String?
    var linkFieldFocusRequest = 0
    @ObservationIgnored private var noticeTask: Task<Void, Never>?

    init(libraryOverride: URL? = nil) {
        library = LibraryStore(override: libraryOverride)
        player.cookieProvider = { [account] in account.cookie }
        preview.shareResolver = { [weak self] link, pwd in
            guard let self else { throw CancellationError() }
            return try await self.share(for: link, pwd: pwd)
        }
    }

    /// Share yang sedang dibuka di jendela, atau yang tersimpan di pemutar.
    func share(for link: String, pwd: String?) async throws -> TeraboxShare {
        if let browser, browser.link == link, browser.phase == .loaded { return browser.share }
        return try await player.share(for: link, pwd: pwd)
    }

    // MARK: Thumbnail

    func thumbnailLoader(_ node: FileNode, in share: TeraboxShare) -> Thumbnails.Loader? {
        guard let url = node.thumb else { return nil }
        return { try await share.thumbnailData(url) }
    }

    /// File .tblink tidak menyimpan thumbnail, jadi alamatnya dicari dari share-nya
    /// (sekali per folder). Hanya untuk gambar dan video.
    func thumbnailLoader(_ entry: LinkEntry) -> Thumbnails.Loader? {
        let kind = FileKinds.kind(name: entry.name, category: entry.category ?? 0)
        guard kind == .video || kind == .image || entry.category == 3 else { return nil }  // 3 = foto, termasuk Live Photo
        return { [weak self] in
            guard let self else { return nil }
            let share = try await self.share(for: entry.shareLink, pwd: entry.pwd)
            guard let url = try await share.thumbnailURL(rel: entry.path, fsId: entry.fsId) else { return nil }
            return try await share.thumbnailData(url)
        }
    }

    // MARK: Link

    func openLink(_ raw: String? = nil) {
        let text = (raw ?? linkText).trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        let share: TeraboxShare
        do {
            share = try TeraboxShare(link: text, cookie: account.cookie)
        } catch {
            errorMessage = error.localizedDescription
            return
        }
        browser?.cancel()
        linkText = text
        let b = ShareBrowser(link: text, share: share)
        browser = b
        sidebar = .share
        b.load()
    }

    func openFromClipboard() {
        guard let text = NSPasteboard.general.string(forType: .string) else { return }
        openLink(text)
    }

    var clipboardHasLink: Bool {
        guard let text = NSPasteboard.general.string(forType: .string) else { return false }
        return (try? TeraboxShare.parseShortURL(text)) != nil && text.count < 500
    }

    func retryBrowser() {
        if let browser { openLink(browser.link) }
    }

    func requestLinkFocus() {
        linkFieldFocusRequest += 1
    }

    // MARK: Aksi pada file

    var canActOnShare: Bool {
        browser?.phase == .loaded && !(browser?.allFiles.isEmpty ?? true)
    }

    @discardableResult
    func saveToLibrary(_ files: [ShareFile]? = nil) -> Int {
        guard let browser, let summary = browser.summary else { return 0 }
        let files = files ?? browser.targetFiles
        guard !files.isEmpty else { return 0 }
        do {
            let saved = try library.save(files, link: browser.link, pwd: browser.pwd, summary: summary)
            show(notice: saved.count == 1 ? "Tersimpan di Perpustakaan" : "\(saved.count) item tersimpan di Perpustakaan")
            return saved.count
        } catch {
            errorMessage = "Gagal menyimpan ke Perpustakaan: \(error.localizedDescription)"
            return 0
        }
    }

    func download(_ files: [ShareFile]? = nil, choosingFolder: Bool = false) {
        guard let browser else { return }
        let files = files ?? browser.targetFiles
        guard !files.isEmpty else { return }
        var folder = downloads.folder
        if choosingFolder {
            guard let picked = FolderPanel.choose(title: "Pilih folder tujuan unduhan", prompt: "Unduh ke Sini",
                                                  startingAt: folder) else { return }
            folder = picked
        }
        let added = downloads.enqueue(files, from: browser.share, to: folder)
        if added > 0 {
            show(notice: added == 1 ? "1 file masuk antrean unduhan" : "\(added) file masuk antrean unduhan")
        }
    }

    /// Unduh file dari Perpustakaan (item atau folder yang dicentang). Link share-nya
    /// dibuka sekali per link, lalu file masuk antrean yang sama dengan unduhan biasa.
    func downloadLibrary(_ urls: Set<URL>, choosingFolder: Bool = false) {
        let entries = library.entries(in: urls)
        guard !entries.isEmpty else { return }
        var folder = downloads.folder
        if choosingFolder {
            guard let picked = FolderPanel.choose(title: "Pilih folder tujuan unduhan", prompt: "Unduh ke Sini",
                                                  startingAt: folder) else { return }
            folder = picked
        }
        var links: [String] = []
        var byLink: [String: [LinkEntry]] = [:]
        for e in entries {
            if byLink[e.shareLink] == nil { links.append(e.shareLink) }
            byLink[e.shareLink, default: []].append(e)
        }
        show(notice: links.count == 1 ? "Membuka link…" : "Membuka \(links.count) link…")
        Task {
            var added = 0
            var failed: [String] = []
            for link in links {
                let list = byLink[link] ?? []
                do {
                    let share = try await share(for: link, pwd: list.first?.pwd)
                    added += downloads.enqueue(list.map(\.file), from: share, to: folder)
                } catch {
                    failed.append("\(list.count) file: \(error.localizedDescription)")
                }
            }
            if added > 0 {
                show(notice: added == 1 ? "1 file masuk antrean unduhan" : "\(added) file masuk antrean unduhan")
            } else if failed.isEmpty {
                show(notice: "Semua file itu sudah ada di antrean")
            }
            if !failed.isEmpty {
                errorMessage = "Sebagian file tidak bisa diunduh.\n" + failed.joined(separator: "\n")
            }
        }
    }

    var isLibraryPage: Bool {
        if case .libraryFolder = page, !isShowingPlayer { return true }
        return false
    }

    /// Unduh dari menu (⌘D): file yang dicentang di Perpustakaan, atau isi link yang dibuka.
    var canDownloadCurrent: Bool {
        isLibraryPage ? !library.checked.isEmpty : canActOnShare
    }

    func downloadCurrent(choosingFolder: Bool = false) {
        if isLibraryPage {
            downloadLibrary(library.checked, choosingFolder: choosingFolder)
        } else {
            download(choosingFolder: choosingFolder)
        }
    }

    func play(_ file: ShareFile) {
        guard let browser else { return }
        player.play(file, link: browser.link, pwd: browser.pwd, share: browser.share)
        sidebar = .nowPlaying
    }

    func playLibraryItem(_ url: URL) {
        guard let entry = library.entry(at: url) ?? (try? LinkEntry.read(url)) else {
            errorMessage = "File \(url.lastPathComponent) tidak bisa dibaca."
            return
        }
        player.play(entry.file, link: entry.shareLink, pwd: entry.pwd, libraryURL: url,
                    share: browser?.link == entry.shareLink ? browser?.share : nil)
    }

    /// Dipanggil saat file .tblink dibuka dari Finder.
    func open(fileURL url: URL) {
        guard url.pathExtension == linkExtension else { return }
        sidebar = .library(url)
        playLibraryItem(url)
    }

    // MARK: Akun

    func importCookieFile() {
        let start = URL.downloadsDirectory
        guard let url = FilePanel.chooseFile(title: "Pilih cookie.txt", startingAt: start) else { return }
        do {
            try account.importFile(url)
            accountChanged()
            show(notice: "Cookie tersimpan di Keychain")
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func finishLogin(cookie: String) {
        do {
            try account.store(cookie)
            showLogin = false
            accountChanged()
            show(notice: "Berhasil masuk ke Terabox")
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    func signOut() {
        account.signOut()
        accountChanged()
    }

    private func accountChanged() {
        player.forgetShares()
        preview.stop()
        preview.forgetSources()
        if let browser, browser.phase != .loaded { openLink(browser.link) }
    }

    // MARK: Pemberitahuan singkat

    func show(notice text: String) {
        notice = text
        noticeTask?.cancel()
        noticeTask = Task { [weak self] in
            try? await Task.sleep(for: .seconds(4))
            guard !Task.isCancelled else { return }
            self?.notice = nil
        }
    }
}
