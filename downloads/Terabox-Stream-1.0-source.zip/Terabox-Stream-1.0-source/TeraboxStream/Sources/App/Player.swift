import AVFoundation
import Foundation
import Observation

/// Pemutar di dalam aplikasi. Semua media diputar AVPlayer dari server lokal
/// 127.0.0.1 (lihat StreamServer), persis seperti alur CLI yang sudah teruji.
@Observable @MainActor
final class PlayerController {
    struct Current: Equatable {
        let file: ShareFile
        let link: String
        let pwd: String?
        let libraryURL: URL?
        var kind: MediaKind { FileKinds.kind(name: file.name, category: file.category) }
        var folderPath: String {
            let parts = file.rel.split(separator: "/")
            return parts.dropLast().joined(separator: " / ")
        }
    }

    enum Phase: Equatable {
        case idle
        case loading(String)
        case ready
        case failed(String, needsLogin: Bool)
        case unsupported
    }

    private(set) var current: Current?
    private(set) var phase: Phase = .idle
    private(set) var sourceLabel = ""
    private(set) var mediaURL: URL?
    private(set) var isPlaying = false
    var quality: VideoQuality = VideoQuality(rawValue: UserDefaults.standard.integer(forKey: "videoQuality")) ?? .automatic {
        didSet {
            UserDefaults.standard.set(quality.rawValue, forKey: "videoQuality")
            if oldValue != quality, current?.kind == .video { reload() }
        }
    }

    @ObservationIgnored let player = AVPlayer()
    @ObservationIgnored var cookieProvider: () -> String? = { nil }
    @ObservationIgnored var forceHLSForAudio = false
    @ObservationIgnored private var task: Task<Void, Never>?
    @ObservationIgnored private var token: String?
    @ObservationIgnored private var statusObservation: NSKeyValueObservation?
    @ObservationIgnored private var rateObservation: NSKeyValueObservation?
    @ObservationIgnored private var shares: [String: (task: Task<TeraboxShare, Error>, openedAt: Date)] = [:]

    init() {
        rateObservation = player.observe(\.timeControlStatus, options: [.new]) { [weak self] player, _ in
            let playing = player.timeControlStatus != .paused
            DispatchQueue.main.async { self?.isPlaying = playing }
        }
    }

    /// Simpan share yang sudah dibuka supaya memutar file dari link yang sama
    /// tidak membuka halaman share lagi (hemat request).
    func remember(_ share: TeraboxShare) {
        shares[share.link] = (Task { share }, .now)
    }

    /// Lupakan share yang tersimpan (mis. setelah ganti akun).
    func forgetShares() {
        shares.removeAll()
    }

    func play(_ file: ShareFile, link: String, pwd: String?, libraryURL: URL? = nil, share: TeraboxShare? = nil) {
        if let share { remember(share) }
        let next = Current(file: file, link: link, pwd: pwd, libraryURL: libraryURL)
        if next == current, phase == .ready || phase.isLoading { return }
        current = next
        start(at: 0)
    }

    func reload() {
        let t = player.currentTime()
        start(at: t.isValid ? t.seconds : 0)
    }

    func stop() {
        task?.cancel()
        player.replaceCurrentItem(with: nil)
        releaseToken()
        current = nil
        phase = .idle
    }

    func togglePlay() {
        guard player.currentItem != nil else { return }
        if isPlaying { player.pause() } else { player.play() }
    }

    func skip(by seconds: Double) {
        guard let item = player.currentItem else { return }
        var target = player.currentTime().seconds + seconds
        if item.duration.isNumeric { target = min(target, item.duration.seconds - 1) }
        player.seek(to: CMTime(seconds: max(0, target), preferredTimescale: 600))
    }

    private func start(at position: Double) {
        guard let current else { return }
        task?.cancel()
        statusObservation = nil
        player.replaceCurrentItem(with: nil)
        releaseToken()
        mediaURL = nil
        sourceLabel = ""
        if current.kind == .other {
            phase = .unsupported
            return
        }
        phase = .loading("Membuka link…")
        let quality = quality
        let forceHLS = forceHLSForAudio
        task = Task { [weak self] in
            guard let self else { return }
            do {
                let share = try await self.share(for: current.link, pwd: current.pwd)
                self.phase = .loading("Meminta link streaming…")
                let source = try await pickSource(share: share, file: current.file, quality: quality, forceHLS: forceHLS)
                let (token, url) = try await StreamServer.shared.register(source, file: current.file)
                try Task.checkCancellation()
                self.token = token
                self.mediaURL = url
                switch source {
                case .hls(let hls): self.sourceLabel = "Lewat " + HLSSource.label(for: await hls.type)
                case .direct: self.sourceLabel = "Dari file asli"
                }
                if current.kind == .image {
                    self.phase = .ready
                    return
                }
                self.attach(url, at: position)
            } catch is CancellationError {
            } catch TeraboxError.needLogin {
                self.phase = .failed(TeraboxError.needLogin.localizedDescription, needsLogin: true)
            } catch {
                self.phase = .failed(error.localizedDescription, needsLogin: false)
            }
        }
    }

    private func attach(_ url: URL, at position: Double) {
        phase = .loading("Menyiapkan pemutar…")
        let item = AVPlayerItem(url: url)
        statusObservation = item.observe(\.status, options: [.new]) { [weak self] item, _ in
            let status = item.status
            let message = item.error?.localizedDescription
            DispatchQueue.main.async { self?.itemStatusChanged(status, message) }
        }
        player.replaceCurrentItem(with: item)
        if position > 1 {
            player.seek(to: CMTime(seconds: position, preferredTimescale: 600))
        }
        player.play()
    }

    private func itemStatusChanged(_ status: AVPlayerItem.Status, _ message: String?) {
        switch status {
        case .readyToPlay: phase = .ready
        case .failed: phase = .failed("Pemutar tidak bisa membuka stream ini. \(message ?? "")", needsLogin: false)
        default: break
        }
    }

    /// Share yang sudah dibuka dipakai ulang selama 30 menit. Permintaan bersamaan
    /// (pemutar, thumbnail, pratinjau) menunggu pembukaan yang sama.
    func share(for link: String, pwd: String?) async throws -> TeraboxShare {
        if let cached = shares[link], Date.now.timeIntervalSince(cached.openedAt) < 30 * 60 {
            return try await cached.task.value
        }
        let cookie = cookieProvider()
        let task = Task {
            let share = try TeraboxShare(link: link, cookie: cookie, pwd: pwd)
            try await share.open()
            return share
        }
        shares[link] = (task, .now)
        do {
            return try await task.value
        } catch {
            shares[link] = nil
            throw error
        }
    }

    private func releaseToken() {
        if let token {
            Task { await StreamServer.shared.unregister(token) }
        }
        token = nil
    }
}

extension PlayerController.Phase {
    var isLoading: Bool {
        if case .loading = self { return true }
        return false
    }
}
