import AVFoundation
import Foundation
import Observation

/// Pratinjau saat kursor berhenti di atas kartu video, seperti di YouTube.
/// Video di-stream (bukan diunduh) lewat server lokal, tanpa suara, dan diputar
/// 4 detik di 1/5, 2/5, 3/5, 4/5 durasi, lalu 4 detik terakhir, kemudian
/// kembali ke 1/5. Hanya ada satu pratinjau dalam satu waktu.
@Observable @MainActor
final class PreviewPlayer {
    /// Kartu yang sedang dipratinjau.
    private(set) var activeID: String?
    /// Gambar video sudah bergerak (sebelum itu kartu tetap menampilkan thumbnail).
    private(set) var isShowing = false
    /// Bagian yang sedang diputar, 1 sampai 5.
    private(set) var part = 0
    private(set) var failed = false
    /// Alasan gagal terakhir, untuk ditampilkan di kartu.
    private(set) var failure: String?
    /// "HLS ..." atau "file asli" (untuk uji otomatis dan log).
    @ObservationIgnored private(set) var sourceLabel = ""

    nonisolated static let partLength: Double = 4
    static let hoverDelay: Duration = .milliseconds(600)
    /// Resolusi kecil dulu: pratinjau tidak butuh gambar tajam dan lebih cepat dimuat.
    static let videoTypes = ["M3U8_AUTO_360", "M3U8_AUTO_480", "M3U8_AUTO_720"]

    @ObservationIgnored let player = AVPlayer()
    @ObservationIgnored var shareResolver: (String, String?) async throws -> TeraboxShare = { _, _ in
        throw TeraboxError.message("Share belum siap")
    }
    /// Dipanggil setiap kali pindah bagian (untuk uji otomatis).
    @ObservationIgnored var onPart: ((Int, Double) -> Void)?
    @ObservationIgnored private var task: Task<Void, Never>?
    @ObservationIgnored private var token: String?
    /// Durasi item yang sedang dipratinjau.
    @ObservationIgnored private(set) var duration: Double = .nan
    @ObservationIgnored private var sources: [Int64: PlaybackSource] = [:]

    init() {
        player.isMuted = true
        player.preventsDisplaySleepDuringVideoPlayback = false
        player.actionAtItemEnd = .pause
    }

    /// Kursor masuk ke kartu: mulai setelah jeda singkat, supaya sekadar lewat
    /// di atas banyak kartu tidak memicu request.
    func hover(id: String, file: ShareFile, link: String, pwd: String?) {
        guard activeID != id else { return }
        StreamServer.debug("hover masuk kartu")
        start(id: id, file: file, link: link, pwd: pwd, delay: Self.hoverDelay)
    }

    func end(id: String) {
        if activeID == id { stop() }
    }

    func start(id: String, file: ShareFile, link: String, pwd: String?, delay: Duration = .zero) {
        stop()
        activeID = id
        task = Task { [weak self] in
            do {
                try await Task.sleep(for: delay)
                try await self?.run(file: file, link: link, pwd: pwd)
            } catch is CancellationError {
            } catch {
                guard let self, !Task.isCancelled else { return }
                self.failed = true
                self.failure = error.localizedDescription
                StreamServer.debug("pratinjau gagal: \(error.localizedDescription)")
            }
        }
    }

    func stop() {
        task?.cancel()
        task = nil
        player.pause()
        player.replaceCurrentItem(with: nil)
        if let token { Task { await StreamServer.shared.unregister(token) } }
        token = nil
        activeID = nil
        isShowing = false
        part = 0
        failed = false
        failure = nil
        sourceLabel = ""
    }

    /// Lupakan sumber yang tersimpan (mis. setelah ganti akun).
    func forgetSources() {
        sources.removeAll()
    }

    private func source(for file: ShareFile, link: String, pwd: String?) async throws -> PlaybackSource {
        if let cached = sources[file.fsId] { return cached }
        let share = try await shareResolver(link, pwd)
        // Sama seperti pemutar utama, tapi resolusi kecil. Kalau playlist HLS belum lengkap
        // (masih di-transcode) atau ditolak, pakai file asli supaya 1/5 sampai 5/5 tetap benar.
        let source = try await pickSource(share: share, file: file, quality: .automatic, videoTypes: Self.videoTypes)
        sources[file.fsId] = source
        return source
    }

    private func run(file: ShareFile, link: String, pwd: String?) async throws {
        let source = try await source(for: file, link: link, pwd: pwd)
        switch source {
        case .hls(let hls): sourceLabel = HLSSource.label(for: await hls.type)
        case .direct: sourceLabel = "file asli"
        }
        StreamServer.debug("pratinjau \(file.name.count) huruf, sumber: \(sourceLabel)")
        try Task.checkCancellation()
        let (token, url) = try await StreamServer.shared.register(source, file: file)
        guard !Task.isCancelled else {
            await StreamServer.shared.unregister(token)
            throw CancellationError()
        }
        self.token = token
        let item = AVPlayerItem(url: url)
        item.preferredForwardBufferDuration = Self.partLength + 2
        player.replaceCurrentItem(with: item)

        let duration = try await item.asset.load(.duration).seconds
        guard try await waitUntil(timeout: 30, { item.status != .unknown }), item.status == .readyToPlay else {
            throw TeraboxError.message(item.error?.localizedDescription ?? "Pratinjau tidak bisa dimuat")
        }
        self.duration = duration
        let points = Self.points(duration: duration)
        let tolerance = CMTime(seconds: 0.3, preferredTimescale: 600)
        while true {
            for (index, start) in points.enumerated() {
                part = points.count == 1 ? 0 : index + 1
                onPart?(part, start)
                // Seek tanpa ditunggu: di dekat akhir file seek kadang tidak pernah selesai,
                // jadi yang ditunggu adalah posisinya, dengan batas waktu.
                player.seek(to: CMTime(seconds: start, preferredTimescale: 600),
                            toleranceBefore: tolerance, toleranceAfter: tolerance) { _ in }
                player.play()
                _ = try await waitUntil(timeout: 8) {
                    let t = self.player.currentTime().seconds
                    return t >= start - 0.5 && t <= start + 2 && self.player.timeControlStatus == .playing
                }
                isShowing = true
                let from = player.currentTime().seconds
                let end = points.count == 1 ? duration : min(from + Self.partLength, duration)
                // Tunggu 4 detik pemutaran sungguhan (buffering tidak dihitung), maksimal 12 detik.
                _ = try await waitUntil(timeout: 12) {
                    let t = self.player.currentTime().seconds
                    let finished = self.player.rate == 0 && t > from + 0.5  // berhenti di akhir file
                    return t >= end - 0.15 || finished || item.status == .failed
                }
            }
        }
    }

    /// Titik mulai tiap bagian. Video di bawah 20 detik tidak muat lima potongan 4 detik
    /// tanpa saling tumpang-tindih, jadi diputar utuh lalu diulang dari awal.
    nonisolated static func points(duration d: Double) -> [Double] {
        guard d.isFinite, d >= 20 else { return [0] }
        return (1...4).map { d * Double($0) / 5 } + [max(0, d - partLength)]
    }

    private func waitUntil(timeout: Double, _ condition: () -> Bool) async throws -> Bool {
        let start = ContinuousClock.now
        while !condition() {
            if ContinuousClock.now - start > .seconds(timeout) { return false }
            try await Task.sleep(for: .milliseconds(100))
        }
        return true
    }
}
