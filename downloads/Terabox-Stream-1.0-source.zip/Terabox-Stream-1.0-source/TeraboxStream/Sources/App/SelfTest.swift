import AppKit
import AVFoundation
import Foundation

/// Uji otomatis alur utama di dalam aplikasi yang sebenarnya (bukan tiruan).
/// Hanya jalan kalau aplikasi diluncurkan dengan argumen -selftest, mis.:
///
///   SELFTEST_LINK=https://1024terabox.com/s/1xxx SELFTEST_REPORT=/tmp/r.txt \
///   "Terabox Stream.app/Contents/MacOS/Terabox Stream" -selftest
///
/// Variabel lain: SELFTEST_STEPS (tree,save,download,play,hls,livp),
/// SELFTEST_LIBRARY, SELFTEST_DOWNLOADS, SELFTEST_APPEARANCE (dark/light), SELFTEST_QUIT=1.
/// Audio selalu dibisukan selama uji.
@MainActor
enum SelfTest {
    private static let env = ProcessInfo.processInfo.environment

    static var isRequested: Bool { CommandLine.arguments.contains("-selftest") }
    static var libraryOverride: URL? { env["SELFTEST_LIBRARY"].map { URL(filePath: $0) } }

    private static var reportURL: URL? { env["SELFTEST_REPORT"].map { URL(filePath: $0) } }
    private static var failures = 0

    static func log(_ line: String) {
        print(line)
        guard let url = reportURL else { return }
        let data = Data((line + "\n").utf8)
        if let h = try? FileHandle(forWritingTo: url) {
            _ = try? h.seekToEnd()
            try? h.write(contentsOf: data)
            try? h.close()
        } else {
            try? data.write(to: url)
        }
    }

    private static func check(_ ok: Bool, _ what: String) {
        if !ok { failures += 1 }
        log("\(ok ? "OK  " : "GAGAL") \(what)")
    }

    /// Beri waktu untuk screenshot dari luar.
    private static func checkpoint(_ name: String) async {
        log("CHECKPOINT \(name)")
        try? await Task.sleep(for: .seconds(Double(env["SELFTEST_PAUSE"] ?? "4") ?? 4))
    }

    private static func wait(_ timeout: Double, _ condition: () -> Bool) async -> Bool {
        let start = Date.now
        while !condition() {
            if Date.now.timeIntervalSince(start) > timeout { return false }
            try? await Task.sleep(for: .milliseconds(250))
        }
        return true
    }

    static func run(_ model: AppModel) async {
        if let a = env["SELFTEST_APPEARANCE"] {
            NSApp.appearance = NSAppearance(named: a == "dark" ? .darkAqua : .aqua)
        }
        model.player.player.isMuted = true
        if env["SELFTEST_ACTIVATE"] == "1" { NSApp.activate() }
        for name in [AVPlayer.rateDidChangeNotification, AVPlayerItem.playbackStalledNotification,
                     AVPlayerItem.didPlayToEndTimeNotification, AVPlayerItem.failedToPlayToEndTimeNotification] {
            NotificationCenter.default.addObserver(forName: name, object: nil, queue: .main) { note in
                let reason = (note.userInfo?["AVPlayerRateDidChangeReasonKey"] as? String) ?? ""
                let text = "     [notif] \(note.name.rawValue) \(reason)"
                MainActor.assumeIsolated { log(text) }
            }
        }
        if let d = env["SELFTEST_DOWNLOADS"] { model.downloads.overrideFolder = URL(filePath: d) }
        let steps = Set((env["SELFTEST_STEPS"] ?? "tree,save,download,play,hls,livp").split(separator: ",").map(String.init))
        log("MULAI langkah=\(steps.sorted().joined(separator: ",")) login=\(model.account.isSignedIn)")
        try? await Task.sleep(for: .seconds(1))

        if let link = env["SELFTEST_LINK"], steps.contains("tree") {
            await tree(model, link)
            if model.browser?.phase == .loaded {
                if steps.contains("save") { await save(model) }
                if steps.contains("download") { await download(model) }
                if steps.contains("range") { await range(model) }
                if steps.contains("thumbs") { await thumbs(model) }
                if steps.contains("grid") { await grid(model) }
                if steps.contains("libthumb") { await libraryThumbs(model) }
                if steps.contains("preview") { await preview(model) }
                if steps.contains("libdl") { await libraryDownload(model) }
            }
        }
        if steps.contains("libpreview") { await libraryPreview(model) }
        if steps.contains("back") { await back(model) }
        if steps.contains("durcheck") { await durationCheck(model) }
        if steps.contains("longplay") { await longPlay(model) }
        if steps.contains("durscan") { await durationScan(model) }
        if steps.contains("partial") { await partialPlaylist(model) }
        if steps.contains("repeat") { await repeatPlaylist(model) }
        if steps.contains("play") { await play(model) }
        if steps.contains("hls") { await hls(model) }
        if steps.contains("livp") { await livp(model) }
        if steps.contains("keychain") { keychain(model) }
        if steps.contains("login") {
            if env["SELFTEST_ACTIVATE"] == "1" { NSApp.activate() }
            model.showLogin = true
            try? await Task.sleep(for: .seconds(6))
            await checkpoint("login")
            model.showLogin = false
        }
        if steps.contains("ui") {
            model.sidebar = .share
            if env["SELFTEST_ACTIVATE"] == "1" { NSApp.activate() }
            await checkpoint("akhir")
        }
        log("SELESAI gagal=\(failures)")
        if env["SELFTEST_QUIT"] == "1" { NSApp.terminate(nil) }
    }

    private static func tree(_ model: AppModel, _ link: String) async {
        model.linkText = link
        model.openLink()
        guard let browser = model.browser else { return check(false, "link terbuka") }
        _ = await wait(180) { if case .loading = browser.phase { false } else { true } }
        check(browser.phase == .loaded, "pohon file tampil (fase: \(browser.phase))")
        for row in browser.rows {
            let f = row.node.file
            log("     \(String(repeating: "  ", count: row.depth))\(row.node.name)  \(row.node.totalSize) B"
                + (f.map { "  fs_id=\($0.fsId) category=\($0.category)" } ?? "  [folder]"))
        }
        if let s = browser.summary { log("     pemilik=\(s.owner) shareid=\(s.shareid)") }
        await checkpoint("pohon")
        if let firstFile = browser.rows.first(where: { !$0.node.isFolder }) {
            browser.selection = [firstFile.id]
            model.showInspector = true
            await checkpoint("pohon-inspector")
            model.showInspector = false
            browser.selection = []
        }
    }

    /// Thumbnail dari daftar file: ada atau tidak, lalu gambarnya dimuat (alamatnya tidak dicetak).
    private static func thumbs(_ model: AppModel) async {
        guard let browser = model.browser else { return }
        for row in browser.rows where !row.node.isFolder {
            guard let loader = model.thumbnailLoader(row.node, in: browser.share), let f = row.node.file else {
                log("     \(row.node.name): tanpa thumbnail dari Terabox")
                continue
            }
            let image = await Thumbnails.shared.image(for: f.fsId, load: loader)
            let onDisk = FileManager.default.fileExists(atPath: Thumbnails.folder.appending(path: "\(f.fsId).img").path(percentEncoded: false))
            check(image != nil && onDisk, "thumbnail \(row.node.name): \(image.map { "\(Int($0.size.width))x\(Int($0.size.height))" } ?? "-"), tersimpan di cache: \(onDisk)")
        }
    }

    private static func grid(_ model: AppModel) async {
        UserDefaults.standard.set("grid", forKey: "browserLayout")
        model.sidebar = .share
        if env["SELFTEST_ACTIVATE"] == "1" { NSApp.activate() }
        try? await Task.sleep(for: .seconds(2))
        await checkpoint("grid")
        if let first = model.browser?.rows.first(where: { !$0.node.isFolder }) {
            model.browser?.selection = [first.id]
            await checkpoint("grid-pilih")
            model.browser?.selection = []
        }
        if env["SELFTEST_KEEP_LAYOUT"] != "1" { UserDefaults.standard.removeObject(forKey: "browserLayout") }
    }

    /// Item Perpustakaan: alamat thumbnail dicari ulang dari share lewat folder induknya.
    private static func libraryThumbs(_ model: AppModel) async {
        guard let browser = model.browser else { return }
        for node in allEntries(model.library.nodes) {
            guard let entry = node.entry else { continue }
            do {
                let share = try await model.share(for: entry.shareLink, pwd: entry.pwd)
                let found = try await share.thumbnailURL(rel: entry.path, fsId: entry.fsId)
                let expected = browser.rows.first { $0.node.file?.fsId == entry.fsId }?.node.thumb
                check(found?.path() == expected?.path(),
                      "alamat thumbnail \(entry.path) dari Perpustakaan: \(found == nil ? "tidak ada" : "ada"), sama dengan daftar file: \(found?.path() == expected?.path())")
            } catch {
                check(false, "thumbnail Perpustakaan \(entry.path): \(error.localizedDescription)")
            }
        }
        model.sidebar = .libraryFolder(model.library.root)
        try? await Task.sleep(for: .seconds(2))
        await checkpoint("grid-perpustakaan")
        if let folder = model.library.nodes.first(where: { $0.children != nil }) {
            model.sidebar = .libraryFolder(folder.url)
            try? await Task.sleep(for: .seconds(3))
            await checkpoint("grid-perpustakaan-folder")
        }
    }

    /// Pratinjau 1/5, 2/5, 3/5, 4/5, 4 detik terakhir, lalu kembali ke 1/5.
    /// Link contoh tidak punya video, jadi mekanismenya diuji dengan mp3-nya (HLS MP3).
    private static func preview(_ model: AppModel) async {
        guard let browser = model.browser,
              let file = browser.allFiles.first(where: { FileKinds.kind(name: $0.name, category: $0.category) != .other }) else { return }
        let preview = model.preview
        var seen: [(part: Int, start: Double, at: Date)] = []
        preview.onPart = { part, start in
            let now = preview.player.currentTime().seconds
            if let last = seen.last {
                log("     bagian \(last.part) berakhir di \(String(format: "%.2f", now)) detik, \(String(format: "%.1f", Date.now.timeIntervalSince(last.at))) detik jam dinding")
            }
            seen.append((part, start, .now))
            log("     bagian \(part): mulai di \(String(format: "%.2f", start)) detik")
        }
        let started = Date.now
        preview.start(id: "uji", file: file, link: browser.link, pwd: browser.pwd)
        _ = await wait(90) { seen.count >= 7 || preview.failed }
        let duration = preview.duration
        log("     durasi \(String(format: "%.1f", duration)) detik, total \(String(format: "%.1f", Date.now.timeIntervalSince(started))) detik")
        let expected = PreviewPlayer.points(duration: duration)
        let parts = seen.map(\.part)
        let startsMatch = zip(seen, expected + expected).allSatisfy { abs($0.start - $1) < 0.01 }
        check(!preview.failed && parts.prefix(7) == [1, 2, 3, 4, 5, 1, 2] && startsMatch,
              "pratinjau berputar 1/5 sampai 5/5 lalu kembali ke 1/5 (urutan \(parts), titik cocok: \(startsMatch))")
        preview.onPart = nil
        preview.stop()
    }

    /// Scroll grid Perpustakaan ke bawah, buka satu item, tekan Kembali:
    /// halaman dan posisi scroll-nya harus sama persis.
    private static func back(_ model: AppModel) async {
        model.sidebar = .libraryFolder(model.library.root)
        try? await Task.sleep(for: .seconds(2))
        func mainScrollView() -> NSScrollView? {
            func all(_ v: NSView) -> [NSScrollView] { (v as? NSScrollView).map { [$0] } ?? [] + v.subviews.flatMap(all) }
            let views = NSApp.windows.compactMap(\.contentView).flatMap(all)
            return views.max { ($0.documentView?.frame.height ?? 0) < ($1.documentView?.frame.height ?? 0) }
        }
        guard let sv = mainScrollView(), (sv.documentView?.frame.height ?? 0) > sv.contentView.bounds.height + 300 else {
            return check(false, "grid Perpustakaan bisa di-scroll")
        }
        sv.contentView.scroll(to: NSPoint(x: 0, y: 700))
        sv.reflectScrolledClipView(sv.contentView)
        try? await Task.sleep(for: .seconds(1))
        let before = sv.contentView.bounds.origin.y
        await checkpoint("kembali-sebelum")
        guard let item = allEntries(model.library.nodes).dropFirst(12).first else { return }
        model.sidebar = .library(item.url)
        _ = await wait(30) { model.player.phase == .ready || model.player.phase == .unsupported }
        check(model.isShowingPlayer, "item terbuka di pemutar (fase: \(model.player.phase))")
        await checkpoint("kembali-pemutar")
        model.goBack()
        try? await Task.sleep(for: .seconds(1))
        let same = mainScrollView() === sv
        let after = sv.contentView.bounds.origin.y
        check(model.sidebar == .libraryFolder(model.library.root) && same && abs(after - before) < 1,
              "Kembali ke grid yang sama, scroll \(Int(before)) -> \(Int(after)) (tampilan yang sama: \(same))")
        await checkpoint("kembali-sesudah")
        model.player.stop()
    }

    /// Minta playlist video yang sama beberapa kali: apakah Terabox kadang memotongnya?
    private static func repeatPlaylist(_ model: AppModel) async {
        let nodes = allEntries(model.library.nodes).filter { ($0.entry?.category ?? 0) == 1 }
        guard let entry = nodes[Int(env["SELFTEST_OFFSET"] ?? "15") ?? 15].entry else { return }
        let types = (env["SELFTEST_TYPES"] ?? "M3U8_AUTO_480").split(separator: ",").map(String.init)
        for i in 0..<(Int(env["SELFTEST_COUNT"] ?? "6") ?? 6) {
            do {
                let share = try await model.share(for: entry.shareLink, pwd: entry.pwd)
                let (type, text) = try await share.m3u8(fsId: entry.fsId, types: types)
                let lines = text.split(separator: "\n")
                let total = lines.compactMap { l -> Double? in
                    guard l.hasPrefix("#EXTINF:") else { return nil }
                    return Double(l.dropFirst(8).split(separator: ",").first ?? "")
                }.reduce(0, +)
                let head = lines.prefix(4).map { $0.hasPrefix("#") ? String($0.prefix(40)) : "URL" }
                log("     ke-\(i + 1): \(type) \(String(format: "%.0f", total)) detik, ENDLIST \(text.contains("#EXT-X-ENDLIST")), awal \(head)")
            } catch {
                log("     ke-\(i + 1): gagal \(error.localizedDescription)")
            }
            try? await Task.sleep(for: .seconds(Double(env["SELFTEST_GAP"] ?? "1") ?? 1))
        }
    }

    /// Cari video yang playlist HLS-nya belum lengkap (belum pernah di-transcode), lalu
    /// pastikan pemutar utama memutarnya dengan durasi penuh.
    private static func partialPlaylist(_ model: AppModel) async {
        let nodes = allEntries(model.library.nodes).filter { ($0.entry?.category ?? 0) == 1 }
        let stride = Int(env["SELFTEST_STRIDE"] ?? "7") ?? 7
        var found: LibraryNode?
        for index in Swift.stride(from: Int(env["SELFTEST_OFFSET"] ?? "1") ?? 1, to: nodes.count, by: stride) {
            guard let entry = nodes[index].entry else { continue }
            do {
                let share = try await model.share(for: entry.shareLink, pwd: entry.pwd)
                let (type, text) = try await share.m3u8(fsId: entry.fsId, types: ["M3U8_AUTO_480", "M3U8_AUTO_360"])
                let total = text.split(separator: "\n").compactMap { l -> Double? in
                    guard l.hasPrefix("#EXTINF:") else { return nil }
                    return Double(l.dropFirst(8).split(separator: ",").first ?? "")
                }.reduce(0, +)
                let complete = text.contains("#EXT-X-ENDLIST")
                log("     #\(index) \(entry.size / 1_000_000) MB: \(type) \(String(format: "%.0f", total)) detik, lengkap: \(complete)")
                if !complete { found = nodes[index]; break }
            } catch {
                log("     #\(index): gagal \(error.localizedDescription)")
            }
            try? await Task.sleep(for: .seconds(1.5))
        }
        guard let node = found else { return log("     semua playlist yang dicek sudah lengkap") }
        model.sidebar = .library(node.url)
        let ready = await waitPlayable(model)
        try? await Task.sleep(for: .seconds(2))
        let d = model.player.player.currentItem?.duration.seconds ?? .nan
        let size = node.entry?.size ?? 0
        check(ready && d.isFinite && d > 60, "video yang belum selesai di-transcode diputar \(model.player.sourceLabel), durasi \(String(format: "%.1f", d)) detik (\(size / 1_000_000) MB)")
        _ = await wait(15) { model.player.player.currentTime().seconds > 5 }
        let target = d.isFinite ? d * 0.8 : 0
        _ = await model.player.player.seek(to: CMTime(seconds: target, preferredTimescale: 600))
        _ = await wait(20) { model.player.player.currentTime().seconds > target + 1 }
        check(model.player.player.currentTime().seconds > target + 1,
              "seek ke 80% (\(Int(target)) detik) lalu lanjut: \(String(format: "%.1f", model.player.player.currentTime().seconds))")
        model.player.stop()
    }

    /// Beberapa video acak: durasi playlist HLS 480p dibandingkan dengan file asli.
    private static func durationScan(_ model: AppModel) async {
        let videos = allEntries(model.library.nodes).compactMap(\.entry).filter { ($0.category ?? 0) == 1 }
        let stride = Int(env["SELFTEST_STRIDE"] ?? "25") ?? 25
        let picked = Swift.stride(from: Int(env["SELFTEST_OFFSET"] ?? "3") ?? 3, to: videos.count, by: stride).map { videos[$0] }
        let types = (env["SELFTEST_TYPES"] ?? "M3U8_AUTO_480,M3U8_AUTO_360").split(separator: ",").map(String.init)
        for entry in picked {
            do {
                let share = try await model.share(for: entry.shareLink, pwd: entry.pwd)
                let (type, text) = try await share.m3u8(fsId: entry.fsId, types: types)
                let lines = text.split(separator: "\n")
                let total = lines.compactMap { l -> Double? in
                    guard l.hasPrefix("#EXTINF:") else { return nil }
                    return Double(l.dropFirst(8).split(separator: ",").first ?? "")
                }.reduce(0, +)
                let src = DirectSource(share: share, fsId: entry.fsId)
                let (token, url) = try await StreamServer.shared.register(.direct(src), file: entry.file)
                let real = (try? await AVURLAsset(url: url).load(.duration).seconds) ?? .nan
                await StreamServer.shared.unregister(token)
                let disc = lines.firstIndex { $0.hasPrefix("#EXT-X-DISCONTINUITY") }.map { "baris \($0)" } ?? "-"
                log("     \(entry.size / 1_000_000) MB: \(type) \(String(format: "%.1f", total)) detik vs asli \(String(format: "%.1f", real)) detik, "
                    + "ENDLIST \(text.contains("#EXT-X-ENDLIST")), DISCONTINUITY \(disc), \(lines.count) baris")
            } catch {
                log("     \(entry.size / 1_000_000) MB: gagal \(error.localizedDescription)")
            }
            try? await Task.sleep(for: .seconds(2))
        }
    }

    /// Putar video panjang di pemutar utama dan pantau posisinya (tanpa screenshot).
    private static func longPlay(_ model: AppModel) async {
        let wanted = env["SELFTEST_FILE"] ?? ""
        guard let node = allEntries(model.library.nodes).first(where: { $0.entry?.path.contains(wanted) == true }) else {
            return check(false, "file uji ditemukan")
        }
        model.sidebar = .library(node.url)
        let ready = await waitPlayable(model)
        let p = model.player.player
        log("     siap: \(ready), sumber: \(model.player.sourceLabel), durasi item: \(String(format: "%.1f", p.currentItem?.duration.seconds ?? .nan))")
        let seconds = Int(env["SELFTEST_SECONDS"] ?? "70") ?? 70
        for _ in 0..<(seconds / 5) {
            try? await Task.sleep(for: .seconds(5))
            let item = p.currentItem
            log("     t=\(String(format: "%.1f", p.currentTime().seconds)) status=\(p.timeControlStatus.rawValue) "
                + "alasan=\(p.reasonForWaitingToPlay?.rawValue ?? "-") durasi=\(String(format: "%.1f", item?.duration.seconds ?? .nan)) "
                + "buffer=\(item?.loadedTimeRanges.map { "\(Int($0.timeRangeValue.start.seconds))-\(Int($0.timeRangeValue.end.seconds))" } ?? []) "
                + "error=\(item?.error?.localizedDescription ?? "-") errlog=\(item?.errorLog()?.events.suffix(2).map { "\($0.errorStatusCode) \($0.errorComment ?? "")" } ?? [])")
        }
        model.player.stop()
    }

    /// Bandingkan durasi playlist HLS tiap kualitas dengan durasi file aslinya.
    private static func durationCheck(_ model: AppModel) async {
        let wanted = env["SELFTEST_FILE"] ?? ""
        guard let entry = allEntries(model.library.nodes).compactMap(\.entry).first(where: { $0.path.contains(wanted) }) else {
            return check(false, "file uji ditemukan")
        }
        log("     file \(entry.size) byte")
        do {
            let share = try await model.share(for: entry.shareLink, pwd: entry.pwd)
            for type in videoHLSTypes {
                do {
                    let (_, text) = try await share.m3u8(fsId: entry.fsId, types: [type])
                    let lines = text.split(separator: "\n")
                    let total = lines.compactMap { l -> Double? in
                        guard l.hasPrefix("#EXTINF:") else { return nil }
                        return Double(l.dropFirst(8).split(separator: ",").first ?? "")
                    }.reduce(0, +)
                    let tags = Set(lines.filter { $0.hasPrefix("#") }.map { String($0.split(separator: ":").first ?? "") })
                    log("     \(type): \(lines.filter { !$0.hasPrefix("#") }.count) segmen, \(String(format: "%.1f", total)) detik, tag \(tags.sorted())")
                } catch {
                    log("     \(type): gagal \(error.localizedDescription)")
                }
                try? await Task.sleep(for: .seconds(1))
            }
            let src = DirectSource(share: share, fsId: entry.fsId)
            let (token, url) = try await StreamServer.shared.register(.direct(src), file: entry.file)
            let real = try await AVURLAsset(url: url).load(.duration).seconds
            await StreamServer.shared.unregister(token)
            log("     file asli: \(String(format: "%.1f", real)) detik")
        } catch {
            check(false, "cek durasi: \(error.localizedDescription)")
        }
    }

    /// Pratinjau video pertama di Perpustakaan. Hanya log angka, tanpa screenshot.
    private static func libraryPreview(_ model: AppModel) async {
        guard let node = allEntries(model.library.nodes).first(where: {
            guard let e = $0.entry else { return false }
            return FileKinds.kind(name: e.name, category: e.category ?? 0) == .video
        }), let entry = node.entry else { return check(false, "ada video di Perpustakaan") }
        let preview = model.preview
        var parts: [Int] = []
        preview.onPart = { part, start in
            parts.append(part)
            log("     bagian \(part): mulai di \(String(format: "%.2f", start)) detik")
        }
        let started = Date.now
        preview.start(id: "uji-perpustakaan", file: entry.file, link: entry.shareLink, pwd: entry.pwd)
        let showed = await wait(60) { preview.isShowing || preview.failed }
        let firstFrame = Date.now.timeIntervalSince(started)
        log("     sumber: \(preview.sourceLabel.isEmpty ? "-" : preview.sourceLabel), durasi \(String(format: "%.1f", preview.duration)) detik, "
            + "status item: \(preview.player.currentItem?.status.rawValue ?? -1), error: \(preview.failure ?? preview.player.currentItem?.error?.localizedDescription ?? "-")")
        check(showed && preview.isShowing && !preview.failed,
              "pratinjau video Perpustakaan mulai bergerak setelah \(String(format: "%.1f", firstFrame)) detik")
        if preview.isShowing {
            let t1 = preview.player.currentTime().seconds
            _ = await wait(25) { parts.count >= 7 || preview.failed }
            let t2 = preview.player.currentTime().seconds
            let size = preview.player.currentItem?.presentationSize ?? .zero
            check(!preview.failed && (parts.count >= 6 || (parts.count >= 2 && Set(parts) == [0] && t2 != t1)),
                  "pratinjau terus berjalan (bagian \(parts), ukuran gambar \(Int(size.width))x\(Int(size.height)))")
        }
        preview.onPart = nil
        preview.stop()
    }

    private static func save(_ model: AppModel) async {
        let n = model.saveToLibrary()
        check(n == model.browser?.allFiles.count && n > 0, "Simpan menulis \(n) file .tblink ke \(model.library.root.path(percentEncoded: false))")
        for node in allEntries(model.library.nodes) {
            log("     \(node.url.path(percentEncoded: false))")
        }
    }

    /// Centang di Perpustakaan (grid dan daftar), Pilih semua, lalu unduh yang dicentang.
    private static func libraryDownload(_ model: AppModel) async {
        let library = model.library
        if library.nodes.isEmpty { _ = model.saveToLibrary() }
        let entries = allEntries(library.nodes)
        UserDefaults.standard.set("grid", forKey: "libraryLayout")
        model.sidebar = .libraryFolder(library.root)
        try? await Task.sleep(for: .seconds(2))
        check(library.checked.isEmpty && !model.canDownloadCurrent, "awalnya tidak ada yang dicentang, ⌘D mati")
        guard let first = entries.first else { return check(false, "Perpustakaan berisi file") }
        // Satu item dicentang
        library.toggleChecked(first.url)
        check(library.entries(in: library.checked).count == 1 && model.canDownloadCurrent, "centang 1 file, ⌘D aktif")
        await checkpoint("lib-centang-1")
        // Pilih semua = semua folder dan file di folder ini, termasuk isi subfolder
        library.checked = Set(library.nodes.map(\.url))
        let picked = library.entries(in: library.checked)
        check(picked.count == entries.count, "Pilih semua: \(picked.count) dari \(entries.count) file")
        await checkpoint("lib-pilih-semua")
        UserDefaults.standard.set("list", forKey: "libraryLayout")
        try? await Task.sleep(for: .seconds(1))
        await checkpoint("lib-daftar")
        UserDefaults.standard.set("grid", forKey: "libraryLayout")
        // Unduh yang dicentang
        model.downloads.clearFinished()
        model.downloadCurrent()
        _ = await wait(60) { model.downloads.jobs.count >= picked.count }
        await model.downloads.waitUntilIdle()
        for job in model.downloads.jobs {
            let size = (try? FileManager.default.attributesOfItem(atPath: job.destination.path(percentEncoded: false))[.size] as? NSNumber)?.int64Value ?? -1
            check((job.state == .done || job.state == .skipped) && size == job.file.size,
                  "unduh dari Perpustakaan \(job.file.rel): status=\(job.state) ukuran=\(size)/\(job.file.size)")
        }
        check(model.downloads.jobs.count == picked.count, "\(model.downloads.jobs.count) file masuk antrean")
        // Pindah folder membuang centang
        if let sub = library.nodes.first(where: { $0.children != nil }) {
            model.sidebar = .libraryFolder(sub.url)
            try? await Task.sleep(for: .seconds(1))
            check(library.checked.isEmpty, "pindah folder: centang dibersihkan")
        }
        await checkpoint("lib-selesai")
        UserDefaults.standard.removeObject(forKey: "libraryLayout")
    }

    private static func allEntries(_ nodes: [LibraryNode]) -> [LibraryNode] {
        nodes.flatMap { $0.entry != nil ? [$0] : allEntries($0.children ?? []) }
    }

    private static func download(_ model: AppModel) async {
        guard let browser = model.browser else { return }
        model.download()
        model.sidebar = .downloads
        try? await Task.sleep(for: .seconds(1.5))
        await checkpoint("unduhan-berjalan")
        await model.downloads.waitUntilIdle()
        for job in model.downloads.jobs {
            let size = (try? FileManager.default.attributesOfItem(atPath: job.destination.path(percentEncoded: false))[.size] as? NSNumber)?.int64Value ?? -1
            check(job.state == .done && size == job.file.size,
                  "unduh \(job.file.rel): status=\(job.state) ukuran=\(size)/\(job.file.size)")
        }
        await checkpoint("unduhan-selesai")
        // Unduh lagi: harus dilewati karena sudah lengkap.
        model.downloads.clearFinished()
        model.download()
        await model.downloads.waitUntilIdle()
        check(model.downloads.jobs.allSatisfy { $0.state == .skipped },
              "unduh ulang dilewati (\(model.downloads.jobs.map { "\($0.state)" }.joined(separator: ",")))")
        _ = browser
    }

    /// Jalur seek mode "file asli": minta potongan di tengah file lewat server lokal
    /// (seperti AVPlayer saat seek) dan bandingkan dengan file hasil unduhan.
    private static func range(_ model: AppModel) async {
        guard let browser = model.browser,
              let job = model.downloads.jobs.first(where: { $0.file.name.hasSuffix(".mp3") }),
              let local = try? Data(contentsOf: job.destination) else { return check(false, "ada mp3 hasil unduhan untuk uji Range") }
        do {
            let src = DirectSource(share: browser.share, fsId: job.file.fsId)
            let (token, url) = try await StreamServer.shared.register(.direct(src), file: job.file)
            defer { Task { await StreamServer.shared.unregister(token) } }
            let start = 3_000_000, end = 3_000_099
            var req = URLRequest(url: url)
            req.setValue("bytes=\(start)-\(end)", forHTTPHeaderField: "Range")
            let (data, resp) = try await URLSession.shared.data(for: req)
            let http = resp as? HTTPURLResponse
            check(http?.statusCode == 206 && data == local[start...end],
                  "Range bytes=\(start)-\(end) lewat server lokal: HTTP \(http?.statusCode ?? 0), \(data.count) byte, "
                  + "Content-Range \(http?.value(forHTTPHeaderField: "Content-Range") ?? "-"), cocok dengan file unduhan: \(data == local[start...end])")
        } catch {
            check(false, "uji Range: \(error.localizedDescription)")
        }
    }

    /// Impor cookie.txt lewat jalur yang sama dengan menu Akun > Impor cookie.txt,
    /// lalu pastikan Keychain mengembalikan nilai yang sama (nilainya tidak dicetak).
    private static func keychain(_ model: AppModel) {
        guard let path = env["SELFTEST_IMPORT"], !path.isEmpty else { return }
        do {
            try model.account.importFile(URL(filePath: path))
            let raw = try String(contentsOfFile: path, encoding: .utf8)
            let same = CookieKeychain.load() == CookieText.normalize(raw)
            check(same && model.account.source == .keychain, "impor cookie.txt tersimpan di Keychain dan terbaca lagi")
        } catch {
            check(false, "impor cookie.txt: \(error.localizedDescription)")
        }
    }

    private static func libraryURL(_ model: AppModel, ext: String) -> URL? {
        allEntries(model.library.nodes).first { ($0.entry?.name as NSString?)?.pathExtension.lowercased() == ext }?.url
    }

    private static func waitPlayable(_ model: AppModel) async -> Bool {
        _ = await wait(90) {
            switch model.player.phase {
            case .ready, .failed, .unsupported: true
            default: false
            }
        }
        return model.player.phase == .ready
    }

    private static func seconds(_ model: AppModel) -> Double {
        model.player.player.currentTime().seconds
    }

    private static func verifyPlaybackAndSeek(_ model: AppModel, label: String, seekTo target: Double) async {
        let ready = await waitPlayable(model)
        check(ready, "\(label): siap diputar (fase: \(model.player.phase), sumber: \(model.player.sourceLabel))")
        guard ready else { return }
        _ = await wait(20) { seconds(model) > 1.0 }
        let t1 = seconds(model)
        try? await Task.sleep(for: .seconds(2))
        let t2 = seconds(model)
        check(t2 > t1 && t2 > 1, "\(label): waktu berjalan \(String(format: "%.2f", t1)) -> \(String(format: "%.2f", t2)) detik")
        if let d = model.player.player.currentItem?.duration, d.isNumeric {
            log("     durasi \(String(format: "%.1f", d.seconds)) detik")
        }
        let finished = await model.player.player.seek(to: CMTime(seconds: target, preferredTimescale: 600))
        _ = await wait(20) { seconds(model) > target + 0.5 }
        let t3 = seconds(model)
        try? await Task.sleep(for: .seconds(2))
        let t4 = seconds(model)
        let p = model.player.player
        let item = p.currentItem
        log("     status setelah seek: rate=\(p.rate) tcs=\(p.timeControlStatus.rawValue) alasan=\(p.reasonForWaitingToPlay?.rawValue ?? "-") "
            + "keepUp=\(item?.isPlaybackLikelyToKeepUp ?? false) buffer=\(item?.loadedTimeRanges.map { "\($0.timeRangeValue.start.seconds)-\($0.timeRangeValue.end.seconds)" } ?? []) "
            + "error=\(item?.error?.localizedDescription ?? "-") errlog=\(item?.errorLog()?.events.map { "\($0.errorStatusCode) \($0.errorComment ?? "")" } ?? [])")
        check(finished && t3 >= target && t4 > t3,
              "\(label): seek ke \(Int(target)) detik lalu lanjut \(String(format: "%.2f", t3)) -> \(String(format: "%.2f", t4))")
    }

    private static func play(_ model: AppModel) async {
        guard let url = libraryURL(model, ext: "mp3") else { return check(false, "ada mp3 di Perpustakaan") }
        model.sidebar = .library(url)
        await verifyPlaybackAndSeek(model, label: "putar mp3 dari Perpustakaan", seekTo: 60)
        await checkpoint("pemutar")
    }

    private static func hls(_ model: AppModel) async {
        guard let url = libraryURL(model, ext: "mp3") else { return }
        model.player.forceHLSForAudio = true
        if model.sidebar != .library(url) { model.sidebar = .library(url) }
        model.player.reload()
        await verifyPlaybackAndSeek(model, label: "putar mp3 lewat HLS M3U8_MP3_128", seekTo: 120)
        model.player.forceHLSForAudio = false
        await checkpoint("pemutar-hls")
    }

    private static func livp(_ model: AppModel) async {
        guard let url = libraryURL(model, ext: "livp") else { return }
        model.sidebar = .library(url)
        _ = await wait(5) { model.player.phase == .unsupported }
        check(model.player.phase == .unsupported, "file .livp ditandai tidak bisa diputar (tanpa request)")
        await checkpoint("livp")
    }
}
