import Foundation
import Observation

// MARK: - Akun

@Observable @MainActor
final class AccountStore {
    enum Source: Equatable {
        case none, keychain, environment
    }

    private(set) var source: Source = .none
    @ObservationIgnored private(set) var cookie: String?

    var isSignedIn: Bool { source != .none }

    init() {
        // TERABOX_COOKIE (atau TERABOX_COOKIE_FILE) dipakai sama seperti di CLI, untuk pengujian.
        // Selain itu cookie diambil dari Keychain.
        let env = ProcessInfo.processInfo.environment
        let fromFile = env["TERABOX_COOKIE_FILE"].flatMap { try? String(contentsOfFile: $0, encoding: .utf8) }
        if let raw = env["TERABOX_COOKIE"] ?? fromFile, let c = CookieText.normalize(raw) {
            cookie = c
            source = .environment
        } else if let saved = CookieKeychain.load() {
            cookie = saved
            source = .keychain
        }
    }

    func store(_ cookie: String) throws {
        try CookieKeychain.save(cookie)
        self.cookie = cookie
        source = .keychain
    }

    func importFile(_ url: URL) throws {
        let raw = try String(contentsOf: url, encoding: .utf8)
        guard let cookie = CookieText.normalize(raw), CookieText.hasNdus(cookie) else {
            throw TeraboxError.message("File ini tidak berisi cookie ndus. Isinya harus seperti ndus=NILAI.")
        }
        try store(cookie)
    }

    func signOut() {
        CookieKeychain.delete()
        cookie = nil
        source = .none
    }
}

// MARK: - Perpustakaan

@Observable @MainActor
final class LibraryStore {
    private(set) var root: URL
    private(set) var nodes: [LibraryNode] = []
    var expanded: Set<URL> = []
    /// Item dan folder yang dicentang di halaman Perpustakaan. Berlaku untuk satu folder saja.
    var checked: Set<URL> = []
    @ObservationIgnored private(set) var checkedFolder: URL?
    @ObservationIgnored private var knownFolders: Set<URL> = []
    @ObservationIgnored private let persistsRoot: Bool

    static var defaultRoot: URL {
        FileManager.default.homeDirectoryForCurrentUser.appending(path: "Terabox Stream/Perpustakaan")
    }

    init(override: URL? = nil) {
        if let override {
            root = override
            persistsRoot = false
        } else {
            root = UserDefaults.standard.string(forKey: "libraryPath").map { URL(filePath: $0) } ?? Self.defaultRoot
            persistsRoot = true
        }
        reload()
    }

    var count: Int { nodes.reduce(0) { $0 + $1.count } }

    func setRoot(_ url: URL) {
        root = url
        if persistsRoot { UserDefaults.standard.set(url.path(percentEncoded: false), forKey: "libraryPath") }
        reload()
    }

    func reload() {
        let scanned = LibraryFiles.scan(root)
        // Folder baru otomatis terbuka; folder yang ditutup user tetap tertutup.
        var newExpanded = expanded
        func visit(_ list: [LibraryNode]) {
            for n in list where n.children != nil {
                if !knownFolders.contains(n.url) {
                    knownFolders.insert(n.url)
                    newExpanded.insert(n.url)
                }
                visit(n.children ?? [])
            }
        }
        visit(scanned)
        if newExpanded != expanded { expanded = newExpanded }
        if scanned != nodes { nodes = scanned }
        // Yang sudah dihapus atau dipindah di Finder tidak lagi dihitung terpilih.
        if !checked.isEmpty {
            var present: Set<URL> = []
            func collect(_ list: [LibraryNode]) {
                for n in list {
                    present.insert(n.url)
                    collect(n.children ?? [])
                }
            }
            collect(scanned)
            let kept = checked.intersection(present)
            if kept != checked { checked = kept }
        }
    }

    /// Pindah ke folder lain: centang dari folder sebelumnya dibuang.
    func showFolder(_ url: URL) {
        guard checkedFolder != url else { return }
        checkedFolder = url
        if !checked.isEmpty { checked = [] }
    }

    func toggleChecked(_ url: URL) {
        if checked.contains(url) { checked.remove(url) } else { checked.insert(url) }
    }

    /// Semua file di bawah item dan folder yang diberikan, urut seperti pohonnya, tanpa duplikat.
    func entries(in urls: Set<URL>) -> [LinkEntry] {
        var out: [LinkEntry] = []
        func all(_ n: LibraryNode) {
            if let e = n.entry { out.append(e) }
            n.children?.forEach(all)
        }
        func visit(_ list: [LibraryNode]) {
            for n in list {
                if urls.contains(n.url) { all(n) } else { visit(n.children ?? []) }
            }
        }
        visit(nodes)
        return out
    }

    func entry(at url: URL) -> LinkEntry? {
        func find(_ list: [LibraryNode]) -> LinkEntry? {
            for n in list {
                if n.url == url { return n.entry }
                if let e = find(n.children ?? []) { return e }
            }
            return nil
        }
        return find(nodes)
    }

    func folderNode(_ url: URL) -> LibraryNode? {
        func find(_ list: [LibraryNode]) -> LibraryNode? {
            for n in list where n.children != nil {
                if n.url == url { return n }
                if let f = find(n.children ?? []) { return f }
            }
            return nil
        }
        return find(nodes)
    }

    func save(_ files: [ShareFile], link: String, pwd: String?, summary: ShareSummary) throws -> [URL] {
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
        let saved = try LibraryFiles.save(files, link: link, pwd: pwd, summary: summary, to: root)
        reload()
        return saved
    }

    func moveToTrash(_ url: URL) throws {
        try FileManager.default.trashItem(at: url, resultingItemURL: nil)
        reload()
    }
}

// MARK: - Isi link yang sedang dibuka

@Observable @MainActor
final class ShareBrowser {
    enum Phase: Equatable {
        case loading(String)
        case needsPassword(wrong: Bool)
        case loaded
        case failed(String, needsLogin: Bool)
    }

    struct Row: Identifiable, Hashable {
        let node: FileNode
        let depth: Int
        var id: String { node.id }
    }

    let link: String
    let share: TeraboxShare
    private(set) var phase: Phase = .loading("Membuka link…")
    private(set) var summary: ShareSummary?
    /// Kode akses yang berhasil dipakai (ikut disimpan di .tblink, seperti CLI).
    private(set) var pwd: String?
    private(set) var roots: [FileNode] = []
    var expanded: Set<String> = []
    var selection: Set<String> = []
    @ObservationIgnored private var index: [String: FileNode] = [:]
    @ObservationIgnored private var task: Task<Void, Never>?

    init(link: String, share: TeraboxShare) {
        self.link = link
        self.share = share
        pwd = TeraboxShare.parsePwd(link)
    }

    /// Nama yang tampil di judul jendela: folder utama share kalau cuma satu.
    var title: String {
        if roots.count == 1, let only = roots.first { return only.name }
        return "Isi Link"
    }

    var allFiles: [ShareFile] { roots.flatMap(\.allFiles) }

    var selectedFiles: [ShareFile] {
        var seen = Set<Int64>()
        return selection.compactMap { index[$0] }
            .sorted { $0.id < $1.id }
            .flatMap(\.allFiles)
            .filter { seen.insert($0.fsId).inserted }
    }

    /// File yang dikenai aksi: yang dipilih, atau semua kalau tidak ada yang dipilih (seperti CLI).
    var targetFiles: [ShareFile] { selection.isEmpty ? allFiles : selectedFiles }

    func node(_ id: String) -> FileNode? { index[id] }

    var rows: [Row] {
        var out: [Row] = []
        func add(_ list: [FileNode], _ depth: Int) {
            for n in list {
                out.append(Row(node: n, depth: depth))
                if let kids = n.children, expanded.contains(n.id) { add(kids, depth + 1) }
            }
        }
        add(roots, 0)
        return out
    }

    func toggle(_ id: String) {
        if expanded.contains(id) { expanded.remove(id) } else { expanded.insert(id) }
    }

    func load() {
        run { browser in
            try await browser.share.open()
        }
    }

    func unlock(with code: String) {
        run { browser in
            browser.phase = .loading("Memeriksa kode akses…")
            try await browser.share.verify(code)
            browser.pwd = code
            try await browser.share.refreshInfo()
        }
    }

    private func run(_ prepare: @escaping @MainActor (ShareBrowser) async throws -> Void) {
        task?.cancel()
        task = Task { [weak self] in
            guard let self else { return }
            do {
                phase = .loading("Membuka link…")
                try await prepare(self)
                summary = await share.summary()
                phase = .loading("Membaca isi folder…")
                let tree = try await share.walk { path in
                    DispatchQueue.main.async { [weak self] in
                        if case .loading = self?.phase { self?.phase = .loading("Membaca \(path)…") }
                    }
                }
                try Task.checkCancellation()
                setTree(tree)
                phase = .loaded
            } catch is CancellationError {
            } catch TeraboxError.needPassword {
                phase = .needsPassword(wrong: false)
            } catch TeraboxError.wrongPassword {
                phase = .needsPassword(wrong: true)
            } catch TeraboxError.needLogin {
                phase = .failed(TeraboxError.needLogin.localizedDescription, needsLogin: true)
            } catch {
                phase = .failed(error.localizedDescription, needsLogin: false)
            }
        }
    }

    private func setTree(_ tree: [FileNode]) {
        var idx: [String: FileNode] = [:]
        var folders: Set<String> = []
        func visit(_ list: [FileNode]) {
            for n in list {
                idx[n.id] = n
                if let kids = n.children {
                    folders.insert(n.id)
                    visit(kids)
                }
            }
        }
        visit(tree)
        index = idx
        roots = tree
        expanded = folders
    }

    func cancel() {
        task?.cancel()
    }
}
