import SwiftUI

@main
struct TeraboxStreamApp: App {
    @State private var model = SelfTest.isRequested
        ? AppModel(libraryOverride: SelfTest.libraryOverride)
        : AppModel()

    var body: some Scene {
        Window("Terabox Stream", id: "main") {
            ContentView()
                .environment(model)
                .frame(minWidth: 860, minHeight: 500)
                .onOpenURL { model.open(fileURL: $0) }
                .task {
                    if SelfTest.isRequested { await SelfTest.run(model) }
                }
        }
        .defaultSize(width: 1180, height: 740)
        .commands { AppCommands(model: model) }

        Settings {
            SettingsView()
                .environment(model)
        }
    }
}

struct AppCommands: Commands {
    let model: AppModel
    @AppStorage("browserLayout") private var layout: BrowserLayout = .list
    @AppStorage("libraryLayout") private var libraryLayout: BrowserLayout = .grid

    /// ⌘1 dan ⌘2 mengubah tampilan halaman yang sedang dibuka.
    private var currentLayout: Binding<BrowserLayout> {
        model.isLibraryPage ? $libraryLayout : $layout
    }

    var body: some Commands {
        @Bindable var player = model.player
        SidebarCommands()
        InspectorCommands()

        CommandGroup(before: .sidebar) {
            Button("Kembali") { model.goBack() }
                .keyboardShortcut("[")
                .disabled(!model.isShowingPlayer)
            Divider()
            Picker("Tampilan", selection: currentLayout) {
                Text("Sebagai Daftar").tag(BrowserLayout.list)
                    .keyboardShortcut("1")
                Text("Sebagai Grid").tag(BrowserLayout.grid)
                    .keyboardShortcut("2")
            }
            .pickerStyle(.inline)
            Divider()
        }

        CommandGroup(replacing: .newItem) {
            Button("Buka Link…") { model.requestLinkFocus() }
                .keyboardShortcut("l")
            Button("Buka Link dari Papan Klip") { model.openFromClipboard() }
                .keyboardShortcut("v", modifiers: [.command, .shift])
        }

        CommandGroup(replacing: .saveItem) {
            Button("Simpan ke Perpustakaan") { model.saveToLibrary() }
                .keyboardShortcut("s")
                .disabled(!model.canActOnShare || model.isLibraryPage)
            Button("Unduh") { model.downloadCurrent() }
                .keyboardShortcut("d")
                .disabled(!model.canDownloadCurrent)
            Button("Unduh ke…") { model.downloadCurrent(choosingFolder: true) }
                .keyboardShortcut("d", modifiers: [.command, .option])
                .disabled(!model.canDownloadCurrent)
        }

        CommandMenu("Pemutaran") {
            Button(player.isPlaying ? "Jeda" : "Putar") { player.togglePlay() }
                .keyboardShortcut(.space, modifiers: [])
                .disabled(player.current == nil)
            Button("Maju 10 Detik") { player.skip(by: 10) }
                .keyboardShortcut(.rightArrow, modifiers: .command)
                .disabled(player.current == nil)
            Button("Mundur 10 Detik") { player.skip(by: -10) }
                .keyboardShortcut(.leftArrow, modifiers: .command)
                .disabled(player.current == nil)
            Divider()
            Picker("Kualitas Video", selection: $player.quality) {
                ForEach(VideoQuality.allCases) { Text($0.title).tag($0) }
            }
            Divider()
            Button("Hentikan") { player.stop() }
                .keyboardShortcut(".", modifiers: .command)
                .disabled(player.current == nil)
        }

        CommandMenu("Akun") {
            Button("Masuk ke Terabox…") { model.showLogin = true }
            Button("Impor cookie.txt…") { model.importCookieFile() }
            Divider()
            Button("Keluar dari Akun") { model.signOut() }
                .disabled(model.account.source != .keychain)
        }
    }
}
