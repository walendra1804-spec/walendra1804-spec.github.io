import AppKit
import Foundation

/// Thumbnail gambar dan video. Diambil sekali dari CDN Terabox, lalu disimpan di
/// ~/Library/Caches supaya membuka aplikasi lagi tidak perlu meminta ulang.
@MainActor
final class Thumbnails {
    static let shared = Thumbnails()

    typealias Loader = @Sendable () async throws -> Data?

    private let memory = NSCache<NSNumber, NSImage>()
    private var inFlight: [Int64: Task<Data?, Never>] = [:]
    /// File yang memang tidak punya thumbnail; tidak ditanyakan lagi selama aplikasi terbuka.
    private var missing: Set<Int64> = []
    private let gate = AsyncGate(limit: 4)

    nonisolated static var folder: URL {
        URL.cachesDirectory.appending(path: "com.walendra.TeraboxStream/Thumbnails", directoryHint: .isDirectory)
    }

    init() {
        memory.countLimit = 400
    }

    func cached(_ fsId: Int64) -> NSImage? {
        memory.object(forKey: NSNumber(value: fsId))
    }

    func image(for fsId: Int64, load: @escaping Loader) async -> NSImage? {
        if let image = cached(fsId) { return image }
        if missing.contains(fsId) { return nil }
        let task: Task<Data?, Never>
        if let running = inFlight[fsId] {
            task = running
        } else {
            let gate = gate
            task = Task.detached {
                if let data = await Self.readDisk(fsId) { return data }
                await gate.acquire()
                defer { Task { await gate.release() } }
                guard let data = try? await load() else { return nil }
                Self.writeDisk(data, fsId)
                return data
            }
            inFlight[fsId] = task
        }
        let data = await task.value
        inFlight[fsId] = nil
        guard let data, let image = NSImage(data: data) else {
            missing.insert(fsId)
            return nil
        }
        memory.setObject(image, forKey: NSNumber(value: fsId))
        return image
    }

    @concurrent
    private nonisolated static func readDisk(_ fsId: Int64) async -> Data? {
        try? Data(contentsOf: folder.appending(path: "\(fsId).img"))
    }

    private nonisolated static func writeDisk(_ data: Data, _ fsId: Int64) {
        try? FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
        try? data.write(to: folder.appending(path: "\(fsId).img"), options: .atomic)
    }
}

/// Batasi berapa banyak unduhan thumbnail yang berjalan bersamaan.
actor AsyncGate {
    private let limit: Int
    private var running = 0
    private var waiting: [CheckedContinuation<Void, Never>] = []

    init(limit: Int) {
        self.limit = limit
    }

    func acquire() async {
        if running < limit {
            running += 1
            return
        }
        await withCheckedContinuation { waiting.append($0) }
    }

    func release() {
        if waiting.isEmpty {
            running -= 1
        } else {
            waiting.removeFirst().resume()
        }
    }
}
