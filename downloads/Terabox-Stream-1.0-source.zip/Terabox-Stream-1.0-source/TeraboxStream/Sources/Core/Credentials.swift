import Foundation
import Security

/// Cookie login Terabox (ndus) disimpan di Keychain. Nilainya tidak pernah
/// ditampilkan atau dicetak ke log.
enum CookieKeychain {
    private static let service = "com.walendra.TeraboxStream"
    private static let account = "terabox-cookie"

    private static var baseQuery: [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: service,
         kSecAttrAccount as String: account]
    }

    static func load() -> String? {
        var query = baseQuery
        query[kSecReturnData as String] = true
        query[kSecMatchLimit as String] = kSecMatchLimitOne
        var out: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &out) == errSecSuccess,
              let data = out as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    static func save(_ cookie: String) throws {
        let data = Data(cookie.utf8)
        let status = SecItemUpdate(baseQuery as CFDictionary, [kSecValueData as String: data] as CFDictionary)
        if status == errSecItemNotFound {
            var add = baseQuery
            add[kSecValueData as String] = data
            add[kSecAttrLabel as String] = "Terabox Stream: cookie login"
            let s = SecItemAdd(add as CFDictionary, nil)
            guard s == errSecSuccess else { throw keychainError(s) }
        } else if status != errSecSuccess {
            throw keychainError(status)
        }
    }

    static func delete() {
        SecItemDelete(baseQuery as CFDictionary)
    }

    private static func keychainError(_ status: OSStatus) -> TeraboxError {
        let msg = SecCopyErrorMessageString(status, nil) as String? ?? "kode \(status)"
        return .message("Cookie tidak bisa disimpan ke Keychain: \(msg)")
    }
}

enum CookieText {
    /// Sama seperti load_cookie() di CLI: kalau isinya cuma nilai, anggap itu ndus.
    static func normalize(_ raw: String) -> String? {
        let s = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if s.isEmpty { return nil }
        return s.contains("=") ? s : "ndus=\(s)"
    }

    static func hasNdus(_ cookie: String) -> Bool {
        parseCookieString(cookie).contains { $0.0 == "ndus" && !$0.1.isEmpty }
    }
}
