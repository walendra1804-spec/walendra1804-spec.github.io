import Foundation
import Synchronization

let browserUserAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
    + "(KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36"

/// Cookie sesi dari server (Set-Cookie), disimpan sendiri supaya bisa digabung
/// dengan cookie login user di setiap request (seperti MergedCookieProcessor di CLI).
final class CookieJar: Sendable {
    struct Cookie: Sendable {
        let name: String
        let value: String
        let domain: String
        let path: String
        let expires: Date?
    }

    private let cookies = Mutex<[Cookie]>([])

    func store(from response: HTTPURLResponse) {
        guard let url = response.url,
              let fields = response.allHeaderFields as? [String: String] else { return }
        let parsed = HTTPCookie.cookies(withResponseHeaderFields: fields, for: url).map {
            Cookie(name: $0.name, value: $0.value, domain: $0.domain.lowercased(),
                   path: $0.path, expires: $0.expiresDate)
        }
        guard !parsed.isEmpty else { return }
        cookies.withLock { list in
            for c in parsed {
                list.removeAll { $0.name == c.name && $0.domain == c.domain && $0.path == c.path }
                list.append(c)
            }
        }
    }

    func cookies(for url: URL) -> [(String, String)] {
        guard let host = url.host()?.lowercased() else { return [] }
        let path = url.path().isEmpty ? "/" : url.path()
        let now = Date.now
        return cookies.withLock { list in
            list.filter { c in
                Self.domain(c.domain, matches: host) && path.hasPrefix(c.path)
                    && (c.expires.map { $0 > now } ?? true)
            }.map { ($0.name, $0.value) }
        }
    }

    func value(named name: String, host: String) -> String? {
        let host = host.lowercased()
        return cookies.withLock { list in
            list.first { $0.name == name && Self.domain($0.domain, matches: host) }?.value
        }
    }

    private static func domain(_ domain: String, matches host: String) -> Bool {
        let bare = domain.hasPrefix(".") ? String(domain.dropFirst()) : domain
        return host == bare || host.hasSuffix("." + bare)
    }
}

func parseCookieString(_ raw: String?) -> [(String, String)] {
    (raw ?? "").split(separator: ";").compactMap { part in
        guard let eq = part.firstIndex(of: "=") else { return nil }
        let k = part[..<eq].trimmingCharacters(in: .whitespaces)
        let v = part[part.index(after: eq)...].trimmingCharacters(in: .whitespaces)
        return k.isEmpty ? nil : (k, v)
    }
}

/// Klien HTTP dengan pengelolaan cookie manual. Cookie login user dikirim ke
/// semua host Terabox (termasuk host CDN setelah redirect), sama seperti CLI.
final class HTTPClient: Sendable {
    let jar: CookieJar?
    private let userCookies: [(String, String)]
    private let session: URLSession

    init(userCookie: String?, keepsSessionCookies: Bool = true) {
        jar = keepsSessionCookies ? CookieJar() : nil
        let pairs = parseCookieString(userCookie)
        userCookies = pairs
        let config = URLSessionConfiguration.ephemeral
        config.httpCookieStorage = nil
        config.httpShouldSetCookies = false
        config.httpCookieAcceptPolicy = .never
        config.urlCache = nil
        config.requestCachePolicy = .reloadIgnoringLocalCacheData
        config.timeoutIntervalForRequest = 60
        config.httpMaximumConnectionsPerHost = 6
        session = URLSession(configuration: config)
    }

    var hasUserCookie: Bool { !userCookies.isEmpty }

    func cookieHeader(for url: URL) -> String? {
        var merged: [(String, String)] = jar?.cookies(for: url) ?? []
        for (k, v) in userCookies {
            merged.removeAll { $0.0 == k }
            merged.append((k, v))
        }
        return merged.isEmpty ? nil : merged.map { "\($0.0)=\($0.1)" }.joined(separator: "; ")
    }

    func prepared(_ request: URLRequest) -> URLRequest {
        var r = request
        if r.value(forHTTPHeaderField: "User-Agent") == nil {
            r.setValue(browserUserAgent, forHTTPHeaderField: "User-Agent")
        }
        if let url = r.url {
            r.setValue(cookieHeader(for: url), forHTTPHeaderField: "Cookie")
        }
        return r
    }

    /// Request biasa; seluruh body dibaca ke memori (untuk API dan halaman).
    func data(for request: URLRequest) async throws -> (Data, HTTPURLResponse) {
        let delegate = RedirectHandler(client: self)
        let (data, response) = try await session.data(for: prepared(request), delegate: delegate)
        guard let http = response as? HTTPURLResponse else { throw TeraboxError.message("Respons bukan HTTP") }
        jar?.store(from: http)
        return (data, http)
    }

    /// Request yang body-nya dialirkan per potongan (untuk download dan streaming).
    func stream(for request: URLRequest) async throws -> (HTTPURLResponse, ResponseBody) {
        let handler = StreamingHandler(client: self)
        let task = session.dataTask(with: prepared(request))
        return try await handler.start(task)
    }
}

/// Saat redirect: simpan cookie dari respons redirect, salin header asli
/// (Range, Referer, dst.) dan pasang ulang cookie untuk host tujuan.
class RedirectHandler: NSObject, URLSessionTaskDelegate, @unchecked Sendable {
    let client: HTTPClient

    init(client: HTTPClient) {
        self.client = client
    }

    func urlSession(_ session: URLSession, task: URLSessionTask,
                    willPerformHTTPRedirection response: HTTPURLResponse,
                    newRequest request: URLRequest) async -> URLRequest? {
        client.jar?.store(from: response)
        var r = request
        for (k, v) in task.originalRequest?.allHTTPHeaderFields ?? [:]
        where k.lowercased() != "cookie" && r.value(forHTTPHeaderField: k) == nil {
            r.setValue(v, forHTTPHeaderField: k)
        }
        if let url = r.url {
            r.setValue(client.cookieHeader(for: url), forHTTPHeaderField: "Cookie")
        }
        return r
    }
}

/// Mengalirkan body respons sebagai potongan Data dengan kontrol aliran:
/// kalau konsumen lambat (mis. AVPlayer sedang tidak membaca), task di-suspend
/// supaya memori tidak membengkak.
final class StreamingHandler: RedirectHandler, URLSessionDataDelegate, @unchecked Sendable {
    private struct State {
        var responseContinuation: CheckedContinuation<HTTPURLResponse, Error>?
        var pending = 0
        var suspended = false
        var task: URLSessionDataTask?
    }

    private static let highWater = 8 * 1024 * 1024
    private static let lowWater = 2 * 1024 * 1024

    private let state = Mutex(State())
    let chunks: AsyncThrowingStream<Data, Error>
    private let continuation: AsyncThrowingStream<Data, Error>.Continuation

    override init(client: HTTPClient) {
        (chunks, continuation) = AsyncThrowingStream.makeStream(of: Data.self, throwing: Error.self)
        super.init(client: client)
    }

    func start(_ task: URLSessionDataTask) async throws -> (HTTPURLResponse, ResponseBody) {
        let response = try await withTaskCancellationHandler {
            try await withCheckedThrowingContinuation { (cont: CheckedContinuation<HTTPURLResponse, Error>) in
                state.withLock {
                    $0.responseContinuation = cont
                    $0.task = task
                }
                task.delegate = self
                task.resume()
            }
        } onCancel: {
            task.cancel()
        }
        return (response, ResponseBody(handler: self))
    }

    func cancel() {
        let task = state.withLock { $0.task }
        task?.cancel()
    }

    func consumed(_ count: Int) {
        let toResume: URLSessionDataTask? = state.withLock { s in
            s.pending -= count
            if s.suspended && s.pending < Self.lowWater {
                s.suspended = false
                return s.task
            }
            return nil
        }
        toResume?.resume()
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive response: URLResponse,
                    completionHandler: @escaping @Sendable (URLSession.ResponseDisposition) -> Void) {
        let cont = state.withLock { s in
            defer { s.responseContinuation = nil }
            return s.responseContinuation
        }
        if let http = response as? HTTPURLResponse {
            client.jar?.store(from: http)
            completionHandler(.allow)
            cont?.resume(returning: http)
        } else {
            completionHandler(.cancel)
            cont?.resume(throwing: TeraboxError.message("Respons bukan HTTP"))
        }
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        continuation.yield(data)
        let shouldSuspend = state.withLock { s in
            s.pending += data.count
            if !s.suspended && s.pending > Self.highWater {
                s.suspended = true
                return true
            }
            return false
        }
        if shouldSuspend { dataTask.suspend() }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        let cont = state.withLock { s in
            defer {
                s.responseContinuation = nil
                s.task = nil
            }
            return s.responseContinuation
        }
        if let error {
            cont?.resume(throwing: error)
            continuation.finish(throwing: error)
        } else {
            cont?.resume(throwing: TeraboxError.message("Koneksi ditutup tanpa respons"))
            continuation.finish()
        }
    }
}

struct ResponseBody: Sendable {
    fileprivate let handler: StreamingHandler

    /// Panggil `body` untuk setiap potongan data. Koneksi ke server selalu
    /// ditutup setelah selesai, gagal, atau dibatalkan.
    func forEach(_ body: (Data) async throws -> Void) async throws {
        defer { handler.cancel() }
        try await withTaskCancellationHandler {
            for try await chunk in handler.chunks {
                try await body(chunk)
                handler.consumed(chunk.count)
            }
        } onCancel: {
            handler.cancel()
        }
    }

    func collect(limit: Int = 4 * 1024 * 1024) async throws -> Data {
        struct LimitReached: Error {}
        var all = Data()
        do {
            try await forEach { chunk in
                all.append(chunk)
                if all.count >= limit { throw LimitReached() }
            }
        } catch is LimitReached {}
        return all
    }

    func cancel() {
        handler.cancel()
    }
}
