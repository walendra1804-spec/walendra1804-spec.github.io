import Foundation

// Perpustakaan: file .tblink = "alamat permanen" sebuah file Terabox.
// Isinya bukan dlink (kedaluwarsa sekitar 1 jam), tapi link share + fs_id,
// sehingga dlink segar bisa diminta ulang setiap kali diputar.
// Format file sama persis dengan save_links() di terabox.py.

let linkExtension = "tblink"

struct LinkEntry: Codable, Sendable, Hashable {
    var type: String = "terabox-stream"
    var version: Int = 1
    var name: String
    var path: String
    var size: Int64
    var md5: String?
    var category: Int?
    var fsId: Int64
    var shareLink: String
    var pwd: String?
    var shareid: Int64?
    var uk: Int64?
    var savedAt: String?

    enum CodingKeys: String, CodingKey {
        case type, version, name, path, size, md5, category
        case fsId = "fs_id"
        case shareLink = "share_link"
        case pwd, shareid, uk
        case savedAt = "saved_at"
    }

    var file: ShareFile {
        ShareFile(fsId: fsId, name: name, rel: path, size: size, md5: md5 ?? "", category: category ?? 0)
    }

    static func read(_ url: URL) throws -> LinkEntry {
        let entry = try JSONDecoder().decode(LinkEntry.self, from: Data(contentsOf: url))
        guard entry.type == "terabox-stream" else {
            throw TeraboxError.message("Bukan file .\(linkExtension) yang valid: \(url.lastPathComponent)")
        }
        return entry
    }

    /// JSON dengan urutan kunci dan indentasi seperti json.dump(indent=2, ensure_ascii=False).
    func pythonStyleJSON() -> String {
        func num(_ v: Int64?) -> String { v.map(String.init) ?? "null" }
        let fields: [(String, String)] = [
            ("type", PyCompat.jsonString(type)),
            ("version", String(version)),
            ("name", PyCompat.jsonString(name)),
            ("path", PyCompat.jsonString(path)),
            ("size", String(size)),
            ("md5", PyCompat.jsonString(md5 ?? "")),
            ("category", String(category ?? 0)),
            ("fs_id", String(fsId)),
            ("share_link", PyCompat.jsonString(shareLink)),
            ("pwd", PyCompat.jsonString(pwd ?? "")),
            ("shareid", num(shareid)),
            ("uk", num(uk)),
            ("saved_at", PyCompat.jsonString(savedAt ?? "")),
        ]
        return "{\n" + fields.map { "  \"\($0.0)\": \($0.1)" }.joined(separator: ",\n") + "\n}"
    }

    /// Waktu UTC seperti datetime.now(timezone.utc).isoformat(timespec="seconds").
    static func nowStamp() -> String {
        var style = Date.ISO8601FormatStyle(timeZone: .gmt)
        style = style.year().month().day().dateTimeSeparator(.standard).time(includingFractionalSeconds: false)
        return Date.now.formatted(style) + "+00:00"
    }
}

/// Satu baris pohon Perpustakaan: folder atau file .tblink.
struct LibraryNode: Identifiable, Hashable, Sendable {
    var id: URL { url }
    let url: URL
    let name: String
    let entry: LinkEntry?
    let children: [LibraryNode]?

    var count: Int {
        entry != nil ? 1 : (children ?? []).reduce(0) { $0 + $1.count }
    }

    var totalSize: Int64 {
        entry?.size ?? (children ?? []).reduce(0) { $0 + $1.totalSize }
    }
}

enum LibraryFiles {
    static func save(_ files: [ShareFile], link: String, pwd: String?, summary: ShareSummary,
                     to root: URL) throws -> [URL] {
        var saved: [URL] = []
        for f in files {
            let parts = f.rel.split(separator: "/", omittingEmptySubsequences: false).map { PyCompat.safeName(String($0)) }
            var dest = root
            for p in parts.dropLast() { dest.append(path: p, directoryHint: .isDirectory) }
            try FileManager.default.createDirectory(at: dest, withIntermediateDirectories: true)
            dest.append(path: parts.last! + "." + linkExtension, directoryHint: .notDirectory)
            let entry = LinkEntry(name: f.name, path: f.rel, size: f.size, md5: f.md5, category: f.category,
                                  fsId: f.fsId, shareLink: link, pwd: pwd ?? "", shareid: summary.shareid,
                                  uk: summary.uk, savedAt: LinkEntry.nowStamp())
            try Data(entry.pythonStyleJSON().utf8).write(to: dest, options: .atomic)
            saved.append(dest)
        }
        return saved
    }

    static func scan(_ root: URL) -> [LibraryNode] {
        let fm = FileManager.default
        guard let names = try? fm.contentsOfDirectory(at: root, includingPropertiesForKeys: [.isDirectoryKey],
                                                      options: [.skipsHiddenFiles]) else { return [] }
        var folders: [LibraryNode] = []
        var items: [LibraryNode] = []
        for url in names {
            let isDir = (try? url.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) ?? false
            if isDir {
                let kids = scan(url)
                if !kids.isEmpty {
                    folders.append(LibraryNode(url: url, name: url.lastPathComponent, entry: nil, children: kids))
                }
            } else if url.pathExtension == linkExtension, let entry = try? LinkEntry.read(url) {
                items.append(LibraryNode(url: url, name: entry.name, entry: entry, children: nil))
            }
        }
        let byName: (LibraryNode, LibraryNode) -> Bool = {
            $0.name.localizedStandardCompare($1.name) == .orderedAscending
        }
        return folders.sorted(by: byName) + items.sorted(by: byName)
    }
}
