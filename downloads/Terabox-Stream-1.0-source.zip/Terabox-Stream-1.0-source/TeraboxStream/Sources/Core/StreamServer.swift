import Foundation
import Network
import Synchronization

/// Server HTTP kecil di 127.0.0.1 untuk AVPlayer, sama seperti server lokal di CLI.
/// AVPlayer tidak bisa menyisipkan cookie Terabox atau memperbarui dlink yang
/// kedaluwarsa, jadi semua request lewat sini:
///   /p/<token>/stream.<ext>   file asli, mendukung Range (seek)
///   /p/<token>/stream.m3u8    playlist HLS (diambil dengan cookie)
///   /p/<token>/seg?u=...      segmen HLS (diteruskan tanpa cookie)
actor StreamServer {
    static let shared = StreamServer()

    private struct Entry: Sendable {
        let source: PlaybackSource
        let mime: String
        let size: Int64
    }

    private var entries: [String: Entry] = [:]
    private var startTask: Task<UInt16, Error>?
    private nonisolated let queue = DispatchQueue(label: "TeraboxStream.server")

    /// Daftarkan sumber, kembalikan URL lokal yang bisa diputar AVPlayer.
    func register(_ source: PlaybackSource, file: ShareFile) async throws -> (token: String, url: URL) {
        let port = try await start()
        let token = UUID().uuidString.lowercased()
        let mime = FileKinds.mimeType(for: file.name)
        entries[token] = Entry(source: source, mime: mime, size: file.size)
        let ext = (file.name as NSString).pathExtension.lowercased()
        let path: String
        switch source {
        case .hls: path = "stream.m3u8"
        case .direct: path = ext.isEmpty ? "stream" : "stream.\(ext)"
        }
        return (token, URL(string: "http://127.0.0.1:\(port)/p/\(token)/\(path)")!)
    }

    func unregister(_ token: String) {
        entries[token] = nil
    }

    private func entry(_ token: String) -> Entry? {
        entries[token]
    }

    private func start() async throws -> UInt16 {
        if let startTask { return try await startTask.value }
        let task = Task { try await listen() }
        startTask = task
        do {
            return try await task.value
        } catch {
            startTask = nil
            throw error
        }
    }

    private func listen() async throws -> UInt16 {
        let params = NWParameters.tcp
        params.requiredLocalEndpoint = .hostPort(host: "127.0.0.1", port: .any)
        let listener = try NWListener(using: params)
        listener.newConnectionHandler = { [weak self] connection in
            guard let self else { return connection.cancel() }
            connection.start(queue: self.queue)
            Task { await self.serve(connection) }
        }
        let once = Once()
        return try await withCheckedThrowingContinuation { (cont: CheckedContinuation<UInt16, Error>) in
            listener.stateUpdateHandler = { state in
                switch state {
                case .ready:
                    if once.claim() {
                        cont.resume(returning: listener.port?.rawValue ?? 0)
                    }
                case .failed(let error):
                    if once.claim() { cont.resume(throwing: error) }
                default:
                    break
                }
            }
            listener.start(queue: queue)
        }
    }

    // MARK: Melayani satu koneksi

    private nonisolated func serve(_ c: NWConnection) async {
        defer { c.cancel() }
        guard let head = try? await Self.readHead(c) else { return }
        let lines = head.split(separator: "\r\n", omittingEmptySubsequences: false)
        let parts = lines.first?.split(separator: " ") ?? []
        guard parts.count >= 2 else { return }
        let method = String(parts[0])
        var headers: [String: String] = [:]
        for line in lines.dropFirst() {
            guard let colon = line.firstIndex(of: ":") else { continue }
            headers[line[..<colon].lowercased()] = line[line.index(after: colon)...].trimmingCharacters(in: .whitespaces)
        }
        guard method == "GET" || method == "HEAD",
              let comps = URLComponents(string: "http://127.0.0.1" + parts[1]) else {
            try? await Self.respond(c, status: 405, headers: [:], body: Data())
            return
        }
        let segments = comps.path.split(separator: "/").map(String.init)
        guard segments.count == 3, segments[0] == "p", let entry = await entry(segments[1]) else {
            try? await Self.respond(c, status: 404, headers: [:], body: Data())
            return
        }
        let sendBody = method == "GET"
        Self.debug("\(method) \(segments[2].prefix(40)) range=\(headers["range"] ?? "-")")
        do {
            switch (entry.source, segments[2]) {
            case (.hls(let src), "stream.m3u8"):
                let text = try await src.playlist()
                try await Self.respond(c, status: 200, headers: ["Content-Type": "application/vnd.apple.mpegurl",
                                                                  "Cache-Control": "no-store"],
                                       body: sendBody ? Data(text.utf8) : Data(), length: text.utf8.count)
            case (.hls(let src), "seg"):
                guard let u = comps.queryItems?.first(where: { $0.name == "u" })?.value, let url = URL(string: u) else {
                    throw TeraboxError.message("Alamat segmen kosong")
                }
                let (resp, body) = try await src.openSegment(url)
                if resp.statusCode >= 400 { throw await httpFailure(resp, body) }
                try await Self.pipe(c, resp, body, mime: "video/mp2t", ranges: false, sendBody: sendBody)
            case (.direct(let src), let name) where name.hasPrefix("stream"):
                switch try await src.open(range: headers["range"]) {
                case .ok(let resp, let body):
                    try await Self.pipe(c, resp, body, mime: entry.mime, ranges: true, sendBody: sendBody)
                case .rangeNotSatisfiable:
                    try await Self.respond(c, status: 416, headers: ["Content-Range": "bytes */\(entry.size)"], body: Data())
                }
            default:
                try await Self.respond(c, status: 404, headers: [:], body: Data())
            }
        } catch {
            Self.debug("  selesai dengan error: \(error.localizedDescription)")
            // Player menutup koneksi saat seek atau berhenti: itu normal.
            let message = Data(error.localizedDescription.prefix(300).utf8)
            try? await Self.respond(c, status: 502, headers: ["Content-Type": "text/plain; charset=utf-8"], body: message)
        }
    }

    private static func pipe(_ c: NWConnection, _ resp: HTTPURLResponse, _ body: ResponseBody,
                             mime: String, ranges: Bool, sendBody: Bool) async throws {
        var headers = ["Content-Type": mime]
        if ranges {
            headers["Accept-Ranges"] = "bytes"
            if let cr = resp.value(forHTTPHeaderField: "Content-Range") { headers["Content-Range"] = cr }
        }
        let length = resp.value(forHTTPHeaderField: "Content-Length").flatMap(Int.init)
        debug("  -> \(resp.statusCode) \(headers["Content-Range"] ?? "") len=\(length.map(String.init) ?? "?")")
        try await send(c, Data(headerBlock(status: resp.statusCode, headers: headers, length: length).utf8))
        var sent = 0
        if sendBody {
            try await body.forEach { chunk in
                try await send(c, chunk)
                sent += chunk.count
            }
        } else {
            body.cancel()
        }
        try await send(c, Data(), final: true)
        debug("  terkirim \(sent) byte")
    }

    private static let debugURL = ProcessInfo.processInfo.environment["STREAM_DEBUG"].map { URL(filePath: $0) }

    /// Log request ke file (hanya kalau STREAM_DEBUG diisi). Tidak pernah berisi cookie.
    static func debug(_ line: String) {
        guard let debugURL else { return }
        let data = Data("\(Date.now.formatted(.iso8601.time(includingFractionalSeconds: true))) \(line)\n".utf8)
        if let h = try? FileHandle(forWritingTo: debugURL) {
            _ = try? h.seekToEnd()
            try? h.write(contentsOf: data)
            try? h.close()
        } else {
            try? data.write(to: debugURL)
        }
    }

    private static func respond(_ c: NWConnection, status: Int, headers: [String: String],
                                body: Data, length: Int? = nil) async throws {
        var block = Data(headerBlock(status: status, headers: headers, length: length ?? body.count).utf8)
        block.append(body)
        try await send(c, block, final: true)
    }

    private static func headerBlock(status: Int, headers: [String: String], length: Int?) -> String {
        let reason = HTTPURLResponse.localizedString(forStatusCode: status).capitalized
        var s = "HTTP/1.1 \(status) \(reason)\r\n"
        for (k, v) in headers { s += "\(k): \(v)\r\n" }
        if let length { s += "Content-Length: \(length)\r\n" }
        s += "Connection: close\r\n\r\n"
        return s
    }

    private static func readHead(_ c: NWConnection) async throws -> String? {
        var buffer = Data()
        let end = Data("\r\n\r\n".utf8)
        while buffer.count < 64 * 1024 {
            let chunk: Data? = try await withCheckedThrowingContinuation { cont in
                c.receive(minimumIncompleteLength: 1, maximumLength: 16 * 1024) { data, _, isComplete, error in
                    if let error { cont.resume(throwing: error) }
                    else if let data, !data.isEmpty { cont.resume(returning: data) }
                    else { cont.resume(returning: isComplete ? nil : Data()) }
                }
            }
            guard let chunk else { return nil }
            buffer.append(chunk)
            if let r = buffer.range(of: end) {
                return String(decoding: buffer[..<r.lowerBound], as: UTF8.self)
            }
        }
        return nil
    }

    private static func send(_ c: NWConnection, _ data: Data, final: Bool = false) async throws {
        try await withCheckedThrowingContinuation { (cont: CheckedContinuation<Void, Error>) in
            c.send(content: data.isEmpty && final ? nil : data,
                   contentContext: final ? .finalMessage : .defaultMessage,
                   isComplete: final,
                   completion: .contentProcessed { error in
                       if let error { cont.resume(throwing: error) } else { cont.resume() }
                   })
        }
    }
}

private final class Once: Sendable {
    private let done = Atomic<Bool>(false)

    func claim() -> Bool {
        !done.exchange(true, ordering: .relaxed)
    }
}
