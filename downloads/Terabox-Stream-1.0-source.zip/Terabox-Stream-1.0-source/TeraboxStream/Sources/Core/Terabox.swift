import CryptoKit
import Foundation

// Port dari kelas TeraboxShare di terabox.py. Setiap langkah dan parameter
// sengaja dibuat sama dengan CLI yang sudah terbukti jalan.

enum TeraboxError: LocalizedError, Sendable {
    case message(String)
    case needPassword
    case wrongPassword
    case needLogin
    case api(String, errno: Int?)

    var errorDescription: String? {
        switch self {
        case .message(let m): m
        case .needPassword: "Link ini butuh kode akses."
        case .wrongPassword: "Kode akses salah."
        case .needLogin: "Terabox menolak permintaan ini tanpa login. Pilih Akun > Masuk ke Terabox, lalu coba lagi."
        case .api(let m, let errno):
            errno == needVerifyErrno
                ? "Terabox sedang membatasi permintaan (kode 400141). Tunggu beberapa menit, lalu coba lagi."
                : m
        }
    }

    var errno: Int? {
        if case .api(_, let e) = self { return e }
        return nil
    }
}

let needVerifyErrno = 400141
private let baseParams: [(String, String)] = [
    ("app_id", "250528"), ("web", "1"), ("channel", "dubox"), ("clienttype", "0"),
]
private let streamKey = Data("iuuPc64E4Fhn0rTXEzrnbLph0o5qyEEa".utf8)  // dari JS player web Terabox

/// Satu file di dalam share.
struct ShareFile: Sendable, Hashable {
    let fsId: Int64
    let name: String
    let rel: String
    let size: Int64
    let md5: String
    let category: Int
}

/// Satu baris pohon file: folder (punya children) atau file.
struct FileNode: Identifiable, Hashable, Sendable {
    let id: String  // path relatif, unik di dalam satu share
    let name: String
    let file: ShareFile?
    let children: [FileNode]?
    let totalSize: Int64
    /// Thumbnail dari Terabox (hanya gambar dan video). URL-nya bertanda tangan dan kedaluwarsa.
    var thumb: URL? = nil

    var isFolder: Bool { file == nil }

    var allFiles: [ShareFile] {
        if let file { return [file] }
        return (children ?? []).flatMap(\.allFiles)
    }
}

struct ShareSummary: Sendable, Equatable {
    let owner: String
    let shareid: Int64
    let uk: Int64
}

/// Item mentah dari share/list atau shorturlinfo.
private struct RawItem: Sendable {
    let fsId: Int64
    let name: String
    let path: String
    let isDir: Bool
    let size: Int64
    let md5: String
    let category: Int
    let thumb: URL?

    init?(_ d: [String: Any]) {
        guard let fsId = intValue(d["fs_id"]), let name = d["server_filename"] as? String else { return nil }
        self.fsId = fsId
        self.name = name
        path = d["path"] as? String ?? ""
        isDir = stringValue(d["isdir"]) == "1"
        size = intValue(d["size"]) ?? 0
        md5 = d["md5"] as? String ?? ""
        category = Int(intValue(d["category"]) ?? 0)
        // url3 paling besar (cukup untuk kartu grid), url1 paling kecil.
        let thumbs = d["thumbs"] as? [String: Any] ?? [:]
        thumb = ["url3", "url2", "url1"].lazy
            .compactMap { (thumbs[$0] as? String).flatMap(URL.init(string:)) }
            .first { $0.scheme == "https" || $0.scheme == "http" }
    }
}

actor TeraboxShare {
    nonisolated let link: String
    nonisolated let surl: String
    nonisolated let usesLogin: Bool
    private let cookie: String?
    private(set) var pwd: String?
    private var sekey: String?
    private let http: HTTPClient
    private(set) var host = URL(string: "https://www.terabox.app")!
    private var jsToken: String?
    private var info: [String: Any]?
    private var guestShare: TeraboxShare?
    private var dirTasks: [String: Task<[RawItem], Error>] = [:]

    init(link: String, cookie: String?, pwd: String? = nil) throws {
        let link = link.trimmingCharacters(in: .whitespacesAndNewlines)
        self.link = link
        surl = try Self.parseShortURL(link)
        self.cookie = cookie
        usesLogin = !(cookie ?? "").isEmpty
        let fromLink = Self.parsePwd(link)
        self.pwd = (pwd?.isEmpty == false ? pwd : nil) ?? fromLink
        http = HTTPClient(userCookie: cookie)
    }

    // MARK: Parsing link

    static func parseShortURL(_ link: String) throws -> String {
        let text = link.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let comps = URLComponents(string: text.contains("://") ? text : "https://" + text) else {
            throw TeraboxError.message("Link tidak dikenali: \(text)")
        }
        if let surl = comps.queryItems?.first(where: { $0.name == "surl" })?.value { return surl }
        if let m = comps.path.firstMatch(of: /\/s\/([A-Za-z0-9_-]+)/) {
            let code = String(m.1)
            return code.hasPrefix("1") ? String(code.dropFirst()) : code
        }
        throw TeraboxError.message("Ini bukan link share Terabox. Link yang benar berbentuk https://terabox.com/s/1abc…")
    }

    static func parsePwd(_ link: String) -> String? {
        let text = link.contains("://") ? link : "https://" + link
        return URLComponents(string: text)?.queryItems?.first { $0.name == "pwd" }?.value
    }

    // MARK: HTTP

    private func browserid() -> String {
        http.jar?.value(named: "browserid", host: host.host() ?? "") ?? ""
    }

    private var referer: String { "\(host.absoluteString)/sharing/link?surl=\(surl)" }

    private func request(_ url: URL, referer: String? = nil, timeout: TimeInterval = 30) -> URLRequest {
        var r = URLRequest(url: url, timeoutInterval: timeout)
        r.setValue("application/json, text/plain, */*", forHTTPHeaderField: "Accept")
        if let referer { r.setValue(referer, forHTTPHeaderField: "Referer") }
        return r
    }

    private func api(_ path: String, _ params: [(String, String)] = [],
                     form: [(String, String)]? = nil) async throws -> [String: Any] {
        var p = baseParams
        if let jsToken { p.append(("jsToken", jsToken)) }
        let bid = browserid()
        if !bid.isEmpty { p.append(("devuid", bid)) }  // selalu dikirim oleh web Terabox
        for (k, v) in params {
            p.removeAll { $0.0 == k }
            p.append((k, v))
        }
        let url = URL(string: "\(host.absoluteString)\(path)?\(PyCompat.formEncode(p))")!
        var req = request(url, referer: referer)
        if let form {
            req.httpMethod = "POST"
            req.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
            req.httpBody = Data(PyCompat.formEncode(form).utf8)
        }
        for attempt in 0..<3 {
            let d: [String: Any]
            do {
                let (data, _) = try await http.data(for: req)
                guard let obj = try JSONSerialization.jsonObject(with: data) as? [String: Any] else {
                    throw TeraboxError.message("Respons \(path) bukan JSON")
                }
                d = obj
            } catch is CancellationError {
                throw CancellationError()
            } catch {
                if attempt == 2 { throw TeraboxError.message("Gagal menghubungi Terabox (\(path)): \(error.localizedDescription)") }
                try await Task.sleep(for: .seconds(1.5 * Double(attempt + 1)))
                continue
            }
            // 400141 "need verify" = pembatasan anti-bot yang sifatnya sementara
            if errno(d) == needVerifyErrno && attempt < 2 {
                try await Task.sleep(for: .seconds(2 + 3 * attempt))
                continue
            }
            return d
        }
        throw TeraboxError.message("Gagal menghubungi Terabox (\(path))")
    }

    private func errno(_ d: [String: Any]) -> Int? {
        intValue(d["errno"]).map { Int($0) }
    }

    private func describe(_ d: [String: Any]) -> String {
        let msg = (d["show_msg"] as? String) ?? (d["errmsg"] as? String) ?? (d["error_msg"] as? String) ?? ""
        return "errno=\(errno(d).map(String.init) ?? "?") \(msg)".trimmingCharacters(in: .whitespaces)
    }

    // MARK: Langkah-langkah

    /// Buka halaman share untuk dapat cookie sesi dan jsToken.
    func open() async throws {
        let url = URL(string: link.contains("://") ? link : "https://" + link)!
        var token: String?
        for attempt in 0..<3 {
            let (data, response): (Data, HTTPURLResponse)
            do {
                (data, response) = try await http.data(for: request(url))
            } catch is CancellationError {
                throw CancellationError()
            } catch {
                throw TeraboxError.message("Tidak bisa membuka link: \(error.localizedDescription)")
            }
            if let final = response.url, let scheme = final.scheme, let h = final.host() {
                host = URL(string: "\(scheme)://\(h)")!
            }
            let html = PyCompat.percentDecodeLeniently(String(decoding: data, as: UTF8.self))
            if let m = html.firstMatch(of: /fn\("([A-Fa-f0-9]{32,})"\)/) {
                token = String(m.1)
                break
            }
            if attempt < 2 {
                // kadang Terabox mengirim varian halaman tanpa token
                try await Task.sleep(for: .seconds(2 + 2 * attempt))
            }
        }
        guard let token else {
            throw TeraboxError.message("jsToken tidak ditemukan (format halaman Terabox mungkin berubah).")
        }
        jsToken = token
        if let pwd { try await verify(pwd) }
        try await refreshInfo()
    }

    /// Buka share berkode akses (seperti mengetik kode di web Terabox).
    func verify(_ code: String) async throws {
        let d = try await api("/share/verify", [("surl", surl)],
                              form: [("pwd", code), ("vcode", ""), ("vcode_str", "")])
        switch errno(d) {
        case 0: break
        case -9, -12: throw TeraboxError.wrongPassword
        case -62:
            throw TeraboxError.message("Terabox minta captcha karena terlalu banyak percobaan. Tunggu beberapa menit lalu coba lagi.")
        default:
            throw TeraboxError.api("Kode akses tidak bisa diperiksa: \(describe(d))", errno: errno(d))
        }
        pwd = code
        let randsk = PyCompat.percentDecodeLeniently(d["randsk"] as? String ?? "")
        sekey = randsk.isEmpty ? nil : randsk
    }

    func refreshInfo() async throws {
        let d = try await api("/api/shorturlinfo", [("shorturl", "1" + surl), ("root", "1")])
        let e = errno(d)
        if e == -9 { throw TeraboxError.needPassword }
        if e != 0 {
            let gone = [105, 2, -21, -4, -8].contains(e ?? 0)
            throw TeraboxError.api(gone ? "Link ini sudah dihapus atau kedaluwarsa (\(describe(d)))."
                                        : "Info share gagal dibaca: \(describe(d))", errno: e)
        }
        info = d
    }

    func summary() -> ShareSummary? {
        guard let info else { return nil }
        return ShareSummary(owner: info["share_username"] as? String ?? "",
                            shareid: intValue(info["shareid"]) ?? 0, uk: intValue(info["uk"]) ?? 0)
    }

    // MARK: Daftar file

    private func listDir(_ path: String?, fallback: Bool = true) async throws -> [RawItem] {
        do {
            return try await listDirRaw(path)
        } catch TeraboxError.api(let msg, let e) {
            guard fallback else { throw TeraboxError.api(msg, errno: e) }
            // Sebagian share menolak share/list ("need verify"). Web Terabox sendiri tidak
            // memanggil share/list untuk folder utama, jadi pakai data dari shorturlinfo.
            if path == nil, let list = info?["list"] as? [[String: Any]], !list.isEmpty {
                return Self.sorted(list.compactMap(RawItem.init))
            }
            if usesLogin {  // coba lagi sebagai tamu (tanpa cookie login)
                do {
                    return try await guest().listDir(path, fallback: false)
                } catch {}
            }
            throw TeraboxError.api(msg, errno: e)
        }
    }

    private func guest() async throws -> TeraboxShare {
        if let guestShare { return guestShare }
        let g = try TeraboxShare(link: link, cookie: nil, pwd: pwd)
        try await g.open()
        guestShare = g
        return g
    }

    private static func sorted(_ items: [RawItem]) -> [RawItem] {
        items.sorted { a, b in
            if a.isDir != b.isDir { return a.isDir }
            return a.name.lowercased() < b.name.lowercased()
        }
    }

    private func listDirRaw(_ path: String?) async throws -> [RawItem] {
        var items: [RawItem] = []
        var page = 1
        while true {
            // Parameter disamakan dengan web Terabox (num 20, by/order, tanpa root=0 untuk subfolder).
            var params: [(String, String)] = [("shorturl", surl), ("page", String(page)), ("num", "20"),
                                              ("by", "time"), ("order", "desc"), ("scene", "")]
            if let path { params.append(("dir", path)) } else { params.append(("root", "1")) }
            let d = try await api("/share/list", params)
            if errno(d) == -9 { throw TeraboxError.needPassword }
            if errno(d) != 0 {
                throw TeraboxError.api("Isi folder \(path ?? "/") gagal dibaca: \(describe(d))", errno: errno(d))
            }
            let batch = (d["list"] as? [[String: Any]] ?? []).compactMap(RawItem.init)
            items += batch
            if batch.count < 20 { return Self.sorted(items) }
            page += 1
        }
    }

    /// Rekursif: kembalikan pohon folder dan file.
    func walk(path: String? = nil, rel: String = "", onFolder: @Sendable (String) -> Void) async throws -> [FileNode] {
        var nodes: [FileNode] = []
        for it in try await listDir(path) {
            try Task.checkCancellation()
            let relPath = rel.isEmpty ? it.name : "\(rel)/\(it.name)"
            if it.isDir {
                onFolder(relPath)
                let kids = try await walk(path: it.path, rel: relPath, onFolder: onFolder)
                nodes.append(FileNode(id: relPath, name: it.name, file: nil, children: kids,
                                      totalSize: kids.reduce(0) { $0 + $1.totalSize }))
            } else {
                let f = ShareFile(fsId: it.fsId, name: it.name, rel: relPath, size: it.size,
                                  md5: it.md5, category: it.category)
                nodes.append(FileNode(id: relPath, name: it.name, file: f, children: nil, totalSize: it.size,
                                      thumb: it.thumb))
            }
        }
        return nodes
    }

    // MARK: Thumbnail

    /// Isi satu folder, disimpan selama share ini hidup (tiap folder cukup dibaca sekali).
    private func cachedList(_ path: String?) async throws -> [RawItem] {
        let key = path ?? "/"
        if let task = dirTasks[key] { return try await task.value }
        let task = Task { try await listDir(path) }
        dirTasks[key] = task
        do {
            return try await task.value
        } catch {
            dirTasks[key] = nil
            throw error
        }
    }

    /// Alamat thumbnail untuk file di Perpustakaan (.tblink tidak menyimpan thumbnail).
    /// Folder induknya dicari dari folder utama share, satu tingkat satu request.
    func thumbnailURL(rel: String, fsId: Int64) async throws -> URL? {
        var path: String?
        for part in rel.split(separator: "/").dropLast() {
            guard let dir = try await cachedList(path).first(where: { $0.isDir && $0.name == part }) else { return nil }
            path = dir.path
        }
        return try await cachedList(path).first { $0.fsId == fsId }?.thumb
    }

    /// Ambil gambar thumbnail (dari CDN Terabox, bukan API, jadi tidak memicu 400141).
    func thumbnailData(_ url: URL) async throws -> Data? {
        let (resp, body) = try await fetch(url)
        guard resp.statusCode < 400 else {
            body.cancel()
            return nil
        }
        let data = try await body.collect(limit: 3 * 1024 * 1024)
        return data.isEmpty ? nil : data
    }

    // MARK: Streaming dan download

    /// Playlist HLS seperti yang dipakai player web Terabox (butuh login).
    /// sign = HMAC-SHA1(clienttype + channel + browserid + timestamp).
    func m3u8(fsId: Int64, types: [String]) async throws -> (type: String, text: String) {
        guard let info else { throw TeraboxError.message("Share belum dibuka") }
        let bid = browserid()
        var last: [String: Any] = [:]
        for type in types {
            let ts = String(Int(Date.now.timeIntervalSince1970))
            let msg = "0dubox\(bid)\(ts)"
            let mac = HMAC<Insecure.SHA1>.authenticationCode(for: Data(msg.utf8), using: SymmetricKey(data: streamKey))
            let sign = mac.map { String(format: "%02x", $0) }.joined()
            let params: [(String, String)] = baseParams + [
                ("uk", stringValue(info["uk"]) ?? ""), ("shareid", stringValue(info["shareid"]) ?? ""),
                ("type", type), ("fid", String(fsId)), ("sign", sign), ("timestamp", ts),
                ("jsToken", jsToken ?? ""), ("esl", "1"), ("isplayer", "1"), ("ehps", "1"),
            ]
            let url = URL(string: "\(host.absoluteString)/share/streaming?\(PyCompat.formEncode(params))")!
            let (data, _) = try await http.data(for: request(url, referer: referer))
            let body = String(decoding: data, as: UTF8.self)
            if body.trimmingCharacters(in: .whitespacesAndNewlines).hasPrefix("#EXTM3U") {
                return (type, body)
            }
            last = (try? JSONSerialization.jsonObject(with: data) as? [String: Any])
                ?? ["show_msg": String(body.prefix(200))]
        }
        let e = errno(last)
        if e == 31045 || !usesLogin { throw TeraboxError.needLogin }
        throw TeraboxError.api("Streaming HLS ditolak: \(describe(last))", errno: e)
    }

    /// Minta direct link (berlaku sekitar 1 jam). Jangan pernah disimpan.
    func dlinks(_ fsIds: [Int64]) async throws -> [Int64: URL] {
        for attempt in 0..<2 {
            guard let info else { throw TeraboxError.message("Share belum dibuka") }
            let sk = sekey ?? PyCompat.percentDecodeLeniently(info["randsk"] as? String ?? "")
            let form: [(String, String)] = [
                ("encrypt", "0"),
                ("extra", "{\"sekey\": \(PyCompat.jsonString(sk))}"),
                ("fid_list", "[" + fsIds.map(String.init).joined(separator: ", ") + "]"),
                ("primaryid", stringValue(info["shareid"]) ?? ""),
                ("uk", stringValue(info["uk"]) ?? ""),
                ("product", "share"),
                ("type", "nolimit"),
            ]
            let d = try await api("/api/sharedownload",
                                  [("sign", stringValue(info["sign"]) ?? ""),
                                   ("timestamp", stringValue(info["timestamp"]) ?? "")], form: form)
            if errno(d) == 0 {
                var out: [Int64: URL] = [:]
                for item in d["list"] as? [[String: Any]] ?? [] {
                    if let id = intValue(item["fs_id"]), let s = item["dlink"] as? String, let u = URL(string: s) {
                        out[id] = u
                    }
                }
                return out
            }
            if attempt == 0 {  // sign kedaluwarsa: perbarui lalu coba lagi
                try await refreshInfo()
                continue
            }
            throw TeraboxError.api("Link unduhan ditolak: \(describe(d))", errno: errno(d))
        }
        return [:]
    }

    /// Buka dlink (atau URL CDN lain) dengan cookie, dan Range kalau ada.
    func fetch(_ url: URL, range: String? = nil) async throws -> (HTTPURLResponse, ResponseBody) {
        var r = request(url, referer: host.absoluteString + "/", timeout: 60)
        if let range { r.setValue(range, forHTTPHeaderField: "Range") }
        return try await http.stream(for: r)
    }
}

/// Ubah respons HTTP gagal jadi pesan yang jelas (31045 = butuh login).
func httpFailure(_ response: HTTPURLResponse, _ body: ResponseBody) async -> TeraboxError {
    let data = (try? await body.collect(limit: 600)) ?? Data()
    let text = String(decoding: data.prefix(300), as: UTF8.self)
    if text.contains("31045") || text.contains("user not exists") { return .needLogin }
    return .message("Server Terabox menjawab HTTP \(response.statusCode). \(text)")
}
