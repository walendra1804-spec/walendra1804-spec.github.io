import Foundation
import UniformTypeIdentifiers

// Pembantu kecil yang meniru perilaku fungsi standar Python di terabox.py,
// supaya request dan file .tblink yang dihasilkan sama persis dengan CLI.

enum PyCompat {
    /// Seperti urllib.parse.unquote: hanya %XX yang valid yang didekode.
    static func percentDecodeLeniently(_ s: String) -> String {
        let bytes = Array(s.utf8)
        var out: [UInt8] = []
        out.reserveCapacity(bytes.count)
        var i = 0
        while i < bytes.count {
            if bytes[i] == 0x25, i + 2 < bytes.count,
               let hi = hexValue(bytes[i + 1]), let lo = hexValue(bytes[i + 2]) {
                out.append(hi << 4 | lo)
                i += 3
            } else {
                out.append(bytes[i])
                i += 1
            }
        }
        return String(decoding: out, as: UTF8.self)
    }

    private static func hexValue(_ c: UInt8) -> UInt8? {
        switch c {
        case 0x30...0x39: c - 0x30
        case 0x41...0x46: c - 0x41 + 10
        case 0x61...0x66: c - 0x61 + 10
        default: nil
        }
    }

    /// Seperti urllib.parse.urlencode (quote_plus).
    static func formEncode(_ pairs: [(String, String)]) -> String {
        pairs.map { "\(quotePlus($0.0))=\(quotePlus($0.1))" }.joined(separator: "&")
    }

    static func quotePlus(_ s: String) -> String {
        var out = ""
        for b in s.utf8 {
            switch b {
            case 0x41...0x5A, 0x61...0x7A, 0x30...0x39, 0x5F, 0x2E, 0x2D, 0x7E:
                out.append(Character(UnicodeScalar(b)))
            case 0x20:
                out.append("+")
            default:
                out.append(String(format: "%%%02X", b))
            }
        }
        return out
    }

    /// Seperti urllib.parse.quote(s, safe="").
    static func quoteAll(_ s: String) -> String {
        quotePlus(s).replacing("+", with: "%20")
    }

    /// String JSON seperti json.dumps(..., ensure_ascii=False).
    static func jsonString(_ s: String) -> String {
        var out = "\""
        for scalar in s.unicodeScalars {
            switch scalar {
            case "\"": out += "\\\""
            case "\\": out += "\\\\"
            case "\n": out += "\\n"
            case "\r": out += "\\r"
            case "\t": out += "\\t"
            case "\u{08}": out += "\\b"
            case "\u{0C}": out += "\\f"
            default:
                if scalar.value < 0x20 {
                    out += String(format: "\\u%04x", scalar.value)
                } else {
                    out.unicodeScalars.append(scalar)
                }
            }
        }
        return out + "\""
    }

    /// Sama dengan safe_name() di terabox.py.
    static func safeName(_ name: String) -> String {
        var s = ""
        for scalar in name.unicodeScalars {
            if "<>:\"/\\|?*".unicodeScalars.contains(scalar) || scalar.value < 0x20 {
                s += "_"
            } else {
                s.unicodeScalars.append(scalar)
            }
        }
        s = s.trimmingCharacters(in: .whitespacesAndNewlines)
        while s.hasSuffix(".") { s.removeLast() }
        return s.isEmpty ? "_" : s
    }
}

func intValue(_ any: Any?) -> Int64? {
    switch any {
    case let n as NSNumber: n.int64Value
    case let s as String: Int64(s.trimmingCharacters(in: .whitespaces))
    default: nil
    }
}

func stringValue(_ any: Any?) -> String? {
    switch any {
    case let s as String: s
    case let n as NSNumber: n.stringValue
    default: nil
    }
}

extension Int64 {
    var fileSize: String { formatted(.byteCount(style: .file)) }
}

// MARK: - Jenis file

enum MediaKind: Sendable, Equatable {
    case video, audio, image, other
}

enum FileKinds {
    static func mimeType(for name: String) -> String {
        let ext = (name as NSString).pathExtension.lowercased()
        let extra = ["mkv": "video/x-matroska", "m4a": "audio/mp4", "flac": "audio/flac",
                     "ts": "video/mp2t", "webm": "video/webm"]
        if let m = extra[ext] { return m }
        return UTType(filenameExtension: ext)?.preferredMIMEType ?? "application/octet-stream"
    }

    /// Sama seperti pick_source(): kategori Terabox (1 video, 2 audio) atau tebakan dari nama file.
    static func kind(name: String, category: Int) -> MediaKind {
        let mime = mimeType(for: name)
        if category == 1 || mime.hasPrefix("video/") { return .video }
        if category == 2 || mime.hasPrefix("audio/") { return .audio }
        if mime.hasPrefix("image/") { return .image }
        return .other
    }

    static func symbol(name: String, category: Int) -> String {
        let ext = (name as NSString).pathExtension.lowercased()
        if ext == "livp" { return "livephoto" }
        switch kind(name: name, category: category) {
        case .video: return "film"
        case .audio: return "music.note"
        case .image: return "photo"
        case .other:
            if let t = UTType(filenameExtension: ext) {
                if t.conforms(to: .archive) { return "doc.zipper" }
                if t.conforms(to: .pdf) { return "doc.richtext" }
                if t.conforms(to: .text) { return "doc.text" }
            }
            return "doc"
        }
    }

    static func description(name: String) -> String {
        let ext = (name as NSString).pathExtension.lowercased()
        if ext == "livp" { return "Live Photo" }
        if let t = UTType(filenameExtension: ext), !t.isDynamic, let d = t.localizedDescription {
            return d
        }
        return ext.isEmpty ? "Berkas" : "Berkas \(ext.uppercased())"
    }
}
