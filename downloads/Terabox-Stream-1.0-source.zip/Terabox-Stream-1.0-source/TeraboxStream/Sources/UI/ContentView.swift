import SwiftUI

struct ContentView: View {
    @Environment(AppModel.self) private var model

    var body: some View {
        @Bindable var model = model
        NavigationSplitView {
            SidebarView()
                .navigationSplitViewColumnWidth(min: 210, ideal: 250, max: 380)
        } detail: {
            DetailView()
        }
        .inspector(isPresented: $model.showInspector) {
            InspectorView()
                .inspectorColumnWidth(min: 250, ideal: 290, max: 420)
        }
        .toolbar {
            ToolbarItem(placement: .principal) {
                LinkField()
            }
            ToolbarItem(placement: .primaryAction) {
                Button {
                    model.showInspector.toggle()
                } label: {
                    Label("Info", systemImage: "info.circle")
                }
                .help("Tampilkan atau sembunyikan info")
            }
        }
        .onChange(of: model.sidebar) { _, item in
            model.preview.stop()
            if case .library(let url) = item { model.playLibraryItem(url) }
        }
        .sheet(isPresented: $model.showLogin) {
            LoginSheet()
        }
        .alert("Ada masalah", isPresented: Binding(
            get: { model.errorMessage != nil },
            set: { if !$0 { model.errorMessage = nil } }
        )) {
            Button("OK", role: .cancel) {}
        } message: {
            Text(model.errorMessage ?? "")
        }
    }
}

/// Kolom link di toolbar, seperti kolom alamat di Safari.
struct LinkField: View {
    @Environment(AppModel.self) private var model
    @FocusState private var focused: Bool

    var body: some View {
        @Bindable var model = model
        HStack(spacing: 6) {
            TextField("Tempel link share Terabox", text: $model.linkText)
                .textFieldStyle(.roundedBorder)
                .focused($focused)
                .onSubmit { model.openLink() }
                .frame(minWidth: 280, idealWidth: 440, maxWidth: 560)
            Button("Buka") { model.openLink() }
                .disabled(model.linkText.trimmingCharacters(in: .whitespaces).isEmpty)
        }
        .onChange(of: model.linkFieldFocusRequest) {
            focused = true
        }
    }
}

extension EnvironmentValues {
    /// Halaman sedang tertutup pemutar (tetap ada supaya posisi scroll-nya tidak hilang).
    @Entry var pageCovered = false
}

struct DetailView: View {
    @Environment(AppModel.self) private var model

    var body: some View {
        let covered = model.isShowingPlayer
        ZStack {
            page
                .opacity(covered ? 0 : 1)
                .allowsHitTesting(!covered)
                .accessibilityHidden(covered)
                .environment(\.pageCovered, covered)
            if covered {
                PlayerView()
                    .background(.background)
            }
        }
        // Judul diatur di satu tempat, karena halaman yang tertutup tetap ada di bawah pemutar.
        .navigationTitle(title.0)
        .navigationSubtitle(title.1)
    }

    @ViewBuilder
    private var page: some View {
        switch model.page {
        case .downloads:
            DownloadsView()
        case .libraryFolder(let url):
            LibraryPage(folder: url)
        default:
            if let browser = model.browser {
                ShareBrowserView(browser: browser)
            } else {
                EmptyLinkView()
            }
        }
    }

    private var title: (String, String) {
        if model.isShowingPlayer {
            let current = model.player.current
            return (current?.file.name ?? "Pemutar", current?.folderPath ?? "")
        }
        switch model.page {
        case .downloads:
            let active = model.downloads.activeCount
            return ("Unduhan", active > 0 ? "\(active) berjalan atau menunggu" : "")
        case .libraryFolder(let url):
            let library = model.library
            let isRoot = url == library.root
            let count = isRoot ? library.count : library.folderNode(url)?.count ?? 0
            return (isRoot ? "Perpustakaan" : url.lastPathComponent, count == 0 ? "" : "\(count) item tersimpan")
        default:
            guard let browser = model.browser else { return ("Terabox Stream", "") }
            return (browser.title, browser.summaryLine)
        }
    }
}

struct EmptyLinkView: View {
    @Environment(AppModel.self) private var model

    var body: some View {
        ContentUnavailableView {
            Label("Belum ada link yang dibuka", systemImage: "link")
        } description: {
            Text("Tempel link share Terabox di kolom atas lalu tekan Return. Semua folder dan subfoldernya akan tampil di sini.")
        } actions: {
            if model.clipboardHasLink {
                Button("Buka Link dari Papan Klip") { model.openFromClipboard() }
                    .buttonStyle(.borderedProminent)
            }
        }
    }
}
