import SwiftUI

struct DownloadsView: View {
    @Environment(AppModel.self) private var model
    @Environment(\.pageCovered) private var covered

    var body: some View {
        let jobs = model.downloads.jobs
        Group {
            if jobs.isEmpty {
                ContentUnavailableView {
                    Label("Belum ada unduhan", systemImage: "arrow.down.circle")
                } description: {
                    Text("Buka link, pilih file, lalu klik Unduh. File disimpan ke \(model.downloads.folder.path(percentEncoded: false)) dengan susunan folder yang sama seperti di Terabox.")
                }
            } else {
                List {
                    ForEach(jobs) { job in
                        DownloadRow(job: job)
                    }
                }
                .listStyle(.inset)
            }
        }
        .toolbar {
            if !covered {
            ToolbarItemGroup(placement: .primaryAction) {
                Button {
                    NSWorkspace.shared.open(model.downloads.folder)
                } label: {
                    Label("Buka Folder Unduhan", systemImage: "folder")
                }
                .help("Buka folder unduhan di Finder")
                Button {
                    model.downloads.clearFinished()
                } label: {
                    Label("Bersihkan yang Selesai", systemImage: "eraser")
                }
                .help("Hapus yang sudah selesai dari daftar (file tetap ada)")
                .disabled(!jobs.contains { $0.isFinished })
            }
            }
        }
    }
}

private struct DownloadRow: View {
    @Environment(AppModel.self) private var model
    let job: DownloadJob

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: FileKinds.symbol(name: job.file.name, category: job.file.category))
                .font(.title2)
                .foregroundStyle(.secondary)
                .frame(width: 28)
            VStack(alignment: .leading, spacing: 4) {
                Text(job.file.name)
                    .lineLimit(1)
                    .truncationMode(.middle)
                if job.state == .running || job.state == .waiting {
                    ProgressView(value: job.state == .running ? job.fraction : 0)
                        .progressViewStyle(.linear)
                        .controlSize(.small)
                }
                Text(statusText)
                    .font(.caption)
                    .foregroundStyle(isFailure ? AnyShapeStyle(.red) : AnyShapeStyle(.secondary))
                    .monospacedDigit()
                    .lineLimit(2)
                    .textSelection(.enabled)
            }
            Spacer(minLength: 8)
            actions
        }
        .padding(.vertical, 4)
        .contentShape(.rect)
        .onTapGesture(count: 2) {
            if job.isFinished { NSWorkspace.shared.open(job.destination) }
        }
        .contextMenu {
            if job.isFinished {
                Button("Buka") { NSWorkspace.shared.open(job.destination) }
                Button("Tampilkan di Finder") { NSWorkspace.shared.activateFileViewerSelecting([job.destination]) }
            }
            if job.isActive { Button("Hentikan") { model.downloads.stop(job) } }
            if !job.isActive && !job.isFinished { Button("Coba Lagi") { model.downloads.retry(job) } }
            Divider()
            Button("Hapus dari Daftar") { model.downloads.remove(job) }
        }
    }

    @ViewBuilder
    private var actions: some View {
        HStack(spacing: 6) {
            if job.isFinished {
                Button("Buka") { NSWorkspace.shared.open(job.destination) }
                Button {
                    NSWorkspace.shared.activateFileViewerSelecting([job.destination])
                } label: {
                    Image(systemName: "magnifyingglass")
                }
                .help("Tampilkan di Finder")
            } else if job.isActive {
                Button {
                    model.downloads.stop(job)
                } label: {
                    Image(systemName: "stop.circle")
                }
                .buttonStyle(.borderless)
                .help("Hentikan. File setengah jadi disimpan sebagai .part dan bisa dilanjutkan.")
            } else {
                Button("Coba Lagi") { model.downloads.retry(job) }
            }
        }
        .controlSize(.small)
    }

    private var isFailure: Bool {
        if case .failed = job.state { return true }
        return false
    }

    private var statusText: String {
        let total = job.file.size.fileSize
        switch job.state {
        case .waiting: return "Menunggu giliran, \(total)"
        case .running:
            let speed = Int64(job.bytesPerSecond).fileSize
            return "\(job.received.fileSize) dari \(total), \(speed)/detik"
        case .done: return "Selesai, \(total)"
        case .skipped: return "Sudah ada di folder tujuan, dilewati"
        case .stopped: return "Dihentikan di \(job.received.fileSize) dari \(total). Coba Lagi untuk melanjutkan."
        case .failed(let msg): return msg
        }
    }
}
