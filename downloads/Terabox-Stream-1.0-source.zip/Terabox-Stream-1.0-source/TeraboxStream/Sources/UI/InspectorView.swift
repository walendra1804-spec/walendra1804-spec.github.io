import SwiftUI

struct InspectorView: View {
    @Environment(AppModel.self) private var model

    var body: some View {
        Form {
            switch model.sidebar {
            case .nowPlaying, .library:
                PlayerInfo()
            case .libraryFolder(let url):
                Section("Perpustakaan") {
                    LabeledContent("Folder") { PathText(url: url) }
                    LabeledContent("Isi", value: "\((url == model.library.root ? model.library.count : model.library.folderNode(url)?.count) ?? 0) item")
                    Button("Tampilkan di Finder") { NSWorkspace.shared.activateFileViewerSelecting([url]) }
                }
            case .downloads:
                Section("Unduhan") {
                    LabeledContent("Folder") {
                        PathText(url: model.downloads.folder)
                    }
                    LabeledContent("Dalam antrean", value: "\(model.downloads.activeCount)")
                }
            default:
                if let browser = model.browser {
                    ShareInfo(browser: browser)
                } else {
                    Section {
                        Text("Info file akan tampil di sini setelah link dibuka.")
                            .foregroundStyle(.secondary)
                    }
                }
            }
        }
        .formStyle(.grouped)
    }
}

private struct ShareInfo: View {
    let browser: ShareBrowser

    var body: some View {
        let picked = browser.selection.compactMap { browser.node($0) }
        if picked.count == 1, let node = picked.first {
            Section(node.isFolder ? "Folder" : "File") {
                LongValue("Nama", node.name)
                LongValue("Lokasi", node.id)
                LabeledContent("Ukuran", value: node.totalSize.fileSize)
                if let file = node.file {
                    LabeledContent("Jenis", value: FileKinds.description(name: file.name))
                    LabeledContent("fs_id") { Text(String(file.fsId)).monospacedDigit().textSelection(.enabled) }
                    if !file.md5.isEmpty {
                        LabeledContent("MD5") { Text(file.md5).font(.caption.monospaced()).textSelection(.enabled) }
                    }
                } else {
                    LabeledContent("Isi", value: "\(node.allFiles.count) file")
                }
            }
        } else if picked.count > 1 {
            let files = browser.selectedFiles
            Section("\(picked.count) item dipilih") {
                LabeledContent("Jumlah file", value: "\(files.count)")
                LabeledContent("Total", value: files.reduce(Int64(0)) { $0 + $1.size }.fileSize)
            }
        }
        Section("Link") {
            if let s = browser.summary {
                LabeledContent("Pemilik", value: s.owner.isEmpty ? "Tidak diketahui" : s.owner)
            }
            LabeledContent("Jumlah file", value: "\(browser.allFiles.count)")
            LongValue("Alamat", browser.link)
            if browser.pwd != nil {
                LabeledContent("Kode akses", value: "Terpasang")
            }
        }
    }
}

private struct PlayerInfo: View {
    @Environment(AppModel.self) private var model

    var body: some View {
        if let current = model.player.current {
            Section("Sedang diputar") {
                LongValue("Nama", current.file.name)
                LongValue("Lokasi", current.file.rel)
                LabeledContent("Ukuran", value: current.file.size.fileSize)
                LabeledContent("Jenis", value: FileKinds.description(name: current.file.name))
                if !model.player.sourceLabel.isEmpty {
                    LabeledContent("Sumber", value: model.player.sourceLabel)
                }
            }
            Section("Asal") {
                LongValue("Link share", current.link)
                if let url = current.libraryURL {
                    VStack(alignment: .leading, spacing: 3) {
                        Text("File .tblink").foregroundStyle(.secondary)
                        PathText(url: url)
                    }
                    Button("Tampilkan di Finder") {
                        NSWorkspace.shared.activateFileViewerSelecting([url])
                    }
                }
                Button("Buka Link Share") { model.openLink(current.link) }
            }
        } else {
            Section {
                Text("Belum ada yang diputar.")
                    .foregroundStyle(.secondary)
            }
        }
    }
}

struct PathText: View {
    let url: URL

    var body: some View {
        Text(url.path(percentEncoded: false).replacing(FileManager.default.homeDirectoryForCurrentUser.path(percentEncoded: false), with: "~/"))
            .lineLimit(2)
            .truncationMode(.middle)
            .textSelection(.enabled)
            .help(url.path(percentEncoded: false))
    }
}

/// Nilai panjang (nama file, path, link): label di atas, nilai rata kiri.
private struct LongValue: View {
    let label: String
    let value: String

    init(_ label: String, _ value: String) {
        self.label = label
        self.value = value
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 3) {
            Text(label)
                .foregroundStyle(.secondary)
            Text(value)
                .textSelection(.enabled)
                .fixedSize(horizontal: false, vertical: true)
        }
    }
}
