import SwiftUI
import WebKit

/// Login Terabox di dalam aplikasi. Setelah berhasil, cookie ndus (HttpOnly)
/// diambil dari WKHTTPCookieStore lalu disimpan ke Keychain. Nilainya tidak
/// pernah ditampilkan.
struct LoginSheet: View {
    @Environment(AppModel.self) private var model
    @Environment(\.dismiss) private var dismiss
    @State private var loading = true

    var body: some View {
        VStack(spacing: 0) {
            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Masuk ke Terabox")
                        .font(.headline)
                    Text("Masuk seperti biasa. Jendela ini tertutup sendiri setelah berhasil, dan cookie login disimpan di Keychain.")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                if loading { ProgressView().controlSize(.small) }
                Button("Batal") { dismiss() }
                    .keyboardShortcut(.cancelAction)
            }
            .padding(14)
            Divider()
            LoginWebView(loading: $loading) { cookie in
                model.finishLogin(cookie: cookie)
            }
        }
        .frame(minWidth: 820, idealWidth: 1000, minHeight: 520, idealHeight: 620)
    }
}

private struct LoginWebView: NSViewRepresentable {
    @Binding var loading: Bool
    let onCookie: (String) -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    func makeNSView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .nonPersistent()
        let view = WKWebView(frame: .zero, configuration: config)
        view.customUserAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
            + "(KHTML, like Gecko) Version/26.0 Safari/605.1.15"
        view.navigationDelegate = context.coordinator
        view.pageZoom = 0.8  // halaman login Terabox dirancang untuk layar lebar
        config.websiteDataStore.httpCookieStore.add(context.coordinator)
        context.coordinator.store = config.websiteDataStore.httpCookieStore
        view.load(URLRequest(url: URL(string: "https://www.terabox.app/login")!))
        return view
    }

    func updateNSView(_ view: WKWebView, context: Context) {
        context.coordinator.parent = self
    }

    static func dismantleNSView(_ view: WKWebView, coordinator: Coordinator) {
        coordinator.store?.remove(coordinator)
        view.stopLoading()
    }

    @MainActor
    final class Coordinator: NSObject, WKNavigationDelegate, WKHTTPCookieStoreObserver {
        var parent: LoginWebView
        weak var store: WKHTTPCookieStore?
        private var finished = false

        init(_ parent: LoginWebView) {
            self.parent = parent
        }

        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            parent.loading = true
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            parent.loading = false
            check()
            if SelfTest.isRequested {
                Task {
                    let info = try? await webView.evaluateJavaScript("document.title + ' | teks=' + document.body.innerText.length")
                    SelfTest.log("     [login] selesai memuat \(webView.url?.host() ?? "-")\(webView.url?.path() ?? "") judul=\(info ?? "-")")
                }
            }
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            parent.loading = false
            if SelfTest.isRequested { SelfTest.log("     [login] gagal: \(error.localizedDescription)") }
        }

        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            parent.loading = false
            if SelfTest.isRequested { SelfTest.log("     [login] gagal: \(error.localizedDescription)") }
        }

        nonisolated func cookiesDidChange(in cookieStore: WKHTTPCookieStore) {
            Task { @MainActor in self.check() }
        }

        private func check() {
            guard !finished, let store else { return }
            Task {
                let cookies = await store.allCookies()
                let hosts = ["terabox", "1024tera", "dubox"]
                guard !finished,
                      let ndus = cookies.first(where: { c in
                          c.name == "ndus" && !c.value.isEmpty && hosts.contains { c.domain.contains($0) }
                      }) else { return }
                finished = true
                parent.onCookie("ndus=\(ndus.value)")
            }
        }
    }
}
