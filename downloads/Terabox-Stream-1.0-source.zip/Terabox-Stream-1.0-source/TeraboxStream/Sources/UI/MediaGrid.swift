import AVFoundation
import SwiftUI

/// Tampilan isi link: daftar (Table) atau grid kartu bergambar.
enum BrowserLayout: String {
    case list, grid
}

private let gridColumns = [GridItem(.adaptive(minimum: 210, maximum: 320), spacing: 18, alignment: .top)]

// MARK: - Grid isi link

/// Kartu dikelompokkan per folder, seperti rak video di YouTube.
struct FileGrid: View {
    @Environment(AppModel.self) private var model
    @Bindable var browser: ShareBrowser

    private struct FolderGroup: Identifiable {
        let id: String
        let title: String
        let files: [FileNode]
    }

    var body: some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 26, pinnedViews: .sectionHeaders) {
                ForEach(groups) { group in
                    Section {
                        LazyVGrid(columns: gridColumns, alignment: .leading, spacing: 22) {
                            ForEach(group.files) { node in
                                if let file = node.file {
                                    card(node, file)
                                }
                            }
                        }
                        .padding(.horizontal, 20)
                    } header: {
                        GroupHeader(title: group.title, count: group.files.count)
                    }
                }
            }
            .padding(.bottom, 20)
        }
        .onDisappear { model.preview.stop() }
    }

    private func card(_ node: FileNode, _ file: ShareFile) -> some View {
        MediaCard(id: node.id, file: file, link: browser.link, pwd: browser.pwd,
                  thumb: model.thumbnailLoader(node, in: browser.share),
                  isSelected: browser.selection.contains(node.id)) { extend in
            if extend {
                if browser.selection.contains(node.id) { browser.selection.remove(node.id) } else { browser.selection.insert(node.id) }
            } else {
                browser.selection = [node.id]
            }
        } open: {
            model.play(file)
        } menu: {
            ShareFileMenu(browser: browser, ids: browser.selection.contains(node.id) ? browser.selection : [node.id])
        }
    }

    /// Satu kelompok untuk setiap folder yang berisi file, urut seperti pohonnya.
    private var groups: [FolderGroup] {
        var out: [FolderGroup] = []
        func visit(_ nodes: [FileNode], _ path: [String]) {
            let files = nodes.filter { !$0.isFolder }
            if !files.isEmpty {
                out.append(FolderGroup(id: "/" + path.joined(separator: "/"),
                                 title: path.isEmpty ? "Folder utama" : path.joined(separator: " / "),
                                 files: files))
            }
            for folder in nodes where folder.isFolder {
                visit(folder.children ?? [], path + [folder.name])
            }
        }
        visit(browser.roots, [])
        return out
    }
}

private struct GroupHeader: View {
    let title: String
    let count: Int

    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            Image(systemName: "folder")
                .foregroundStyle(.secondary)
            Text(title)
                .font(.headline)
                .lineLimit(1)
                .truncationMode(.middle)
            Text("\(count) file")
                .foregroundStyle(.secondary)
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 8)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(.bar)
    }
}

// MARK: - Perpustakaan

/// Isi satu folder Perpustakaan, sebagai daftar atau grid. File dan folder bisa dicentang
/// lalu diunduh sekaligus.
struct LibraryPage: View {
    @Environment(AppModel.self) private var model
    @Environment(\.pageCovered) private var covered
    @AppStorage("libraryLayout") private var layout: BrowserLayout = .grid
    let folder: URL

    var body: some View {
        let library = model.library
        let children = folder == library.root ? library.nodes : library.folderNode(folder)?.children ?? []
        Group {
            if children.isEmpty {
                ContentUnavailableView("Folder ini kosong", systemImage: "folder",
                                       description: Text("Simpan file dari sebuah link untuk menambahkannya ke sini."))
            } else {
                Group {
                    switch layout {
                    case .list: LibraryTable(children: children)
                    case .grid: LibraryGrid(children: children)
                    }
                }
                .safeAreaInset(edge: .bottom, spacing: 0) {
                    LibraryActionBar(children: children)
                }
            }
        }
        .toolbar {
            if !covered {
                ToolbarItem(placement: .primaryAction) {
                    Picker("Tampilan", selection: $layout) {
                        Label("Daftar", systemImage: "list.bullet").tag(BrowserLayout.list)
                        Label("Grid", systemImage: "square.grid.2x2").tag(BrowserLayout.grid)
                    }
                    .pickerStyle(.segmented)
                    .help("Tampilkan sebagai daftar (⌘1) atau grid bergambar (⌘2)")
                }
            }
        }
        .onChange(of: folder, initial: true) {
            library.showFolder(folder)
            model.preview.stop()
        }
        .onDisappear { model.preview.stop() }
    }
}

private struct LibraryGrid: View {
    @Environment(AppModel.self) private var model
    let children: [LibraryNode]

    var body: some View {
        let library = model.library
        let checking = !library.checked.isEmpty
        let folders = children.filter { $0.children != nil }
        let items = children.filter { $0.entry != nil }
        ScrollView {
            VStack(alignment: .leading, spacing: 22) {
                if !folders.isEmpty {
                    LazyVGrid(columns: [GridItem(.adaptive(minimum: 200, maximum: 320), spacing: 12)], spacing: 12) {
                        ForEach(folders) { node in
                            FolderTile(node: node, isChecked: library.checked.contains(node.url), checking: checking)
                        }
                    }
                }
                LazyVGrid(columns: gridColumns, alignment: .leading, spacing: 22) {
                    ForEach(items) { node in
                        if let entry = node.entry { card(node.url, entry, checking: checking) }
                    }
                }
            }
            .padding(20)
        }
    }

    private func card(_ url: URL, _ entry: LinkEntry, checking: Bool) -> some View {
        let library = model.library
        return MediaCard(id: url.path(percentEncoded: false), file: entry.file, link: entry.shareLink, pwd: entry.pwd,
                         thumb: model.thumbnailLoader(entry), isSelected: library.checked.contains(url),
                         checkable: true, checking: checking) { _ in
            // Klik kartu = centang/hapus centang. Klik dua kali membuka (dua klik saling membatalkan).
            library.toggleChecked(url)
        } open: {
            model.sidebar = .library(url)
        } menu: {
            if library.checked.contains(url), library.checked.count > 1 {
                LibrarySelectionMenu(urls: library.checked)
            } else {
                LibraryItemMenu(url: url, entry: entry)
            }
        }
    }
}

private struct LibraryTable: View {
    @Environment(AppModel.self) private var model
    let children: [LibraryNode]

    var body: some View {
        @Bindable var library = model.library
        Table(children, selection: $library.checked) {
            TableColumn("") { node in
                Toggle("Centang \(node.name)", isOn: Binding {
                    library.checked.contains(node.url)
                } set: { on in
                    if on { library.checked.insert(node.url) } else { library.checked.remove(node.url) }
                })
                .toggleStyle(.checkbox)
                .labelsHidden()
            }
            .width(18)

            TableColumn("Nama") { node in
                LibraryNameCell(node: node)
            }
            .width(min: 220, ideal: 420)

            TableColumn("Ukuran") { node in
                Text(node.totalSize.fileSize)
                    .monospacedDigit()
                    .foregroundStyle(.secondary)
            }
            .width(min: 70, ideal: 90, max: 130)
            .alignment(.trailing)

            TableColumn("Jenis") { node in
                Text(node.children != nil ? "Folder, \(node.count) file" : FileKinds.description(name: node.name))
                    .foregroundStyle(.secondary)
            }
            .width(min: 90, ideal: 140, max: 220)
        }
        .contextMenu(forSelectionType: URL.self) { urls in
            if urls.count == 1, let url = urls.first, let entry = library.entry(at: url) {
                LibraryItemMenu(url: url, entry: entry)
            } else if !urls.isEmpty {
                LibrarySelectionMenu(urls: urls)
            }
        } primaryAction: { urls in
            guard urls.count == 1, let url = urls.first else { return }
            if library.folderNode(url) != nil {
                library.expanded.insert(url)
                model.sidebar = .libraryFolder(url)
            } else {
                model.sidebar = .library(url)
            }
        }
    }
}

private struct LibraryNameCell: View {
    @Environment(AppModel.self) private var model
    let node: LibraryNode

    var body: some View {
        HStack(spacing: 6) {
            if let entry = node.entry {
                let symbol = FileKinds.symbol(name: entry.name, category: entry.category ?? 0)
                if let thumb = model.thumbnailLoader(entry) {
                    ThumbnailView(fsId: entry.fsId, symbol: symbol, load: thumb, symbolFont: .caption)
                        .frame(width: 30, height: 18)
                        .clipShape(.rect(cornerRadius: 3))
                } else {
                    Image(systemName: symbol)
                        .foregroundStyle(.secondary)
                        .frame(width: 30)
                }
            } else {
                Image(systemName: "folder.fill")
                    .foregroundStyle(.tint)
                    .frame(width: 30)
            }
            Text(node.name)
                .lineLimit(1)
                .truncationMode(.middle)
        }
    }
}

/// Baris bawah halaman Perpustakaan: centang semua, jumlah yang dicentang, dan tombol unduh.
private struct LibraryActionBar: View {
    @Environment(AppModel.self) private var model
    let children: [LibraryNode]

    var body: some View {
        let library = model.library
        let all = Set(children.map(\.url))
        let total = children.reduce(0) { $0 + $1.count }
        let picked = library.entries(in: library.checked)
        let size = picked.reduce(Int64(0)) { $0 + $1.size }
        HStack(spacing: 12) {
            Toggle("Pilih semua", isOn: Binding {
                !all.isEmpty && all.isSubset(of: library.checked)
            } set: { on in
                library.checked = on ? all : []
            })
            .toggleStyle(.checkbox)
            .help("Centang semua file dan folder di sini")

            Text(picked.isEmpty
                 ? "\(total) file. Centang file atau folder untuk mengunduhnya."
                 : "\(picked.count) dari \(total) file dicentang, \(size.fileSize)")
                .foregroundStyle(.secondary)
                .lineLimit(1)

            Spacer(minLength: 8)

            if let notice = model.notice {
                Label(notice, systemImage: "checkmark.circle.fill")
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .transition(.opacity)
            }
            Button("Unduh ke…") {
                model.downloadLibrary(library.checked, choosingFolder: true)
            }
            .disabled(picked.isEmpty)
            Button(picked.count > 1 ? "Unduh \(picked.count) File" : "Unduh") {
                model.downloadLibrary(library.checked)
            }
            .buttonStyle(.borderedProminent)
            .disabled(picked.isEmpty)
            .help("Unduh ke \(model.downloads.folder.path(percentEncoded: false)) (⌘D)")
        }
        .font(.callout)
        .padding(.horizontal, 14)
        .padding(.vertical, 7)
        .background(.bar)
        .overlay(alignment: .top) { Divider() }
        .animation(.default, value: model.notice)
    }
}

private struct FolderTile: View {
    @Environment(AppModel.self) private var model
    let node: LibraryNode
    let isChecked: Bool
    let checking: Bool
    @State private var hovering = false

    var body: some View {
        Button {
            model.library.expanded.insert(node.url)
            model.sidebar = .libraryFolder(node.url)
        } label: {
            HStack(spacing: 10) {
                Image(systemName: "folder.fill")
                    .font(.title2)
                    .foregroundStyle(.tint)
                VStack(alignment: .leading, spacing: 1) {
                    Text(node.name)
                        .lineLimit(1)
                        .truncationMode(.middle)
                    Text("\(node.count) file, \(node.totalSize.fileSize)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Spacer(minLength: 34)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 9)
            .background(.quaternary.opacity(0.6), in: .rect(cornerRadius: 8))
            .overlay {
                if isChecked {
                    RoundedRectangle(cornerRadius: 8)
                        .strokeBorder(Color.accentColor, lineWidth: 2)
                }
            }
            .contentShape(.rect)
        }
        .buttonStyle(.plain)
        .overlay(alignment: .trailing) {
            if isChecked || checking || hovering {
                Button { model.library.toggleChecked(node.url) } label: {
                    CheckBadge(isOn: isChecked)
                }
                .buttonStyle(.plain)
                .padding(.trailing, 10)
                .accessibilityLabel(isChecked ? "Hapus centang \(node.name)" : "Centang \(node.name)")
            }
        }
        .onHover { hovering = $0 }
        .contextMenu {
            LibrarySelectionMenu(urls: isChecked && model.library.checked.count > 1 ? model.library.checked : [node.url])
        }
        .help("Buka folder \(node.name)")
    }
}

/// Menu klik kanan untuk beberapa item, atau satu folder, di Perpustakaan.
struct LibrarySelectionMenu: View {
    @Environment(AppModel.self) private var model
    let urls: Set<URL>

    var body: some View {
        let count = model.library.entries(in: urls).count
        Button(count == 1 ? "Unduh" : "Unduh \(count) File") { model.downloadLibrary(urls) }
        Button("Unduh ke…") { model.downloadLibrary(urls, choosingFolder: true) }
        Divider()
        Button("Tampilkan di Finder") {
            NSWorkspace.shared.activateFileViewerSelecting(Array(urls))
        }
    }
}

/// Kotak centang bulat di pojok kartu.
struct CheckBadge: View {
    let isOn: Bool

    var body: some View {
        ZStack {
            Circle()
                .fill(isOn ? AnyShapeStyle(Color.accentColor) : AnyShapeStyle(.black.opacity(0.3)))
            Circle()
                .strokeBorder(.white, lineWidth: 1.5)
            if isOn {
                Image(systemName: "checkmark")
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(.white)
            }
        }
        .frame(width: 22, height: 22)
        .shadow(color: .black.opacity(0.35), radius: 2)
        .contentShape(.circle)
    }
}

/// Menu klik kanan untuk satu item Perpustakaan (dipakai sidebar dan grid).
struct LibraryItemMenu: View {
    @Environment(AppModel.self) private var model
    let url: URL
    let entry: LinkEntry

    var body: some View {
        Button("Putar") { model.sidebar = .library(url) }
        Button("Unduh") { model.downloadLibrary([url]) }
        Button("Unduh ke…") { model.downloadLibrary([url], choosingFolder: true) }
        Divider()
        Button("Buka Link Share") { model.openLink(entry.shareLink) }
        Button("Salin Link Share") {
            NSPasteboard.general.clearContents()
            NSPasteboard.general.setString(entry.shareLink, forType: .string)
        }
        Divider()
        Button("Tampilkan di Finder") {
            NSWorkspace.shared.activateFileViewerSelecting([url])
        }
        Button("Pindahkan ke Sampah") {
            do {
                try model.library.moveToTrash(url)
            } catch {
                model.errorMessage = error.localizedDescription
            }
        }
    }
}

// MARK: - Kartu

struct MediaCard<Menu: View>: View {
    @Environment(AppModel.self) private var model
    let id: String
    let file: ShareFile
    let link: String
    let pwd: String?
    let thumb: Thumbnails.Loader?
    let isSelected: Bool
    /// Kartu punya kotak centang (Perpustakaan). Tampil saat kursor di atasnya,
    /// saat dicentang, atau selama ada yang dicentang (`checking`).
    var checkable = false
    var checking = false
    let select: (_ extend: Bool) -> Void
    let open: () -> Void
    @ViewBuilder let menu: () -> Menu
    @State private var hovering = false

    private var kind: MediaKind { FileKinds.kind(name: file.name, category: file.category) }

    var body: some View {
        let preview = model.preview
        let previewing = preview.activeID == id && preview.isShowing
        VStack(alignment: .leading, spacing: 8) {
            Color.clear
                .aspectRatio(16 / 9, contentMode: .fit)
                .overlay {
                    ThumbnailView(fsId: file.fsId, symbol: FileKinds.symbol(name: file.name, category: file.category),
                                  load: thumb)
                }
                .overlay {
                    if previewing {
                        PreviewSurface(player: preview.player)
                            .transition(.opacity)
                    }
                }
                .overlay(alignment: .bottom) {
                    if previewing, preview.part > 0 {
                        PartIndicator(part: preview.part)
                    }
                }
                .clipShape(.rect(cornerRadius: 8))
                .overlay {
                    if isSelected {
                        RoundedRectangle(cornerRadius: 8)
                            .strokeBorder(Color.accentColor, lineWidth: 3)
                    }
                }
                .animation(.easeOut(duration: 0.2), value: previewing)

            VStack(alignment: .leading, spacing: 2) {
                Text(file.name)
                    .font(.body.weight(.medium))
                    .lineLimit(2)
                    .truncationMode(.middle)
                Text("\(FileKinds.description(name: file.name)), \(file.size.fileSize)")
                    .font(.callout)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            .padding(.horizontal, 2)
        }
        .contentShape(.rect)
        .onTapGesture(count: 2) {
            model.preview.stop()
            open()
        }
        .simultaneousGesture(TapGesture().onEnded {
            select(NSEvent.modifierFlags.contains(.command))
        })
        // Di luar gesture kartu, supaya klik kotak centang tidak ikut dihitung klik kartu.
        .overlay(alignment: .topLeading) {
            if checkable, isSelected || checking || hovering {
                Button { select(true) } label: {
                    CheckBadge(isOn: isSelected)
                }
                .buttonStyle(.plain)
                .padding(8)
                .accessibilityLabel(isSelected ? "Hapus centang" : "Centang")
            }
        }
        .onHover { inside in
            hovering = inside
            guard kind == .video else { return }
            if inside {
                model.preview.hover(id: id, file: file, link: link, pwd: pwd)
            } else {
                model.preview.end(id: id)
            }
        }
        .contextMenu { menu() }
        .help(file.name)
        .accessibilityElement(children: .combine)
        .accessibilityAddTraits(isSelected ? [.isButton, .isSelected] : .isButton)
        .accessibilityAction(named: kind == .other ? "Buka" : "Putar", open)
        .accessibilityAction(named: isSelected ? "Hapus centang" : "Centang") {
            if checkable { select(true) }
        }
    }
}

/// Lima garis kecil di bawah pratinjau: bagian mana (1/5 sampai 5/5) yang sedang diputar.
private struct PartIndicator: View {
    let part: Int

    var body: some View {
        HStack(spacing: 3) {
            ForEach(1...5, id: \.self) { i in
                Capsule()
                    .fill(.white.opacity(i == part ? 0.95 : 0.35))
                    .frame(height: 3)
            }
        }
        .padding(.horizontal, 10)
        .padding(.bottom, 7)
        .shadow(color: .black.opacity(0.4), radius: 2)
        .accessibilityLabel("Pratinjau bagian \(part) dari 5")
    }
}

struct ThumbnailView: View {
    let fsId: Int64
    let symbol: String
    let load: Thumbnails.Loader?
    var symbolFont: Font = .title
    @State private var image: NSImage?

    init(fsId: Int64, symbol: String, load: Thumbnails.Loader?, symbolFont: Font = .title) {
        self.fsId = fsId
        self.symbol = symbol
        self.load = load
        self.symbolFont = symbolFont
        _image = State(initialValue: Thumbnails.shared.cached(fsId))
    }

    var body: some View {
        ZStack {
            Rectangle().fill(.quaternary)
            if let image {
                Image(nsImage: image)
                    .resizable()
                    .scaledToFill()
            } else {
                Image(systemName: symbol)
                    .font(symbolFont)
                    .foregroundStyle(.secondary)
            }
        }
        .task(id: fsId) {
            guard image == nil, let load else { return }
            image = await Thumbnails.shared.image(for: fsId, load: load)
        }
    }
}

/// AVPlayerLayer tanpa kontrol, untuk pratinjau. Tidak menerima klik.
struct PreviewSurface: NSViewRepresentable {
    let player: AVPlayer

    func makeNSView(context: Context) -> PlayerLayerView {
        let view = PlayerLayerView()
        view.playerLayer.player = player
        return view
    }

    func updateNSView(_ view: PlayerLayerView, context: Context) {
        if view.playerLayer.player !== player { view.playerLayer.player = player }
    }

    static func dismantleNSView(_ view: PlayerLayerView, coordinator: ()) {
        view.playerLayer.player = nil
    }

    final class PlayerLayerView: NSView {
        let playerLayer = AVPlayerLayer()

        override init(frame: NSRect) {
            super.init(frame: frame)
            playerLayer.videoGravity = .resizeAspectFill
            playerLayer.backgroundColor = .clear
            layer = playerLayer
            wantsLayer = true
        }

        required init?(coder: NSCoder) { nil }

        override func hitTest(_ point: NSPoint) -> NSView? { nil }
    }
}
