import AVKit
import SwiftUI

struct PlayerView: View {
    @Environment(AppModel.self) private var model

    var body: some View {
        let player = model.player
        Group {
            if let current = player.current {
                switch current.kind {
                case .video: VideoStage(current: current)
                case .audio: AudioStage(current: current)
                case .image: ImageStage(current: current)
                case .other: UnsupportedStage(current: current)
                }
            } else {
                ContentUnavailableView {
                    Label("Belum ada yang diputar", systemImage: "play.rectangle")
                } description: {
                    Text("Klik item di Perpustakaan, atau klik dua kali file di link yang sedang dibuka.")
                }
            }
        }
        .toolbar {
            ToolbarItem(placement: .navigation) {
                Button {
                    model.goBack()
                } label: {
                    Label("Kembali", systemImage: "chevron.left")
                }
                .help("Kembali ke \(backName) (⌘[)")
            }
            if player.current?.kind == .video {
                ToolbarItem(placement: .primaryAction) {
                    QualityMenu()
                }
            }
        }
    }
}

extension PlayerView {
    private var backName: String {
        switch model.page {
        case .downloads: "Unduhan"
        case .libraryFolder: "Perpustakaan"
        default: "isi link"
        }
    }
}

private struct QualityMenu: View {
    @Environment(AppModel.self) private var model

    var body: some View {
        @Bindable var player = model.player
        Picker("Kualitas", selection: $player.quality) {
            ForEach(VideoQuality.allCases) { q in
                Text(q == .automatic ? "Otomatis (720p, turun kalau perlu)" : q.title).tag(q)
            }
        }
        .pickerStyle(.menu)
        .help("Kualitas video HLS dari Terabox")
    }
}

// MARK: - Panggung audio
// Satu-satunya tempat aplikasi ini memakai huruf serif: judul lagu tampil
// besar seperti label sampul piringan, sisanya tetap gaya Mac biasa.

private struct AudioStage: View {
    @Environment(AppModel.self) private var model
    let current: PlayerController.Current

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            if !current.folderPath.isEmpty {
                Label(current.folderPath, systemImage: "folder")
                    .font(.callout)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
                    .truncationMode(.middle)
                    .padding(.bottom, 10)
            }
            Text((current.file.name as NSString).deletingPathExtension)
                .font(.system(size: 38, weight: .regular, design: .serif))
                .lineLimit(3)
                .minimumScaleFactor(0.6)
                .textSelection(.enabled)
                .padding(.bottom, 6)
            PhaseLine(kindText: FileKinds.description(name: current.file.name), size: current.file.size)
                .padding(.bottom, 22)
            PlayerSurface(player: model.player.player, style: .inline)
                .frame(height: 64)
                .clipShape(.rect(cornerRadius: 10))
                .opacity(model.player.phase == .ready ? 1 : 0.4)
                .disabled(model.player.phase != .ready)
        }
        .frame(maxWidth: 680, alignment: .leading)
        .padding(.horizontal, 48)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
    }
}

/// Satu baris keterangan: status pemuatan, sumber streaming, atau error.
private struct PhaseLine: View {
    @Environment(AppModel.self) private var model
    let kindText: String
    let size: Int64

    var body: some View {
        let player = model.player
        switch player.phase {
        case .loading(let message):
            HStack(spacing: 6) {
                ProgressView().controlSize(.mini)
                Text(message)
            }
            .foregroundStyle(.secondary)
        case .failed(let message, let needsLogin):
            VStack(alignment: .leading, spacing: 8) {
                Label(message, systemImage: "exclamationmark.triangle.fill")
                    .foregroundStyle(.red)
                    .textSelection(.enabled)
                HStack {
                    Button("Coba Lagi") { player.reload() }
                    if needsLogin {
                        Button("Masuk ke Terabox…") { model.showLogin = true }
                    }
                }
            }
        default:
            Text(player.sourceLabel.isEmpty ? "\(kindText), \(size.fileSize)" : "\(kindText), \(size.fileSize). Diputar \(player.sourceLabel.lowercasedFirst).")
                .foregroundStyle(.secondary)
        }
    }
}

// MARK: - Video

private struct VideoStage: View {
    @Environment(AppModel.self) private var model
    let current: PlayerController.Current

    var body: some View {
        ZStack {
            Color.black
            PlayerSurface(player: model.player.player, style: .floating)
            switch model.player.phase {
            case .loading(let message):
                VStack(spacing: 10) {
                    ProgressView().controlSize(.small)
                    Text(message)
                }
                .foregroundStyle(.white.opacity(0.85))
                .environment(\.colorScheme, .dark)
            case .failed:
                PhaseLine(kindText: FileKinds.description(name: current.file.name), size: current.file.size)
                    .padding(24)
                    .background(.regularMaterial, in: .rect(cornerRadius: 12))
                    .frame(maxWidth: 520)
            default:
                EmptyView()
            }
        }
    }
}

// MARK: - Gambar

private struct ImageStage: View {
    @Environment(AppModel.self) private var model
    let current: PlayerController.Current

    var body: some View {
        Group {
            if let url = model.player.mediaURL {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image): image.resizable().scaledToFit()
                    case .failure: Label("Gambar tidak bisa ditampilkan", systemImage: "photo")
                    default: ProgressView()
                    }
                }
                .padding(24)
            } else {
                PhaseLine(kindText: FileKinds.description(name: current.file.name), size: current.file.size)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

private struct UnsupportedStage: View {
    @Environment(AppModel.self) private var model
    let current: PlayerController.Current

    var body: some View {
        ContentUnavailableView {
            Label(current.file.name, systemImage: FileKinds.symbol(name: current.file.name, category: current.file.category))
        } description: {
            Text("\(FileKinds.description(name: current.file.name)) tidak bisa diputar di aplikasi. Unduh file ini lalu buka dengan aplikasi yang cocok.")
        } actions: {
            if model.browser?.link == current.link {
                Button("Unduh") { model.download([current.file]) }
                    .buttonStyle(.borderedProminent)
            } else {
                Button("Buka Link Share") { model.openLink(current.link) }
            }
        }
    }
}

// MARK: - AVPlayerView

struct PlayerSurface: NSViewRepresentable {
    let player: AVPlayer
    let style: AVPlayerViewControlsStyle

    func makeNSView(context: Context) -> AVPlayerView {
        let view = AVPlayerView()
        view.player = player
        view.controlsStyle = style
        view.showsFullScreenToggleButton = style == .floating
        view.allowsPictureInPicturePlayback = style == .floating
        view.videoGravity = .resizeAspect
        return view
    }

    func updateNSView(_ view: AVPlayerView, context: Context) {
        if view.player !== player { view.player = player }
        if view.controlsStyle != style { view.controlsStyle = style }
    }
}

extension String {
    var lowercasedFirst: String {
        guard let first else { return self }
        return first.lowercased() + dropFirst()
    }
}
