import SwiftUI

struct SettingsView: View {
    @Environment(AppModel.self) private var model

    var body: some View {
        @Bindable var player = model.player
        Form {
            Section("Lokasi") {
                LabeledContent("Perpustakaan") {
                    HStack {
                        PathText(url: model.library.root)
                        Button("Pilih…") {
                            if let url = FolderPanel.choose(title: "Pilih folder Perpustakaan", prompt: "Pakai Folder Ini",
                                                            startingAt: model.library.root) {
                                model.library.setRoot(url)
                            }
                        }
                    }
                }
                Text("Folder berisi file .tblink. Folder yang sama dipakai oleh terabox.py, jadi isi Perpustakaan selalu sama di aplikasi dan di Terminal.")
                    .font(.callout)
                    .foregroundStyle(.secondary)
                LabeledContent("Folder unduhan") {
                    HStack {
                        PathText(url: model.downloads.folder)
                        Button("Pilih…") {
                            if let url = FolderPanel.choose(title: "Pilih folder unduhan", prompt: "Pakai Folder Ini",
                                                            startingAt: model.downloads.folder) {
                                model.downloads.folder = url
                            }
                        }
                    }
                }
            }

            Section("Pemutaran") {
                Picker("Kualitas video", selection: $player.quality) {
                    ForEach(VideoQuality.allCases) { q in
                        Text(q == .automatic ? "Otomatis (720p, turun kalau perlu)" : q.title).tag(q)
                    }
                }
            }

            Section("Akun Terabox") {
                LabeledContent("Status", value: accountStatus)
                HStack {
                    Button("Masuk ke Terabox…") { model.showLogin = true }
                    Button("Impor cookie.txt…") { model.importCookieFile() }
                    Spacer()
                    if model.account.source == .keychain {
                        Button("Keluar", role: .destructive) { model.signOut() }
                    }
                }
                Text("Melihat isi link tidak butuh login. Video dan sebagian unduhan butuh login supaya Terabox mau mengirim filenya.")
                    .font(.callout)
                    .foregroundStyle(.secondary)
            }
        }
        .formStyle(.grouped)
        .frame(width: 560)
        .fixedSize(horizontal: false, vertical: true)
    }

    private var accountStatus: String {
        switch model.account.source {
        case .none: "Belum masuk"
        case .keychain: "Sudah masuk, cookie tersimpan di Keychain"
        case .environment: "Memakai cookie dari TERABOX_COOKIE"
        }
    }
}

enum FolderPanel {
    @MainActor
    static func choose(title: String, prompt: String, startingAt: URL?) -> URL? {
        let panel = NSOpenPanel()
        panel.title = title
        panel.prompt = prompt
        panel.canChooseDirectories = true
        panel.canChooseFiles = false
        panel.canCreateDirectories = true
        panel.allowsMultipleSelection = false
        panel.directoryURL = startingAt
        return panel.runModal() == .OK ? panel.url : nil
    }
}

enum FilePanel {
    @MainActor
    static func chooseFile(title: String, startingAt: URL?) -> URL? {
        let panel = NSOpenPanel()
        panel.title = title
        panel.prompt = "Impor"
        panel.canChooseDirectories = false
        panel.canChooseFiles = true
        panel.allowsMultipleSelection = false
        panel.allowedContentTypes = [.plainText, .text, .data]
        panel.directoryURL = startingAt
        return panel.runModal() == .OK ? panel.url : nil
    }
}
