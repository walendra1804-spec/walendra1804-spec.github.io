import SwiftUI

struct ShareBrowserView: View {
    @Environment(AppModel.self) private var model
    @Bindable var browser: ShareBrowser
    @State private var passwordSheet = false
    @AppStorage("browserLayout") private var layout: BrowserLayout = .list
    @Environment(\.pageCovered) private var covered

    var body: some View {
        content
            .toolbar {
                if !covered {
                ToolbarItem(placement: .primaryAction) {
                    Picker("Tampilan", selection: $layout) {
                        Label("Daftar", systemImage: "list.bullet").tag(BrowserLayout.list)
                        Label("Grid", systemImage: "square.grid.2x2").tag(BrowserLayout.grid)
                    }
                    .pickerStyle(.segmented)
                    .help("Tampilkan sebagai daftar (⌘1) atau grid bergambar (⌘2)")
                    .disabled(browser.phase != .loaded)
                }
                ToolbarItemGroup(placement: .primaryAction) {
                    Button {
                        model.saveToLibrary()
                    } label: {
                        Label("Simpan", systemImage: "books.vertical")
                    }
                    .help("Simpan ke Perpustakaan tanpa mengunduh (⌘S)")
                    .disabled(!model.canActOnShare)

                    Button {
                        model.download()
                    } label: {
                        Label("Unduh", systemImage: "arrow.down.circle")
                    }
                    .help("Unduh ke \(model.downloads.folder.path(percentEncoded: false)) (⌘D)")
                    .disabled(!model.canActOnShare)
                }
                }
            }
            .sheet(isPresented: $passwordSheet) {
                PasswordSheet(wrong: browser.phase == .needsPassword(wrong: true)) { code in
                    browser.unlock(with: code)
                }
            }
            .onChange(of: browser.phase, initial: true) { _, phase in
                if case .needsPassword = phase { passwordSheet = true }
            }
    }

    @ViewBuilder
    private var content: some View {
        switch browser.phase {
        case .loading(let message):
            VStack(spacing: 10) {
                ProgressView()
                    .controlSize(.small)
                Text(message)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
                    .truncationMode(.middle)
            }
            .padding()
            .frame(maxWidth: 420)
        case .needsPassword:
            ContentUnavailableView {
                Label("Link ini dikunci", systemImage: "lock")
            } description: {
                Text("Pemilik link memasang kode akses. Minta kode 4 karakternya, lalu masukkan di sini.")
            } actions: {
                Button("Masukkan Kode Akses…") { passwordSheet = true }
                    .buttonStyle(.borderedProminent)
            }
        case .failed(let message, let needsLogin):
            ContentUnavailableView {
                Label("Link tidak bisa dibuka", systemImage: "exclamationmark.triangle")
            } description: {
                Text(message)
                    .textSelection(.enabled)
            } actions: {
                if needsLogin {
                    Button("Masuk ke Terabox…") { model.showLogin = true }
                        .buttonStyle(.borderedProminent)
                }
                Button("Coba Lagi") { model.retryBrowser() }
            }
        case .loaded:
            if browser.roots.isEmpty {
                ContentUnavailableView("Folder ini kosong", systemImage: "folder",
                                       description: Text("Link terbuka, tapi tidak ada file di dalamnya."))
            } else {
                Group {
                    switch layout {
                    case .list: FileTable(browser: browser)
                    case .grid: FileGrid(browser: browser)
                    }
                }
                    .safeAreaInset(edge: .bottom, spacing: 0) {
                        StatusBar(browser: browser)
                    }
            }
        }
    }

}

extension ShareBrowser {
    /// Baris kecil di bawah judul jendela.
    var summaryLine: String {
        guard phase == .loaded else { return "" }
        let files = allFiles
        let total = files.reduce(Int64(0)) { $0 + $1.size }
        let owner = summary?.owner ?? ""
        let base = "\(files.count) file, \(total.fileSize)"
        return owner.isEmpty ? base : "\(base), dibagikan oleh \(owner)"
    }
}

private struct FileTable: View {
    @Environment(AppModel.self) private var model
    @Bindable var browser: ShareBrowser

    var body: some View {
        Table(browser.rows, selection: $browser.selection) {
            TableColumn("Nama") { row in
                NameCell(row: row, isExpanded: browser.expanded.contains(row.id),
                         thumb: model.thumbnailLoader(row.node, in: browser.share)) {
                    browser.toggle(row.id)
                }
            }
            .width(min: 220, ideal: 420)

            TableColumn("Ukuran") { row in
                Text(row.node.totalSize.fileSize)
                    .monospacedDigit()
                    .foregroundStyle(.secondary)
            }
            .width(min: 70, ideal: 90, max: 130)
            .alignment(.trailing)

            TableColumn("Jenis") { row in
                Text(row.node.isFolder ? "Folder" : FileKinds.description(name: row.node.name))
                    .foregroundStyle(.secondary)
            }
            .width(min: 90, ideal: 140, max: 220)
        }
        .contextMenu(forSelectionType: String.self) { ids in
            ShareFileMenu(browser: browser, ids: ids)
        } primaryAction: { ids in
            primaryAction(ids)
        }
        .onKeyPress(.rightArrow) { setExpanded(true) }
        .onKeyPress(.leftArrow) { setExpanded(false) }
    }

    private func primaryAction(_ ids: Set<String>) {
        guard ids.count == 1, let id = ids.first, let node = browser.node(id) else { return }
        if let file = node.file {
            model.play(file)
        } else {
            browser.toggle(id)
        }
    }

    private func setExpanded(_ open: Bool) -> KeyPress.Result {
        let folders = browser.selection.filter { browser.node($0)?.isFolder == true }
        guard !folders.isEmpty else { return .ignored }
        for id in folders {
            if open { browser.expanded.insert(id) } else { browser.expanded.remove(id) }
        }
        return .handled
    }
}

/// Menu klik kanan untuk file dan folder di link yang sedang dibuka (daftar dan grid).
struct ShareFileMenu: View {
    @Environment(AppModel.self) private var model
    let browser: ShareBrowser
    let ids: Set<String>

    var body: some View {
        let nodes = ids.compactMap { browser.node($0) }
        let files = nodes.flatMap(\.allFiles)
        if nodes.count == 1, let file = nodes.first?.file {
            Button(FileKinds.kind(name: file.name, category: file.category) == .other ? "Buka" : "Putar") {
                model.play(file)
            }
            Divider()
        }
        if !files.isEmpty {
            Button(files.count == 1 ? "Simpan ke Perpustakaan" : "Simpan \(files.count) File ke Perpustakaan") {
                model.saveToLibrary(files)
            }
            Button(files.count == 1 ? "Unduh" : "Unduh \(files.count) File") {
                model.download(files)
            }
            Button("Unduh ke…") {
                model.download(files, choosingFolder: true)
            }
        }
        if nodes.count == 1, let node = nodes.first {
            Divider()
            Button("Salin Nama") {
                NSPasteboard.general.clearContents()
                NSPasteboard.general.setString(node.name, forType: .string)
            }
        }
    }
}

private struct NameCell: View {
    let row: ShareBrowser.Row
    let isExpanded: Bool
    let thumb: Thumbnails.Loader?
    let toggle: () -> Void

    var body: some View {
        HStack(spacing: 5) {
            if row.node.isFolder {
                Button(action: toggle) {
                    Image(systemName: "chevron.right")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.secondary)
                        .rotationEffect(.degrees(isExpanded ? 90 : 0))
                        .frame(width: 14, height: 14)
                        .contentShape(.rect)
                }
                .buttonStyle(.plain)
                .accessibilityLabel(isExpanded ? "Tutup folder" : "Buka folder")
                Image(systemName: "folder.fill")
                    .foregroundStyle(.tint)
            } else {
                Color.clear.frame(width: 14, height: 14)
                if let file = row.node.file, thumb != nil {
                    ThumbnailView(fsId: file.fsId, symbol: FileKinds.symbol(name: file.name, category: file.category),
                                  load: thumb, symbolFont: .caption)
                        .frame(width: 30, height: 18)
                        .clipShape(.rect(cornerRadius: 3))
                } else {
                    Image(systemName: FileKinds.symbol(name: row.node.name, category: row.node.file?.category ?? 0))
                        .foregroundStyle(.secondary)
                        .frame(width: 30)
                }
            }
            Text(row.node.name)
                .lineLimit(1)
                .truncationMode(.middle)
        }
        .padding(.leading, CGFloat(row.depth) * 18)
    }
}

private struct StatusBar: View {
    @Environment(AppModel.self) private var model
    let browser: ShareBrowser

    var body: some View {
        HStack {
            Text(selectionText)
            Spacer()
            if let notice = model.notice {
                Label(notice, systemImage: "checkmark.circle.fill")
                    .foregroundStyle(.secondary)
                    .transition(.opacity)
            }
        }
        .font(.callout)
        .foregroundStyle(.secondary)
        .padding(.horizontal, 14)
        .padding(.vertical, 7)
        .background(.bar)
        .overlay(alignment: .top) { Divider() }
        .animation(.default, value: model.notice)
    }

    private var selectionText: String {
        let all = browser.allFiles
        if browser.selection.isEmpty {
            return "\(all.count) file. Simpan dan Unduh berlaku untuk semuanya."
        }
        let picked = browser.selectedFiles
        let size = picked.reduce(Int64(0)) { $0 + $1.size }
        return "\(picked.count) dari \(all.count) file dipilih, \(size.fileSize)"
    }
}

struct PasswordSheet: View {
    @Environment(\.dismiss) private var dismiss
    let wrong: Bool
    let submit: (String) -> Void
    @State private var code = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Masukkan kode akses")
                .font(.headline)
            Text("Link ini dikunci oleh pemiliknya. Kodenya biasanya 4 karakter dan dikirim bersama link.")
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
            TextField("Kode akses", text: $code)
                .textFieldStyle(.roundedBorder)
                .onSubmit(confirm)
            if wrong {
                Label("Kode tadi salah. Periksa lagi huruf besar dan kecilnya.", systemImage: "exclamationmark.circle")
                    .foregroundStyle(.red)
                    .font(.callout)
            }
            HStack {
                Spacer()
                Button("Batal", role: .cancel) { dismiss() }
                    .keyboardShortcut(.cancelAction)
                Button("Buka Link", action: confirm)
                    .keyboardShortcut(.defaultAction)
                    .disabled(code.trimmingCharacters(in: .whitespaces).isEmpty)
            }
        }
        .padding(20)
        .frame(width: 360)
    }

    private func confirm() {
        let c = code.trimmingCharacters(in: .whitespaces)
        guard !c.isEmpty else { return }
        dismiss()
        submit(c)
    }
}
