import SwiftUI

struct SidebarView: View {
    @Environment(AppModel.self) private var model

    var body: some View {
        @Bindable var model = model
        List(selection: $model.sidebar) {
            Section {
                Label(model.browser?.title ?? "Isi Link", systemImage: "link")
                    .tag(SidebarItem.share)
                if model.player.current != nil, model.player.current?.libraryURL == nil {
                    Label(model.player.current?.file.name ?? "", systemImage: "play.circle")
                        .lineLimit(1)
                        .tag(SidebarItem.nowPlaying)
                }
                DownloadsRowLabel()
                    .tag(SidebarItem.downloads)
            }

            Section("Perpustakaan") {
                if model.library.nodes.isEmpty {
                    Text("Belum ada yang disimpan")
                        .font(.callout)
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                        .selectionDisabled()
                } else {
                    Label("Semua yang Disimpan", systemImage: "square.grid.2x2")
                        .badge(model.library.count)
                        .tag(SidebarItem.libraryFolder(model.library.root))
                    ForEach(model.library.nodes) { node in
                        LibraryRow(node: node)
                    }
                }
            }
        }
        .listStyle(.sidebar)
        .contextMenu {
            Button("Tampilkan Perpustakaan di Finder") {
                NSWorkspace.shared.activateFileViewerSelecting([model.library.root])
            }
            Button("Muat Ulang Perpustakaan") { model.library.reload() }
        }
        .onReceive(NotificationCenter.default.publisher(for: NSApplication.didBecomeActiveNotification)) { _ in
            model.library.reload()
        }
    }
}

private struct DownloadsRowLabel: View {
    @Environment(AppModel.self) private var model

    var body: some View {
        let active = model.downloads.activeCount
        Label("Unduhan", systemImage: "arrow.down.circle")
            .badge(active)
    }
}

private struct LibraryRow: View {
    @Environment(AppModel.self) private var model
    let node: LibraryNode

    var body: some View {
        if let children = node.children {
            DisclosureGroup(isExpanded: expansion) {
                ForEach(children) { LibraryRow(node: $0) }
            } label: {
                Label(node.name, systemImage: "folder")
                    .tag(SidebarItem.libraryFolder(node.url))
            }
        } else if let entry = node.entry {
            let isCurrent = model.player.current?.libraryURL == node.url && model.player.phase != .unsupported
            Label {
                Text(entry.name)
                    .lineLimit(1)
                    .truncationMode(.middle)
            } icon: {
                Image(systemName: isCurrent ? "speaker.wave.2.fill" : FileKinds.symbol(name: entry.name, category: entry.category ?? 0))
            }
            .help("\(entry.path)\n\(entry.size.fileSize)")
            .tag(SidebarItem.library(node.url))
            .contextMenu {
                LibraryItemMenu(url: node.url, entry: entry)
            }
        }
    }

    private var expansion: Binding<Bool> {
        Binding {
            model.library.expanded.contains(node.url)
        } set: { open in
            if open { model.library.expanded.insert(node.url) } else { model.library.expanded.remove(node.url) }
        }
    }
}
