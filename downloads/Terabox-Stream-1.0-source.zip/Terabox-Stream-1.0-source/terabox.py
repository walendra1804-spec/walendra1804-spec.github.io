#!/usr/bin/env python3
"""
Terabox share downloader (MVP) - semua lewat terminal.

Pemakaian:
  python3 terabox.py                          # mode interaktif (input link, pilih file)
  python3 terabox.py list <link>              # tampilkan isi folder/file (rekursif)
  python3 terabox.py download <link> [-o DIR] [-y] [--only "1,3,5-8"]
  python3 terabox.py save <link> [--only ...] # simpan link stream (.tblink) ke Perpustakaan/
  python3 terabox.py play <link | file.tblink>  # streaming langsung tanpa download
  python3 terabox.py library                  # pilih & putar dari Perpustakaan/

Cookie (opsional; pakai kalau download ditolak dengan pesan 'butuh cookie'):
  - argumen  --cookie "ndus=xxxx"
  - env      TERABOX_COOKIE="ndus=xxxx"
  - file     cookie.txt (di folder yang sama dengan script ini)

Hanya memakai library standar Python (tidak perlu pip install).
"""

import argparse
import hashlib
import hmac
import html
import json
import mimetypes
import os
import re
import sys
import threading
import time
import webbrowser
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import urllib.error
import urllib.parse
import urllib.request
from http.cookiejar import CookieJar

UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36")
BASE_PARAMS = {"app_id": "250528", "web": "1", "channel": "dubox", "clienttype": "0"}
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
LIBRARY_DIR = os.path.join(SCRIPT_DIR, "Perpustakaan")
LINK_EXT = ".tblink"
NEED_VERIFY = 400141
COOKIE_HINT = ("Server menolak: butuh cookie login Terabox (ndus). "
               "Lihat README.md bagian 'Cookie'.")


class TeraboxError(Exception):
    pass


class NeedPassword(TeraboxError):
    pass


class ApiError(TeraboxError):
    def __init__(self, msg, errno=None):
        super().__init__(msg)
        self.errno = errno


def parse_cookie_string(raw):
    out = {}
    for part in (raw or "").split(";"):
        if "=" in part:
            k, v = part.split("=", 1)
            if k.strip():
                out[k.strip()] = v.strip()
    return out


class MergedCookieProcessor(urllib.request.HTTPCookieProcessor):
    """Kirim cookie sesi (dari jar) DAN cookie login user bersamaan.

    HTTPCookieProcessor bawaan tidak menambahkan cookie jar kalau request
    sudah punya header Cookie, jadi keduanya digabung di sini.
    """

    def __init__(self, jar, user_cookie):
        super().__init__(jar)
        self.user = parse_cookie_string(user_cookie)

    def http_request(self, request):
        request = super().http_request(request)
        if self.user:
            merged = parse_cookie_string(request.get_header("Cookie", ""))
            merged.update(self.user)
            request.remove_header("Cookie")
            request.add_unredirected_header("Cookie", "; ".join(f"{k}={v}" for k, v in merged.items()))
        return request

    https_request = http_request


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #

def human_size(n):
    n = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.2f} {unit}"
        n /= 1024


def safe_name(name):
    # Aman untuk Windows/macOS/Linux
    name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", name).strip().rstrip(".")
    return name or "_"


def load_cookie(cli_value):
    raw = cli_value or os.environ.get("TERABOX_COOKIE")
    if not raw:
        path = os.path.join(SCRIPT_DIR, "cookie.txt")
        if os.path.isfile(path):
            with open(path, encoding="utf-8") as f:
                raw = f.read()
    if not raw:
        return None
    raw = raw.strip()
    if not raw:
        return None
    if "=" not in raw:  # user cuma paste nilai ndus-nya saja
        raw = f"ndus={raw}"
    return raw


def parse_link_pwd(link):
    """Kode akses kadang ikut di link, mis. .../s/1abc?pwd=xyz1"""
    u = urllib.parse.urlparse(link if "://" in link else "https://" + link)
    return urllib.parse.parse_qs(u.query).get("pwd", [None])[0]


def parse_short_url(link):
    """Ambil kode share dari berbagai bentuk link Terabox.

    Mengembalikan surl tanpa awalan '1' (dipakai /share/list);
    shorturlinfo memakai versi dengan awalan '1'.
    """
    link = link.strip()
    u = urllib.parse.urlparse(link if "://" in link else "https://" + link)
    q = urllib.parse.parse_qs(u.query)
    if "surl" in q:
        return q["surl"][0]
    m = re.search(r"/s/([A-Za-z0-9_-]+)", u.path)
    if m:
        code = m.group(1)
        return code[1:] if code.startswith("1") else code
    raise TeraboxError(f"Link tidak dikenali: {link}")


def parse_selection(text, max_n):
    text = text.strip().lower()
    if text in ("", "all", "a", "semua", "*"):
        return list(range(1, max_n + 1))
    picked = set()
    for part in text.replace(" ", "").split(","):
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            picked.update(range(int(a), int(b) + 1))
        else:
            picked.add(int(part))
    bad = [i for i in picked if i < 1 or i > max_n]
    if bad:
        raise ValueError(f"Nomor di luar jangkauan: {bad}")
    return sorted(picked)


# --------------------------------------------------------------------------- #
# Terabox client
# --------------------------------------------------------------------------- #

class TeraboxShare:
    def __init__(self, link, cookie=None, pwd=None):
        self.link = link
        self.surl = parse_short_url(link)
        self.cookie = cookie
        self.pwd = pwd or parse_link_pwd(link)
        self.sekey = None  # dari /share/verify untuk share berkode akses
        self.jar = CookieJar()
        self.opener = urllib.request.build_opener(MergedCookieProcessor(self.jar, cookie))
        self.host = "https://www.terabox.app"
        self.js_token = None
        self.info = None  # hasil shorturlinfo

    # ---- HTTP -------------------------------------------------------------
    def _headers(self, referer=None):
        h = {"User-Agent": UA, "Accept": "application/json, text/plain, */*"}
        if referer:
            h["Referer"] = referer
        return h

    def browserid(self):
        host = urllib.parse.urlparse(self.host).hostname or ""
        return next((c.value for c in self.jar if c.name == "browserid"
                     and host.endswith(c.domain.lstrip("."))), "")

    def _open(self, url, data=None, referer=None, timeout=30):
        req = urllib.request.Request(url, data=data, headers=self._headers(referer))
        return self.opener.open(req, timeout=timeout)

    def _api(self, path, params=None, data=None):
        p = dict(BASE_PARAMS)
        if self.js_token:
            p["jsToken"] = self.js_token
        if self.browserid():
            p["devuid"] = self.browserid()  # selalu dikirim oleh web Terabox
        p.update(params or {})
        url = f"{self.host}{path}?{urllib.parse.urlencode(p)}"
        body = urllib.parse.urlencode(data).encode() if data is not None else None
        referer = f"{self.host}/sharing/link?surl={self.surl}"
        for attempt in range(3):
            try:
                with self._open(url, body, referer) as r:
                    d = json.loads(r.read().decode("utf-8", "replace"))
            except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as e:
                if attempt == 2:
                    raise TeraboxError(f"Gagal request {path}: {e}")
                time.sleep(1.5 * (attempt + 1))
                continue
            # 400141 "need verify" = pembatasan anti-bot yang sifatnya sementara
            if d.get("errno") == NEED_VERIFY and attempt < 2:
                time.sleep(2 + 3 * attempt)
                continue
            return d

    # ---- Langkah-langkah ---------------------------------------------------
    def init(self):
        """Buka halaman share untuk dapat cookie sesi + jsToken."""
        url = self.link if "://" in self.link else "https://" + self.link
        for attempt in range(3):
            try:
                with self._open(url) as r:
                    final = urllib.parse.urlparse(r.geturl())
                    html = r.read().decode("utf-8", "replace")
            except urllib.error.URLError as e:
                raise TeraboxError(f"Tidak bisa membuka link: {e}")
            if final.netloc:
                self.host = f"{final.scheme}://{final.netloc}"
            m = re.search(r'fn\("([A-Fa-f0-9]{32,})"\)', urllib.parse.unquote(html))
            if m:
                break
            time.sleep(2 + 2 * attempt)  # kadang Terabox mengirim varian halaman tanpa token
        else:
            raise TeraboxError("jsToken tidak ditemukan (format halaman Terabox mungkin berubah).")
        self.js_token = m.group(1)
        if self.pwd:
            self.verify(self.pwd)
        self.refresh_info()

    def verify(self, pwd):
        """Buka share berkode akses (seperti mengetik kode di web Terabox)."""
        d = self._api("/share/verify", {"surl": self.surl},
                      {"pwd": pwd, "vcode": "", "vcode_str": ""})
        errno = d.get("errno")
        if errno in (-9, -12):
            raise NeedPassword("Kode akses salah.")
        if errno == -62:
            raise TeraboxError("Terabox minta captcha karena terlalu banyak percobaan. "
                               "Tunggu beberapa menit lalu coba lagi.")
        if errno != 0:
            raise TeraboxError(f"share/verify gagal: {describe(d)}")
        self.pwd = pwd
        self.sekey = urllib.parse.unquote(d.get("randsk", "")) or None

    def refresh_info(self):
        d = self._api("/api/shorturlinfo", {"shorturl": "1" + self.surl, "root": "1"})
        errno = d.get("errno")
        if errno == -9:
            raise NeedPassword("Link ini butuh kode akses.")
        if errno != 0:
            hint = ""
            if errno in (105, 2, -21, -4, -8):
                hint = " (link mungkin sudah dihapus/kedaluwarsa)"
            raise TeraboxError(f"shorturlinfo gagal: {describe(d)}{hint}")
        self.info = d

    def list_dir(self, path=None, fallback=True):
        try:
            return self._list_dir(path)
        except NeedPassword:
            raise
        except ApiError as e:
            if not fallback:
                raise
            # Sebagian share menolak share/list ("need verify", errno 400141).
            # Web Terabox sendiri tidak memanggil share/list untuk folder utama,
            # jadi pakai data folder utama dari shorturlinfo.
            if path is None and self.info and self.info.get("list"):
                print(f"  [info] share/list ditolak (errno {e.errno}); memakai data dari shorturlinfo")
                return self._sorted(self.info["list"])
            if self.cookie:  # coba lagi sebagai tamu (tanpa cookie login)
                try:
                    print(f"  [info] share/list ditolak (errno {e.errno}); mencoba sebagai tamu...")
                    return self._guest().list_dir(path, fallback=False)
                except TeraboxError:
                    pass
            raise

    def _guest(self):
        if not getattr(self, "_guest_share", None):
            g = TeraboxShare(self.link, None, self.pwd)
            g.init()
            self._guest_share = g
        return self._guest_share

    @staticmethod
    def _sorted(items):
        return sorted(items, key=lambda it: (str(it.get("isdir")) != "1",
                                             it.get("server_filename", "").lower()))

    def _list_dir(self, path):
        items, page = [], 1
        while True:
            # Parameter disamakan dengan web Terabox (num 20, by/order, tanpa
            # root=0 untuk subfolder); urutan nama diurus sendiri di bawah.
            params = {"shorturl": self.surl, "page": str(page), "num": "20",
                      "by": "time", "order": "desc", "scene": ""}
            if path is None:
                params["root"] = "1"
            else:
                params["dir"] = path
            d = self._api("/share/list", params)
            if d.get("errno") == -9:
                raise NeedPassword("Link ini butuh kode akses.")
            if d.get("errno") != 0:
                raise ApiError(f"share/list gagal untuk folder {path or '/'}: {describe(d)}",
                               d.get("errno"))
            batch = d.get("list", [])
            items.extend(batch)
            if len(batch) < 20:
                return self._sorted(items)
            page += 1

    def walk(self, path=None, rel="", on_dir=None):
        """Rekursif: kembalikan list semua file dengan path relatif."""
        files = []
        for it in self.list_dir(path):
            name = it["server_filename"]
            rel_path = f"{rel}/{name}" if rel else name
            if str(it.get("isdir")) == "1":
                if on_dir:
                    on_dir(rel_path)
                files.extend(self.walk(it["path"], rel_path, on_dir))
            else:
                files.append({
                    "fs_id": int(it["fs_id"]),
                    "name": name,
                    "rel": rel_path,
                    "size": int(it.get("size", 0)),
                    "md5": it.get("md5", ""),
                    "category": int(it.get("category", 0)),
                })
        return files

    STREAM_KEY = b"iuuPc64E4Fhn0rTXEzrnbLph0o5qyEEa"  # dari JS player web Terabox

    def get_m3u8(self, fs_id, types):
        """Playlist HLS seperti yang dipakai player web Terabox (butuh login).

        sign = HMAC-SHA1(clienttype + channel + browserid + timestamp).
        Mencoba tiap `type` berurutan; kembalikan (type, isi m3u8).
        """
        browserid = self.browserid()
        last = None
        for typ in types:
            ts = str(int(time.time()))
            msg = f"{BASE_PARAMS['clienttype']}{BASE_PARAMS['channel']}{browserid}{ts}"
            params = dict(BASE_PARAMS, uk=self.info["uk"], shareid=self.info["shareid"], type=typ,
                          fid=fs_id, sign=hmac.new(self.STREAM_KEY, msg.encode(), hashlib.sha1).hexdigest(),
                          timestamp=ts, jsToken=self.js_token, esl=1, isplayer=1, ehps=1)
            url = f"{self.host}/share/streaming?{urllib.parse.urlencode(params)}"
            with self._open(url, referer=f"{self.host}/sharing/link?surl={self.surl}") as r:
                body = r.read().decode("utf-8", "replace")
            if body.lstrip().startswith("#EXTM3U"):
                return typ, body
            try:
                last = json.loads(body)
            except json.JSONDecodeError:
                last = {"errno": None, "show_msg": body[:200]}
        hint = "" if self.cookie else " Streaming video butuh cookie login (lihat README bagian 'Cookie')."
        raise ApiError(f"share/streaming gagal: {describe(last or {})}{hint}", (last or {}).get("errno"))

    def get_dlinks(self, fs_ids):
        """Minta direct link (berlaku ~1 jam). Return {fs_id: dlink}."""
        for attempt in range(2):
            info = self.info
            sekey = self.sekey or urllib.parse.unquote(info.get("randsk", ""))
            data = {
                "encrypt": "0",
                "extra": json.dumps({"sekey": sekey}),
                "fid_list": json.dumps(fs_ids),
                "primaryid": str(info["shareid"]),
                "uk": str(info["uk"]),
                "product": "share",
                "type": "nolimit",
            }
            d = self._api("/api/sharedownload",
                          {"sign": info["sign"], "timestamp": str(info["timestamp"])}, data)
            if d.get("errno") == 0:
                return {int(x["fs_id"]): x.get("dlink") for x in d.get("list", [])}
            if attempt == 0:  # sign kadaluarsa -> refresh lalu coba lagi
                self.refresh_info()
                continue
            raise ApiError(f"sharedownload gagal: {describe(d)}", d.get("errno"))

    def download(self, dlink, dest, size, label):
        """Download dengan resume (.part) + progress bar."""
        if os.path.isfile(dest) and os.path.getsize(dest) == size:
            print(f"  [skip] sudah ada: {label}")
            return True
        os.makedirs(os.path.dirname(dest) or ".", exist_ok=True)
        part = dest + ".part"
        done = os.path.getsize(part) if os.path.isfile(part) else 0
        if done > size:
            os.remove(part)
            done = 0

        headers = self._headers(referer=f"{self.host}/")
        if done:
            headers["Range"] = f"bytes={done}-"
        req = urllib.request.Request(dlink, headers=headers)
        try:
            resp = self.opener.open(req, timeout=60)
        except urllib.error.HTTPError as e:
            raise http_error(e)

        with resp:
            if done and resp.status != 206:  # server tidak dukung resume
                done = 0
            mode = "ab" if done else "wb"
            start, last = time.time(), 0.0
            got = 0
            with open(part, mode) as f:
                while True:
                    chunk = resp.read(1024 * 256)
                    if not chunk:
                        break
                    f.write(chunk)
                    got += len(chunk)
                    now = time.time()
                    if now - last > 0.3:
                        last = now
                        self._progress(label, done + got, size, got / max(now - start, 1e-6))
            self._progress(label, done + got, size, got / max(time.time() - start, 1e-6))
            print()

        if size and os.path.getsize(part) != size:
            raise TeraboxError(f"Ukuran tidak cocok untuk {label} "
                               f"({os.path.getsize(part)} vs {size}). Jalankan lagi untuk resume.")
        os.replace(part, dest)
        return True

    @staticmethod
    def _progress(label, cur, total, speed):
        width = 28
        frac = cur / total if total else 1
        bar = "#" * int(width * frac) + "-" * (width - int(width * frac))
        name = label if len(label) <= 40 else "..." + label[-37:]
        sys.stdout.write(f"\r  [{bar}] {frac * 100:5.1f}% {human_size(cur):>10}/"
                         f"{human_size(total):<10} {human_size(speed)}/s  {name}   ")
        sys.stdout.flush()


def describe(d):
    """Ringkas respons error Terabox supaya mudah dilaporkan."""
    msg = d.get("show_msg") or d.get("errmsg") or d.get("error_msg") or ""
    raw = json.dumps({k: v for k, v in d.items() if k not in ("list",)}, ensure_ascii=False)
    return f"errno={d.get('errno')} {msg} | respons: {raw[:300]}"


def http_error(e):
    body = e.read()[:300].decode("utf-8", "replace")
    if '"error_code":31045' in body or "user not exists" in body:
        return TeraboxError(COOKIE_HINT)
    return TeraboxError(f"HTTP {e.code}: {body}")


# --------------------------------------------------------------------------- #
# Perpustakaan: file .tblink = "alamat permanen" sebuah file Terabox.
# Isinya bukan dlink (kedaluwarsa ~1 jam), tapi link share + fs_id, sehingga
# dlink segar bisa diminta ulang setiap kali diputar.
# --------------------------------------------------------------------------- #

def save_links(share, files, lib_dir=LIBRARY_DIR):
    saved = []
    for f in files:
        parts = [safe_name(p) for p in f["rel"].split("/")]
        dest = os.path.join(lib_dir, *parts) + LINK_EXT
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        entry = {
            "type": "terabox-stream",
            "version": 1,
            "name": f["name"],
            "path": f["rel"],
            "size": f["size"],
            "md5": f.get("md5", ""),
            "category": f.get("category", 0),
            "fs_id": f["fs_id"],
            "share_link": share.link,
            "pwd": share.pwd or "",
            "shareid": share.info.get("shareid"),
            "uk": share.info.get("uk"),
            "saved_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        }
        with open(dest, "w", encoding="utf-8") as fp:
            json.dump(entry, fp, ensure_ascii=False, indent=2)
        saved.append(dest)
    return saved


def read_link_file(path):
    with open(path, encoding="utf-8") as fp:
        entry = json.load(fp)
    if entry.get("type") != "terabox-stream":
        raise TeraboxError(f"Bukan file {LINK_EXT} yang valid: {path}")
    return entry


def list_library(lib_dir=LIBRARY_DIR):
    found = []
    for root, _, names in os.walk(lib_dir):
        for n in names:
            if n.endswith(LINK_EXT):
                found.append(os.path.join(root, n))
    return sorted(found, key=lambda p: os.path.relpath(p, lib_dir).lower())


# --------------------------------------------------------------------------- #
# Streaming: server HTTP lokal di 127.0.0.1.
#  - Mode "asli": meneruskan request (termasuk Range untuk seek) ke dlink,
#    sambil menyisipkan cookie & memperbarui dlink yang kedaluwarsa.
#  - Mode "HLS": memakai /share/streaming seperti player web Terabox (video
#    sudah ditranscode ke H.264). Playlist diambil dengan cookie; segmen .ts
#    diteruskan lewat server lokal supaya bisa diputar di browser mana pun.
# --------------------------------------------------------------------------- #

VIDEO_HLS_TYPES = ["M3U8_AUTO_720", "M3U8_AUTO_480", "M3U8_AUTO_360"]
AUDIO_HLS_TYPES = ["M3U8_MP3_128"]
SEGMENT_HOSTS = ("terabox.app", "terabox.com", "1024tera.com", "teraboxcdn.com", "1024terabox.com")


class StreamSource:
    DLINK_TTL = 45 * 60  # dlink berlaku ~1 jam; perbarui lebih awal

    def __init__(self, share, fs_id):
        self.share = share
        self.fs_id = fs_id
        self.lock = threading.Lock()
        self.dlink = None
        self.fetched_at = 0.0

    def _link(self, force=False):
        with self.lock:
            if force or not self.dlink or time.time() - self.fetched_at > self.DLINK_TTL:
                self.dlink = self.share.get_dlinks([self.fs_id]).get(self.fs_id)
                self.fetched_at = time.time()
                if not self.dlink:
                    raise TeraboxError("dlink kosong dari server")
            return self.dlink

    def open(self, range_header=None):
        for attempt in range(2):
            headers = self.share._headers(referer=f"{self.share.host}/")
            if range_header:
                headers["Range"] = range_header
            req = urllib.request.Request(self._link(force=attempt > 0), headers=headers)
            try:
                return self.share.opener.open(req, timeout=60)
            except urllib.error.HTTPError as e:
                if e.code == 416:
                    raise
                if attempt == 0 and e.code in (403, 404, 410):
                    continue  # mungkin dlink kedaluwarsa, minta yang baru
                raise http_error(e)


class HlsSource:
    PLAYLIST_TTL = 20 * 60

    def __init__(self, share, fs_id, types):
        self.share = share
        self.fs_id = fs_id
        self.types = types
        self.lock = threading.Lock()
        self.text = None
        self.type = None
        self.fetched_at = 0.0

    def playlist(self):
        with self.lock:
            if not self.text or time.time() - self.fetched_at > self.PLAYLIST_TTL:
                self.type, raw = self.share.get_m3u8(self.fs_id, self.types)
                self.text = self._rewrite(raw, self.share.host + "/")
                self.fetched_at = time.time()
            return self.text

    @staticmethod
    def _rewrite(raw, base):
        out = []
        for line in raw.splitlines():
            item = line.strip()
            if item and not item.startswith("#"):
                url = urllib.parse.urljoin(base, item)
                line = "/seg?u=" + urllib.parse.quote(url, safe="")
            out.append(line)
        return "\n".join(out) + "\n"

    @staticmethod
    def open_segment(url):
        host = urllib.parse.urlparse(url).hostname or ""
        if not any(host == h or host.endswith("." + h) for h in SEGMENT_HOSTS):
            raise TeraboxError(f"Host segmen tidak dikenal: {host}")
        req = urllib.request.Request(url, headers={"User-Agent": UA})
        return urllib.request.urlopen(req, timeout=60)

    def label(self):
        q = (self.type or "").rsplit("_", 1)[-1]
        return f"HLS {q}p (hasil transcode Terabox)" if q.isdigit() and self.type.startswith("M3U8_AUTO") \
            else f"HLS {self.type}"


def guess_mime(name):
    mime, _ = mimetypes.guess_type(name)
    extra = {".mkv": "video/x-matroska", ".m4a": "audio/mp4", ".flac": "audio/flac",
             ".ts": "video/mp2t", ".webm": "video/webm"}
    return mime or extra.get(os.path.splitext(name)[1].lower(), "application/octet-stream")


PLAYER_PAGE = """<!doctype html>
<html lang="id"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{title}</title>
<style>
  :root {{ color-scheme: light dark; }}
  body {{ margin: 0; font: 14px -apple-system, system-ui, sans-serif; background: Canvas; color: CanvasText;
         min-height: 100vh; display: grid; place-items: center; }}
  main {{ width: min(960px, 100% - 32px); }}
  h1 {{ font-size: 15px; font-weight: 600; margin: 0 0 2px; overflow-wrap: anywhere; }}
  p {{ margin: 0 0 14px; opacity: .6; font-size: 12px; }}
  video, img {{ width: 100%; max-height: 80vh; background: #000; border-radius: 6px; }}
  audio {{ width: 100%; }}
</style></head>
<body><main>
  <h1>{title}</h1>
  <p>{meta}</p>
  {player}
</main></body></html>
"""

HLS_PLAYER = """<{tag} id="m" controls autoplay playsinline></{tag}>
<script>
  const m = document.getElementById("m"), src = "/stream.m3u8";
  if (m.canPlayType("application/vnd.apple.mpegurl")) {{
    m.src = src;  // Safari: HLS bawaan
  }} else {{
    const s = document.createElement("script");
    s.src = "https://cdnjs.cloudflare.com/ajax/libs/hls.js/1.5.13/hls.min.js";
    s.onload = () => {{ const h = new Hls(); h.loadSource(src); h.attachMedia(m); }};
    document.head.appendChild(s);
  }}
</script>"""


def make_handler(source, name, size):
    mime = guess_mime(name)
    hls = isinstance(source, HlsSource)
    if hls:
        player = HLS_PLAYER.format(tag="audio" if mime.startswith("audio/") else "video")
        mode = source.label()
    elif mime.startswith("video/"):
        player = '<video src="/stream" controls autoplay playsinline></video>'
    elif mime.startswith("audio/"):
        player = '<audio src="/stream" controls autoplay></audio>'
    elif mime.startswith("image/"):
        player = '<img src="/stream" alt="">'
    else:
        player = '<p><a href="/stream">Buka file</a> (jenis file ini mungkin tidak bisa diputar di browser)</p>'
    if not hls:
        mode = "file asli"
    page = PLAYER_PAGE.format(title=html.escape(name), player=player,
                              meta=html.escape(f"{human_size(size)} · {mode} · streaming dari Terabox"))
    page_bytes = page.encode("utf-8")

    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, *a):
            pass

        def do_HEAD(self):
            self._route(send_body=False)

        def do_GET(self):
            self._route(send_body=True)

        def _send_bytes(self, data, ctype, send_body):
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            if send_body:
                self.wfile.write(data)

        def _route(self, send_body):
            route = urllib.parse.urlparse(self.path)
            try:
                if route.path in ("/", "/index.html"):
                    self._send_bytes(page_bytes, "text/html; charset=utf-8", send_body)
                elif hls and route.path == "/stream.m3u8":
                    self._send_bytes(source.playlist().encode(), "application/vnd.apple.mpegurl", send_body)
                elif hls and route.path == "/seg":
                    url = urllib.parse.parse_qs(route.query).get("u", [""])[0]
                    self._pipe(HlsSource.open_segment(url), "video/mp2t", send_body)
                elif not hls and route.path == "/stream":
                    self._direct(send_body)
                else:
                    self.send_error(404)
            except TeraboxError as e:
                print(f"\n  [stream error] {e}")
                self.send_error(502, str(e)[:200])
            except urllib.error.HTTPError as e:
                print(f"\n  [stream error] HTTP {e.code} dari server Terabox")
                self.send_error(502, f"HTTP {e.code}")
            except (BrokenPipeError, ConnectionResetError):
                pass  # player menutup koneksi (seek/stop) - normal

        def _direct(self, send_body):
            try:
                up = source.open(self.headers.get("Range"))
            except urllib.error.HTTPError as e:  # 416: range di luar ukuran file
                self.send_response(e.code)
                self.send_header("Content-Range", f"bytes */{size}")
                self.send_header("Content-Length", "0")
                self.end_headers()
                return
            self._pipe(up, mime, send_body, ranges=True)

        def _pipe(self, up, ctype, send_body, ranges=False):
            with up:
                self.send_response(up.status)
                self.send_header("Content-Type", ctype)
                if ranges:
                    self.send_header("Accept-Ranges", "bytes")
                    if up.headers.get("Content-Range"):
                        self.send_header("Content-Range", up.headers["Content-Range"])
                length = up.headers.get("Content-Length")
                if length:
                    self.send_header("Content-Length", length)
                else:
                    self.close_connection = True
                    self.send_header("Connection", "close")
                self.end_headers()
                if not send_body:
                    return
                while True:
                    chunk = up.read(256 * 1024)
                    if not chunk:
                        break
                    self.wfile.write(chunk)

    return Handler


def pick_source(share, fs_id, name, category=0, quality=None):
    """Video -> HLS (seperti web Terabox), lainnya -> file asli; saling jadi cadangan."""
    mime = guess_mime(name)
    is_video = category == 1 or mime.startswith("video/")
    is_audio = category == 2 or mime.startswith("audio/")
    video_types = [f"M3U8_AUTO_{quality}"] if quality else VIDEO_HLS_TYPES

    def try_hls(types):
        src = HlsSource(share, fs_id, types)
        src.playlist()
        return src

    def try_direct():
        src = StreamSource(share, fs_id)
        src.open("bytes=0-0").close()  # cek di awal supaya error langsung kelihatan
        return src

    order = [lambda: try_hls(video_types), try_direct] if is_video else \
        [try_direct, lambda: try_hls(AUDIO_HLS_TYPES)] if is_audio else [try_direct]
    errors = []
    for attempt in order:
        try:
            return attempt()
        except TeraboxError as e:
            errors.append(str(e))
            if len(errors) < len(order):
                print(f"  [info] {e}\n  [info] mencoba cara lain...")
    raise TeraboxError(" | ".join(errors))


def stream(share, fs_id, name, size, category=0, open_browser=True, quality=None):
    print("Meminta link streaming...")
    source = pick_source(share, fs_id, name, category, quality)
    server = ThreadingHTTPServer(("127.0.0.1", 0), make_handler(source, name, size))
    server.daemon_threads = True
    url = f"http://127.0.0.1:{server.server_address[1]}/"
    hls = isinstance(source, HlsSource)
    print(f"\nSedang streaming: {name} ({human_size(size)})")
    print(f"  Mode   : {source.label() if hls else 'file asli'}")
    print(f"  Player : {url}")
    print(f"  Langsung (untuk VLC/IINA/mpv): {url}{'stream.m3u8' if hls else 'stream'}")
    print("Tekan Ctrl+C untuk berhenti.\n")
    if open_browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("Streaming dihentikan.")
    finally:
        server.server_close()


# --------------------------------------------------------------------------- #
# CLI
# --------------------------------------------------------------------------- #

def fetch_tree(share):
    print("Membuka link...")
    while True:
        try:
            share.init()
            break
        except NeedPassword as e:
            if not sys.stdin.isatty():
                raise TeraboxError(f"{e} Tambahkan --pwd KODE.")
            share.pwd = input(f"{e} Masukkan kode akses (4 karakter dari pemilik link): ").strip()
            if not share.pwd:
                raise TeraboxError("Dibatalkan: kode akses kosong.")
    owner = share.info.get("share_username", "?")
    print(f"Share milik: {owner}  |  shareid: {share.info.get('shareid')}")
    print("Menjelajahi folder (rekursif)...")
    files = share.walk(on_dir=lambda p: print(f"  [dir] {p}"))
    return files


def print_files(files):
    total = sum(f["size"] for f in files)
    print(f"\nDitemukan {len(files)} file, total {human_size(total)}:\n")
    w = len(str(len(files)))
    for i, f in enumerate(files, 1):
        print(f"  {str(i).rjust(w)}. {f['rel']}  ({human_size(f['size'])})")
    print()


def download_files(share, files, out_dir):
    ok, fail = 0, []
    for idx, f in enumerate(files, 1):
        dest = os.path.join(out_dir, *[safe_name(p) for p in f["rel"].split("/")])
        print(f"[{idx}/{len(files)}] {f['rel']}")
        try:
            dlink = share.get_dlinks([f["fs_id"]]).get(f["fs_id"])
            if not dlink:
                raise TeraboxError("dlink kosong dari server")
            share.download(dlink, dest, f["size"], f["name"])
            ok += 1
        except TeraboxError as e:
            print(f"\n  [gagal] {e}")
            fail.append(f["rel"])
            if "butuh cookie" in str(e):
                break  # semua file lain pasti gagal juga
        except KeyboardInterrupt:
            print("\nDibatalkan. Jalankan ulang untuk melanjutkan (resume).")
            break
    print(f"\nSelesai: {ok} berhasil, {len(fail)} gagal. Folder: {os.path.abspath(out_dir)}")
    for r in fail:
        print(f"  - gagal: {r}")
    return not fail


def default_out_dir(share, files):
    # Path relatif file sudah diawali nama folder share, jadi cukup "downloads".
    return "downloads"


def cmd_list(args):
    share = TeraboxShare(args.link, load_cookie(args.cookie), args.pwd)
    files = fetch_tree(share)
    print_files(files)
    if args.json:
        with open(args.json, "w", encoding="utf-8") as fp:
            json.dump(files, fp, ensure_ascii=False, indent=2)
        print(f"Disimpan ke {args.json}")


def cmd_download(args):
    share = TeraboxShare(args.link, load_cookie(args.cookie), args.pwd)
    files = fetch_tree(share)
    print_files(files)
    if not files:
        return
    sel = parse_selection(args.only or "all", len(files))
    chosen = [files[i - 1] for i in sel]
    out_dir = args.output or default_out_dir(share, files)
    if not args.yes:
        ans = input(f"Download {len(chosen)} file ke '{out_dir}'? [Y/n] ").strip().lower()
        if ans not in ("", "y", "ya", "yes"):
            return
    sys.exit(0 if download_files(share, chosen, out_dir) else 1)


def pick_one(count, prompt="Pilih nomor yang mau diputar (q untuk keluar): "):
    while True:
        text = input(prompt).strip().lower()
        if text == "q":
            return None
        if text.isdigit() and 1 <= int(text) <= count:
            return int(text)
        print(f"  Masukkan angka 1-{count}.")


def play_entry(entry, cookie, open_browser=True, quality=None):
    share = TeraboxShare(entry["share_link"], cookie, entry.get("pwd") or None)
    print("Membuka link...")
    share.init()
    stream(share, int(entry["fs_id"]), entry["name"], int(entry.get("size", 0)),
           int(entry.get("category", 0)), open_browser, quality)


def cmd_save(args):
    share = TeraboxShare(args.link, load_cookie(args.cookie), args.pwd)
    files = fetch_tree(share)
    print_files(files)
    if not files:
        return
    chosen = [files[i - 1] for i in parse_selection(args.only or "all", len(files))]
    saved = save_links(share, chosen)
    print(f"Tersimpan {len(saved)} link stream di {LIBRARY_DIR}")


def cmd_play(args):
    cookie = load_cookie(args.cookie)
    if os.path.isfile(args.target):
        return play_entry(read_link_file(args.target), cookie, not args.no_browser, args.kualitas)
    share = TeraboxShare(args.target, cookie, args.pwd)
    files = fetch_tree(share)
    print_files(files)
    if not files:
        return
    n = args.number or (1 if len(files) == 1 else pick_one(len(files)))
    if n:
        f = files[n - 1]
        stream(share, f["fs_id"], f["name"], f["size"], f["category"], not args.no_browser, args.kualitas)


def cmd_library(args):
    items = list_library()
    if not items:
        print(f"Perpustakaan masih kosong. Simpan dulu dengan: python3 terabox.py save <link>")
        return
    print(f"Perpustakaan ({len(items)} item):\n")
    w = len(str(len(items)))
    for i, p in enumerate(items, 1):
        e = read_link_file(p)
        print(f"  {str(i).rjust(w)}. {e['path']}  ({human_size(e.get('size', 0))})")
    print()
    n = pick_one(len(items))
    if n:
        play_entry(read_link_file(items[n - 1]), load_cookie(args.cookie), quality=args.kualitas)


def cmd_interactive(args):
    print("=== Terabox Downloader (MVP) ===")
    link = input("Paste link Terabox (atau Enter untuk buka Perpustakaan): ").strip()
    if not link:
        return cmd_library(args)
    share = TeraboxShare(link, load_cookie(args.cookie), args.pwd)
    files = fetch_tree(share)
    print_files(files)
    if not files:
        print("Tidak ada file.")
        return
    print("Mau apa?  [1] Download   [2] Simpan link stream   [3] Putar sekarang")
    action = pick_one(3, "Pilih 1/2/3 (q untuk keluar): ")
    if action is None:
        return
    if action == 3:
        n = 1 if len(files) == 1 else pick_one(len(files))
        if n:
            f = files[n - 1]
            stream(share, f["fs_id"], f["name"], f["size"], f["category"])
        return
    while True:
        text = input("Pilih nomor file (contoh: 1,3,5-8) atau Enter untuk semua, q untuk keluar: ")
        if text.strip().lower() == "q":
            return
        try:
            sel = parse_selection(text, len(files))
            break
        except ValueError as e:
            print(f"  Input tidak valid: {e}")
    chosen = [files[i - 1] for i in sel]
    if action == 2:
        saved = save_links(share, chosen)
        print(f"Tersimpan {len(saved)} link stream di {LIBRARY_DIR}")
        print("Putar kapan saja dengan: python3 terabox.py library")
        return
    default = default_out_dir(share, files)
    out_dir = input(f"Folder tujuan [{default}]: ").strip() or default
    download_files(share, chosen, out_dir)


def main():
    ap = argparse.ArgumentParser(description="Lihat, download, simpan & streaming isi link share Terabox.")
    ap.add_argument("--cookie", help='Cookie login, mis. "ndus=xxxx" (atau env TERABOX_COOKIE / cookie.txt)')
    ap.add_argument("--pwd", help="Kode akses untuk link privat (kalau tidak diisi, akan ditanya)")
    sub = ap.add_subparsers(dest="cmd")

    ck = argparse.ArgumentParser(add_help=False)
    ck.add_argument("--cookie", default=argparse.SUPPRESS, help=argparse.SUPPRESS)
    ck.add_argument("--pwd", default=argparse.SUPPRESS, help=argparse.SUPPRESS)

    p = sub.add_parser("list", parents=[ck], help="Tampilkan semua folder & file di link")
    p.add_argument("link")
    p.add_argument("--json", help="Simpan daftar file ke file JSON")
    p.set_defaults(func=cmd_list)

    p = sub.add_parser("download", parents=[ck], help="Download file dari link")
    p.add_argument("link")
    p.add_argument("-o", "--output", help="Folder tujuan (default: downloads)")
    p.add_argument("--only", help='Nomor file yang dipilih, mis. "1,3,5-8" (default: semua)')
    p.add_argument("-y", "--yes", action="store_true", help="Tanpa konfirmasi")
    p.set_defaults(func=cmd_download)

    p = sub.add_parser("save", parents=[ck], help="Simpan link stream (.tblink) ke Perpustakaan/")
    p.add_argument("link")
    p.add_argument("--only", help='Nomor file yang dipilih, mis. "1,3,5-8" (default: semua)')
    p.set_defaults(func=cmd_save)

    p = sub.add_parser("play", parents=[ck], help="Streaming file dari link atau file .tblink")
    p.add_argument("target", help="Link Terabox atau path file .tblink")
    p.add_argument("-n", "--number", type=int, help="Nomor file (kalau target berupa link)")
    p.add_argument("--no-browser", action="store_true", help="Jangan buka browser otomatis")
    p.add_argument("--kualitas", type=int, choices=[360, 480, 720, 1080],
                   help="Kualitas video HLS (default: 720, turun otomatis kalau tidak tersedia)")
    p.set_defaults(func=cmd_play)

    p = sub.add_parser("library", parents=[ck], help="Pilih & putar item dari Perpustakaan/")
    p.add_argument("--kualitas", type=int, choices=[360, 480, 720, 1080], help="Kualitas video HLS")
    p.set_defaults(func=cmd_library)

    args = ap.parse_args()
    try:
        (getattr(args, "func", None) or cmd_interactive)(args)
    except TeraboxError as e:
        print(f"\nError: {e}")
        sys.exit(1)
    except (KeyboardInterrupt, EOFError):
        print("\nDibatalkan.")
        sys.exit(130)


if __name__ == "__main__":
    main()
