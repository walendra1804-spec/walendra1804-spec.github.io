import Foundation
import Observation

@Observable @MainActor
final class DownloadJob: Identifiable {
    enum State: Equatable {
        case waiting, running, done, skipped
        case failed(String)
        case stopped
    }

    let id = UUID()
    let file: ShareFile
    let destination: URL
    let share: TeraboxShare
    var state: State = .waiting
    var received: Int64 = 0
    var bytesPerSecond: Double = 0
    @ObservationIgnored var task: Task<Void, Never>?

    init(file: ShareFile, destination: URL, share: TeraboxShare) {
        self.file = file
        self.destination = destination
        self.share = share
    }

    var isFinished: Bool { state == .done || state == .skipped }
    var isActive: Bool { state == .waiting || state == .running }

    var fraction: Double {
        file.size > 0 ? min(1, Double(received) / Double(file.size)) : (isFinished ? 1 : 0)
    }
}

/// Antrean unduhan. File diunduh satu per satu (seperti CLI) supaya akun tidak
/// memicu pembatasan 400141; dlink diminta tepat sebelum tiap file diunduh.
@Observable @MainActor
final class DownloadManager {
    private(set) var jobs: [DownloadJob] = []
    @ObservationIgnored private var worker: Task<Void, Never>?

    static var defaultFolder: URL {
        FileManager.default.homeDirectoryForCurrentUser.appending(path: "Downloads/Terabox")
    }

    /// Folder sementara yang tidak disimpan ke pengaturan (dipakai uji otomatis).
    @ObservationIgnored var overrideFolder: URL?

    var folder: URL {
        get {
            access(keyPath: \.folder)
            if let overrideFolder { return overrideFolder }
            return UserDefaults.standard.string(forKey: "downloadFolder").map { URL(filePath: $0) } ?? Self.defaultFolder
        }
        set {
            withMutation(keyPath: \.folder) {
                UserDefaults.standard.set(newValue.path(percentEncoded: false), forKey: "downloadFolder")
            }
        }
    }

    var activeCount: Int { jobs.count { $0.isActive } }

    /// Tambahkan file ke antrean. Struktur folder dari Terabox dipertahankan.
    func enqueue(_ files: [ShareFile], from share: TeraboxShare, to folder: URL) -> Int {
        var added = 0
        for f in files {
            let parts = f.rel.split(separator: "/", omittingEmptySubsequences: false).map { PyCompat.safeName(String($0)) }
            var dest = folder
            for p in parts.dropLast() { dest.append(path: p, directoryHint: .isDirectory) }
            dest.append(path: parts.last!, directoryHint: .notDirectory)
            if jobs.contains(where: { $0.destination == dest && $0.isActive }) { continue }
            jobs.append(DownloadJob(file: f, destination: dest, share: share))
            added += 1
        }
        startWorker()
        return added
    }

    func stop(_ job: DownloadJob) {
        if job.state == .waiting { job.state = .stopped }
        job.task?.cancel()
    }

    func retry(_ job: DownloadJob) {
        guard !job.isActive else { return }
        job.state = .waiting
        startWorker()
    }

    func remove(_ job: DownloadJob) {
        stop(job)
        jobs.removeAll { $0 === job }
    }

    func clearFinished() {
        jobs.removeAll { $0.isFinished }
    }

    /// Menunggu sampai antrean kosong (dipakai oleh uji otomatis).
    func waitUntilIdle() async {
        while let w = worker { await w.value }
    }

    private func startWorker() {
        guard worker == nil else { return }
        worker = Task { [weak self] in
            while let self, let job = self.jobs.first(where: { $0.state == .waiting }) {
                await self.run(job)
            }
            self?.worker = nil
        }
    }

    private func run(_ job: DownloadJob) async {
        job.state = .running
        let task = Task { await Self.perform(job) }
        job.task = task
        await task.value
        job.task = nil
        if case .failed(let msg) = job.state, msg == TeraboxError.needLogin.localizedDescription {
            // File lain dari share yang sama pasti ditolak juga; jangan buang request.
            for other in jobs where other.state == .waiting && other.share === job.share {
                other.state = .failed(msg)
            }
        }
    }

    private static func perform(_ job: DownloadJob) async {
        let file = job.file
        let dest = job.destination
        let share = job.share
        do {
            let result = try await download(file: file, to: dest, share: share) { got, speed in
                DispatchQueue.main.async {
                    job.received = got
                    job.bytesPerSecond = speed
                }
            }
            job.received = file.size
            job.state = result
        } catch is CancellationError {
            job.state = .stopped
        } catch let e as URLError where e.code == .cancelled {
            job.state = .stopped
        } catch {
            job.state = .failed(error.localizedDescription)
        }
    }

    /// Seperti TeraboxShare.download() di CLI: resume dari .part, skip kalau sudah lengkap.
    /// File di atas 4 MB diunduh paralel (lihat ParallelDownload).
    @concurrent
    private static func download(file: ShareFile, to dest: URL, share: TeraboxShare,
                                 progress: @escaping @Sendable (Int64, Double) -> Void) async throws -> DownloadJob.State {
        let fm = FileManager.default
        if fileSize(dest) == file.size {
            return .skipped
        }
        try fm.createDirectory(at: dest.deletingLastPathComponent(), withIntermediateDirectories: true)
        let part = dest.appendingPathExtension("part")
        if file.size > ParallelDownload.chunkSize {
            do {
                try await ParallelDownload.run(file: file, part: part, share: share, progress: progress)
                if fm.fileExists(atPath: dest.path(percentEncoded: false)) { try fm.removeItem(at: dest) }
                try fm.moveItem(at: part, to: dest)
                return .done
            } catch is ParallelDownload.RangeUnsupported {
                // Lanjut dengan satu koneksi dari awal.
                try? fm.removeItem(at: part)
                try? fm.removeItem(at: part.appendingPathExtension("json"))
            }
        }
        var done = fileSize(part) ?? 0
        if done > file.size {
            try? fm.removeItem(at: part)
            done = 0
        }

        guard let dlink = try await share.dlinks([file.fsId])[file.fsId] else {
            throw TeraboxError.message("Terabox tidak memberi link unduhan untuk file ini.")
        }
        let (resp, body) = try await share.fetch(dlink, range: done > 0 ? "bytes=\(done)-" : nil)
        if resp.statusCode >= 400 { throw await httpFailure(resp, body) }
        if done > 0 && resp.statusCode != 206 { done = 0 }  // server tidak mendukung resume

        if done == 0 || !fm.fileExists(atPath: part.path(percentEncoded: false)) {
            fm.createFile(atPath: part.path(percentEncoded: false), contents: nil)
        }
        let handle = try FileHandle(forWritingTo: part)
        defer { try? handle.close() }
        if done > 0 { try handle.seekToEnd() } else { try handle.truncate(atOffset: 0) }

        let start = Date.now
        var got: Int64 = 0
        var lastReport = Date.distantPast
        try await body.forEach { chunk in
            try handle.write(contentsOf: chunk)
            got += Int64(chunk.count)
            let now = Date.now
            if now.timeIntervalSince(lastReport) > 0.25 {
                lastReport = now
                progress(done + got, Double(got) / max(now.timeIntervalSince(start), 0.001))
            }
        }
        try handle.close()

        let written = fileSize(part) ?? 0
        if file.size > 0 && written != file.size {
            throw TeraboxError.message("Ukuran tidak cocok (\(written) dari \(file.size) byte). Klik Coba Lagi untuk melanjutkan.")
        }
        if fm.fileExists(atPath: dest.path(percentEncoded: false)) { try fm.removeItem(at: dest) }
        try fm.moveItem(at: part, to: dest)
        return .done
    }
}

func fileSize(_ url: URL) -> Int64? {
    (try? FileManager.default.attributesOfItem(atPath: url.path(percentEncoded: false))[.size] as? NSNumber)?.int64Value
}
