import Foundation
import Synchronization

/// Unduhan paralel. Terabox membatasi kecepatan per koneksi untuk akun gratis (file besar
/// bisa cuma ~30 KB/s), jadi file dibagi potongan 4 MB yang diunduh lewat beberapa koneksi
/// sekaligus, masing-masing ditulis langsung ke posisinya di file .part. Potongan yang sudah
/// selesai dicatat di <file>.part.json, jadi unduhan bisa dilanjutkan setelah dihentikan
/// atau aplikasinya ditutup.
enum ParallelDownload {
    static let chunkSize: Int64 = 4 << 20
    static let connections = 8

    /// Server menjawab 200 (bukan 206) untuk request Range: pakai unduhan satu koneksi.
    struct RangeUnsupported: Error {}

    static func run(file: ShareFile, part: URL, share: TeraboxShare,
                    progress: @escaping @Sendable (Int64, Double) -> Void) async throws {
        let size = file.size
        let count = Int((size + chunkSize - 1) / chunkSize)
        func length(_ i: Int) -> Int64 { min(Int64(i + 1) * chunkSize, size) - Int64(i) * chunkSize }

        let stateURL = part.appendingPathExtension("json")
        var done = Set<Int>()
        if let data = try? Data(contentsOf: stateURL),
           let saved = try? JSONDecoder().decode(SavedChunks.self, from: data),
           saved.size == size, saved.chunk == chunkSize, fileSize(part) == size {
            done = Set(saved.done)
        } else if let prefix = fileSize(part), prefix > 0, prefix < size {
            // .part dari unduhan satu koneksi versi lama: bagian awalnya sudah lengkap.
            done = Set((0..<count).filter { Int64($0) * chunkSize + length($0) <= prefix })
        }

        let fd = open(part.path(percentEncoded: false), O_WRONLY | O_CREAT, 0o644)
        guard fd >= 0 else { throw TeraboxError.message("Tidak bisa menulis \(part.lastPathComponent) (errno \(errno)).") }
        defer { close(fd) }
        guard ftruncate(fd, off_t(size)) == 0 else {
            throw TeraboxError.message("Tidak bisa menyiapkan \(part.lastPathComponent) (errno \(errno)). Ruang disk cukup?")
        }

        let pending = (0..<count).filter { !done.contains($0) }
        let queue = ChunkQueue(pending: pending, done: done, saveTo: stateURL, size: size, chunk: chunkSize)
        let link = LinkBox(share: share, fsId: file.fsId)
        let received = Counter(done.reduce(0) { $0 + length($1) })
        let workers = min(connections, pending.count)
        StreamServer.note("unduh paralel: \(count) potongan, \(pending.count) tersisa, \(workers) koneksi")

        let start = Date.now
        let startBytes = received.value
        let reporter = Task {
            var lastBytes = received.value
            var lastTime = Date.now
            var speed = 0.0
            while !Task.isCancelled {
                try? await Task.sleep(for: .milliseconds(500))
                let now = Date.now, bytes = received.value
                let instant = Double(bytes - lastBytes) / max(now.timeIntervalSince(lastTime), 0.001)
                speed = speed == 0 ? instant : speed * 0.7 + instant * 0.3
                progress(bytes, speed)
                (lastBytes, lastTime) = (bytes, now)
            }
        }
        defer { reporter.cancel() }

        try await withThrowingTaskGroup(of: Void.self) { group in
            for _ in 0..<workers {
                group.addTask {
                    while let i = await queue.next() {
                        let from = Int64(i) * chunkSize
                        try await fetchRange(from: from, to: from + length(i) - 1, fd: fd,
                                             link: link, share: share, received: received)
                        await queue.finish(i)
                    }
                }
            }
            try await group.waitForAll()
        }
        guard await queue.isComplete else { throw TeraboxError.message("Unduhan belum lengkap. Klik Coba Lagi untuk melanjutkan.") }
        fsync(fd)
        try? FileManager.default.removeItem(at: stateURL)
        let seconds = Date.now.timeIntervalSince(start)
        StreamServer.note("unduh paralel selesai: \((received.value - startBytes) / 1024) KB dalam \(Int(seconds)) detik")
    }

    /// Satu potongan. Kalau koneksi putus di tengah, sisanya diminta lagi dari posisi terakhir.
    private static func fetchRange(from: Int64, to end: Int64, fd: Int32, link: LinkBox,
                                   share: TeraboxShare, received: Counter) async throws {
        var pos = from
        var failures = 0
        while pos <= end {
            try Task.checkCancellation()
            let url = try await link.current()
            let before = pos
            do {
                let (resp, body) = try await share.fetch(url, range: "bytes=\(pos)-\(end)")
                if [403, 404, 410].contains(resp.statusCode) && failures < 3 {
                    body.cancel()
                    failures += 1
                    try await link.refresh(replacing: url)  // dlink kedaluwarsa
                    continue
                }
                if resp.statusCode >= 400 { throw await httpFailure(resp, body) }
                if resp.statusCode != 206 {
                    body.cancel()
                    throw RangeUnsupported()
                }
                try await body.forEach { data in
                    try write(fd, data, at: pos)
                    pos += Int64(data.count)
                    received.add(Int64(data.count))
                }
                if pos <= end && pos == before {
                    failures += 1
                    if failures > 5 { throw TeraboxError.message("Server Terabox berhenti mengirim data.") }
                }
            } catch let error as URLError where error.code != .cancelled {
                failures += 1
                if failures > 5 { throw error }
                try await Task.sleep(for: .seconds(Double(failures)))
            }
        }
    }

    private static func write(_ fd: Int32, _ data: Data, at offset: Int64) throws {
        guard !data.isEmpty else { return }
        try data.withUnsafeBytes { raw in
            var written = 0
            while written < raw.count {
                let n = pwrite(fd, raw.baseAddress! + written, raw.count - written, off_t(offset) + off_t(written))
                if n < 0 {
                    if errno == EINTR { continue }
                    throw TeraboxError.message("Gagal menulis ke disk (errno \(errno)).")
                }
                written += n
            }
        }
    }
}

private struct SavedChunks: Codable {
    var size: Int64
    var chunk: Int64
    var done: [Int]
}

/// Antrean potongan yang dibagi ke semua koneksi; mencatat yang selesai ke disk.
private actor ChunkQueue {
    private var pending: [Int]
    private var done: Set<Int>
    private var inFlight = 0
    private let saveTo: URL
    private let size: Int64
    private let chunk: Int64

    init(pending: [Int], done: Set<Int>, saveTo: URL, size: Int64, chunk: Int64) {
        self.pending = pending
        self.done = done
        self.saveTo = saveTo
        self.size = size
        self.chunk = chunk
    }

    func next() -> Int? {
        guard !pending.isEmpty else { return nil }
        inFlight += 1
        return pending.removeFirst()
    }

    func finish(_ i: Int) {
        inFlight -= 1
        done.insert(i)
        let saved = SavedChunks(size: size, chunk: chunk, done: done.sorted())
        try? JSONEncoder().encode(saved).write(to: saveTo, options: .atomic)
    }

    var isComplete: Bool { pending.isEmpty && inFlight == 0 }
}

/// dlink bersama untuk semua koneksi. Diminta ulang paling banyak sekali pada satu waktu,
/// karena banyak request sharedownload beruntun memicu 400141.
private actor LinkBox {
    private let share: TeraboxShare
    private let fsId: Int64
    private var url: URL?
    private var fetchedAt = Date.distantPast
    private var loading: Task<URL, Error>?

    init(share: TeraboxShare, fsId: Int64) {
        self.share = share
        self.fsId = fsId
    }

    func current() async throws -> URL {
        if let url, Date.now.timeIntervalSince(fetchedAt) < 45 * 60 { return url }
        if let loading { return try await loading.value }
        let task = Task { [share, fsId] in
            guard let link = try await share.dlinks([fsId])[fsId] else {
                throw TeraboxError.message("Terabox tidak memberi link unduhan untuk file ini.")
            }
            return link
        }
        loading = task
        defer { loading = nil }
        let link = try await task.value
        url = link
        fetchedAt = .now
        return link
    }

    func refresh(replacing old: URL) async throws {
        if url == old { url = nil }
        _ = try await current()
    }
}

private final class Counter: Sendable {
    private let storage: Atomic<Int64>
    init(_ value: Int64) { storage = Atomic(value) }
    var value: Int64 { storage.load(ordering: .relaxed) }
    func add(_ n: Int64) { storage.add(n, ordering: .relaxed) }
}
