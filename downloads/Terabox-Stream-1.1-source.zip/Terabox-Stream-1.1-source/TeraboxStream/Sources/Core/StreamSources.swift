import AVFoundation
import Foundation

// Sumber streaming, sama seperti StreamSource / HlsSource / pick_source() di CLI.
//  - "File asli": meneruskan request (termasuk Range untuk seek) ke dlink,
//    dlink diperbarui otomatis kalau kedaluwarsa.
//  - "HLS": /share/streaming seperti player web Terabox. Playlist butuh cookie,
//    segmen .ts diambil tanpa cookie.

let videoHLSTypes = ["M3U8_AUTO_720", "M3U8_AUTO_480", "M3U8_AUTO_360"]
let audioHLSTypes = ["M3U8_MP3_128"]
private let segmentHosts = ["terabox.app", "terabox.com", "1024tera.com", "teraboxcdn.com", "1024terabox.com"]

actor DirectSource {
    let share: TeraboxShare
    let fsId: Int64
    private var dlink: URL?
    private var fetchedAt = Date.distantPast
    private static let ttl: TimeInterval = 45 * 60  // dlink berlaku sekitar 1 jam

    init(share: TeraboxShare, fsId: Int64) {
        self.share = share
        self.fsId = fsId
    }

    private func link(force: Bool) async throws -> URL {
        if force || dlink == nil || Date.now.timeIntervalSince(fetchedAt) > Self.ttl {
            guard let url = try await share.dlinks([fsId])[fsId] else {
                throw TeraboxError.message("Terabox tidak memberi link untuk file ini.")
            }
            dlink = url
            fetchedAt = .now
        }
        return dlink!
    }

    enum Opened: Sendable {
        case ok(HTTPURLResponse, ResponseBody)
        case rangeNotSatisfiable
    }

    func open(range: String?) async throws -> Opened {
        for attempt in 0..<2 {
            let (resp, body) = try await share.fetch(try await link(force: attempt > 0), range: range)
            if resp.statusCode < 400 { return .ok(resp, body) }
            if resp.statusCode == 416 {
                body.cancel()
                return .rangeNotSatisfiable
            }
            if attempt == 0 && [403, 404, 410].contains(resp.statusCode) {
                body.cancel()
                continue  // mungkin dlink kedaluwarsa, minta yang baru
            }
            throw await httpFailure(resp, body)
        }
        throw TeraboxError.message("File tidak bisa dibuka.")
    }
}

actor HLSSource {
    let share: TeraboxShare
    let fsId: Int64
    let types: [String]
    private(set) var type: String?
    /// Playlist lengkap (ada #EXT-X-ENDLIST). Video yang baru pertama kali diputar sedang
    /// di-transcode Terabox, dan playlist-nya baru berisi sebagian video tanpa ENDLIST.
    private(set) var isComplete = true
    /// Jumlah semua #EXTINF, dalam detik.
    private(set) var duration: Double = 0
    private var text: String?
    private var fetchedAt = Date.distantPast
    private static let ttl: TimeInterval = 20 * 60
    /// Playlist yang belum lengkap diambil ulang paling cepat tiap 10 detik, supaya
    /// AVPlayer (yang memuat ulang playlist seperti siaran langsung) melihatnya bertambah.
    private static let growingTTL: TimeInterval = 10
    private static let segmentClient = HTTPClient(userCookie: nil, keepsSessionCookies: false)

    init(share: TeraboxShare, fsId: Int64, types: [String]) {
        self.share = share
        self.fsId = fsId
        self.types = types
    }

    /// Playlist dengan alamat segmen diganti jadi "seg?u=..." (relatif ke URL playlist lokal).
    func playlist() async throws -> String {
        if let text, Date.now.timeIntervalSince(fetchedAt) < (isComplete ? Self.ttl : Self.growingTTL) { return text }
        var (type, raw) = try await share.m3u8(fsId: fsId, types: types)
        if ProcessInfo.processInfo.environment["SELFTEST_CUT_HLS"] == "1" { raw = Self.cutForTest(raw) }
        let base = await share.host.appending(path: "/")
        let rewritten = raw.split(separator: "\n", omittingEmptySubsequences: false).map { line -> String in
            let item = line.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !item.isEmpty, !item.hasPrefix("#"),
                  let url = URL(string: item, relativeTo: base)?.absoluteURL else { return String(line) }
            return "seg?u=" + PyCompat.quoteAll(url.absoluteString)
        }.joined(separator: "\n")
        self.type = type
        isComplete = raw.contains("#EXT-X-ENDLIST")
        duration = raw.split(separator: "\n").compactMap { line -> Double? in
            guard line.hasPrefix("#EXTINF:") else { return nil }
            return Double(line.dropFirst(8).split(separator: ",").first ?? "")
        }.reduce(0, +)
        self.text = rewritten + "\n"
        fetchedAt = .now
        return rewritten + "\n"
    }

    /// Segmen diambil tanpa cookie, tapi wajib membawa Referer halaman Terabox:
    /// tanpa itu CDN video menjawab 403 "hotlinking forbidden" (errno 31426).
    func openSegment(_ url: URL) async throws -> (HTTPURLResponse, ResponseBody) {
        let host = url.host()?.lowercased() ?? ""
        guard segmentHosts.contains(where: { host == $0 || host.hasSuffix("." + $0) }) else {
            throw TeraboxError.message("Host segmen tidak dikenal: \(host)")
        }
        var request = URLRequest(url: url, timeoutInterval: 60)
        request.setValue(await share.host.absoluteString + "/", forHTTPHeaderField: "Referer")
        return try await Self.segmentClient.stream(for: request)
    }

    /// Uji otomatis: potong playlist jadi 3 segmen pertama, seperti yang kadang dikirim Terabox.
    private static func cutForTest(_ raw: String) -> String {
        var out: [Substring] = []
        var segments = 0
        for line in raw.split(separator: "\n") {
            if !line.hasPrefix("#") { segments += 1 }
            if segments > 3 { break }
            out.append(line)
        }
        return out.joined(separator: "\n") + "\n#EXT-X-ENDLIST\n"
    }

    static func label(for type: String?) -> String {
        guard let type else { return "HLS" }
        if type.hasPrefix("M3U8_AUTO_"), let q = type.split(separator: "_").last, Int(q) != nil {
            return "HLS \(q)p, hasil transcode Terabox"
        }
        if type == "M3U8_MP3_128" { return "HLS MP3 128 kbps" }
        return "HLS \(type)"
    }
}

enum PlaybackSource: Sendable {
    case direct(DirectSource)
    case hls(HLSSource)
}

enum VideoQuality: Int, CaseIterable, Identifiable, Sendable {
    case automatic = 0, p1080 = 1080, p720 = 720, p480 = 480, p360 = 360

    var id: Int { rawValue }
    var title: String { self == .automatic ? "Otomatis" : "\(rawValue)p" }
    /// Kualitas pilihan dicoba dulu, lalu yang lebih rendah, lalu yang lebih tinggi. Tidak semua
    /// video punya semua kualitas, dan file asli (cadangan terakhir) sangat lambat untuk akun
    /// gratis, jadi kualitas lain selalu lebih baik daripada jatuh ke file asli.
    var hlsTypes: [String] {
        guard self != .automatic else { return videoHLSTypes }
        let all = [1080, 720, 480, 360]
        let order = [rawValue] + all.filter { $0 < rawValue } + all.filter { $0 > rawValue && $0 != 1080 }.reversed()
        return order.map { "M3U8_AUTO_\($0)" }
    }
}

/// Video lewat HLS (seperti web Terabox), lainnya lewat file asli; saling jadi cadangan.
func pickSource(share: TeraboxShare, file: ShareFile, quality: VideoQuality,
                forceHLS: Bool = false, videoTypes: [String]? = nil,
                quick: Bool = false) async throws -> PlaybackSource {
    let kind = FileKinds.kind(name: file.name, category: file.category)

    func tryHLS(_ types: [String]) async throws -> PlaybackSource {
        let src = HLSSource(share: share, fsId: file.fsId, types: types)
        _ = try await src.playlist()
        return .hls(src)
    }

    /// Cek file asli di awal supaya error langsung kelihatan, sekaligus intip 16 byte pertamanya.
    func probeDirect() async throws -> (PlaybackSource, Data) {
        let src = DirectSource(share: share, fsId: file.fsId)
        var head = Data()
        if case .ok(_, let body) = try await src.open(range: "bytes=0-15") {
            head = try await body.collect(limit: 16)
        }
        return (.direct(src), head)
    }

    func tryDirect() async throws -> PlaybackSource {
        try await probeDirect().0
    }

    /// Audio yang ternyata MP4 terfragmentasi (mis. hasil unduhan YouTube "DASH" yang diberi
    /// nama .mp3) tidak bisa di-seek oleh AVPlayer. Versi HLS MP3 dari Terabox bisa, jadi
    /// untuk file seperti itu HLS didahulukan.
    func tryAudio() async throws -> PlaybackSource {
        let (direct, head) = try await probeDirect()
        StreamServer.note("probe \(head.count) byte, MP4 terfragmentasi: \(isFragmentedMP4(head))")
        guard isFragmentedMP4(head) else { return direct }
        do {
            return try await tryHLS(audioHLSTypes)
        } catch {
            StreamServer.note("HLS gagal, kembali ke file asli: \(error.localizedDescription)")
            return direct
        }
    }

    /// Video: HLS (seperti web Terabox, cepat dari CDN-nya). File asli untuk akun gratis
    /// sangat lambat, jadi hanya disentuh kalau HLS gagal atau playlist-nya mencurigakan.
    /// Terabox kadang memberi playlist yang cuma 20-35 detik pertama. Itu tertangkap dari
    /// bitrate tersirat (ukuran file / durasi playlist) di atas 40 Mbps, padahal video Terabox
    /// biasanya 2-15 Mbps, atau dari playlist tanpa ENDLIST. Hanya kasus itu yang dicek ke
    /// durasi file asli; kalau memang lebih pendek, putar file aslinya. `quick` (pratinjau)
    /// melewati pengecekan itu sama sekali.
    func tryVideo() async throws -> PlaybackSource {
        let hls = HLSSource(share: share, fsId: file.fsId, types: videoTypes ?? quality.hlsTypes)
        do {
            _ = try await hls.playlist()
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            StreamServer.note("HLS gagal: \(error.localizedDescription)")
            return try await tryDirect()
        }
        let streamed = await hls.duration
        let complete = await hls.isComplete
        let impliedMbps = Double(file.size) * 8 / max(streamed, 1) / 1_000_000
        StreamServer.note("video lewat \(await hls.type ?? "-"): durasi HLS \(streamed) detik (lengkap: \(complete)), bitrate tersirat \(Int(impliedMbps)) Mbps")
        if quick || (complete && impliedMbps <= 40) { return .hls(hls) }
        guard let (direct, _) = try? await probeDirect() else { return .hls(hls) }
        guard let real = await realDuration(direct) else { return .hls(hls) }
        let tolerance = max(3, real * 0.03)
        StreamServer.note("playlist mencurigakan; file asli \(real) detik")
        if complete && streamed >= real - tolerance { return .hls(hls) }
        return direct
    }

    func realDuration(_ source: PlaybackSource) async -> Double? {
        guard let (token, url) = try? await StreamServer.shared.register(source, file: file) else { return nil }
        defer { Task { await StreamServer.shared.unregister(token) } }
        guard let seconds = try? await AVURLAsset(url: url).load(.duration).seconds,
              seconds.isFinite, seconds > 0 else { return nil }
        return seconds
    }

    var errors: [Error] = []
    let attempts: [() async throws -> PlaybackSource]
    switch kind {
    case .video: attempts = [tryVideo, tryDirect]
    case .audio where forceHLS: attempts = [{ try await tryHLS(audioHLSTypes) }]
    case .audio: attempts = [tryAudio, { try await tryHLS(audioHLSTypes) }]
    default: attempts = [tryDirect]
    }
    for attempt in attempts {
        do {
            return try await attempt()
        } catch is CancellationError {
            throw CancellationError()
        } catch {
            errors.append(error)
        }
    }
    if errors.contains(where: { ($0 as? TeraboxError).map { if case .needLogin = $0 { true } else { false } } ?? false }) {
        throw TeraboxError.needLogin
    }
    throw TeraboxError.message(errors.map(\.localizedDescription).joined(separator: "\n"))
}

/// "ftypdash" atau "ftypiso5"/"ftypiso6" di awal file = MP4 terfragmentasi tanpa indeks seek.
func isFragmentedMP4(_ head: Data) -> Bool {
    guard head.count >= 12 else { return false }
    let bytes = [UInt8](head)
    guard String(decoding: bytes[4..<8], as: UTF8.self) == "ftyp" else { return false }
    let brand = String(decoding: bytes[8..<12], as: UTF8.self)
    return ["dash", "iso5", "iso6", "msdh"].contains(brand)
}
