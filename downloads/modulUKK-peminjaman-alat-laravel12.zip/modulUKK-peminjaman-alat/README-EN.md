# Equipment Lending App: Laravel 12 CRUD tutorial (Indonesian)

A complete, beginner-level tutorial (in Indonesian) for building an equipment lending app with
Laravel 12, MySQL 8 and Bootstrap 5, written for the Indonesian vocational exam UKK RPL 2025/2026, Package 1.

- `modul/`: 14 step-by-step chapters (BAB 00-13).
- `peminjaman-alat/`: the finished, tested Laravel project. Run `composer install`, copy `.env.example`
  to `.env`, set the MySQL settings, then `php artisan key:generate`, `php artisan migrate --seed` and `php artisan serve`.
- `dokumentasi/`: requirements, ERD, flowcharts, function docs, debugging notes, 15 test cases with screenshots, evaluation.
- `peminjaman-alat/database/db_peminjaman_alat.sql`: MySQL dump including the function, stored procedure and triggers.

Test logins: admin/admin123, petugas/petugas123, peminjam/peminjam123.

Online version: https://walendra1804-spec.github.io/2026/11/16/cara-membuat-projek-laravel-12-crud-peminjaman-alat/

License: MIT.
