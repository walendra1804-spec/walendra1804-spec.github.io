# UKK RPL 2025/2026: Aplikasi Peminjaman Alat (Laravel 12 + MySQL + Bootstrap 5)

Versi online + penjelasan lengkap: https://walendra1804-spec.github.io/2026/11/16/cara-membuat-projek-laravel-12-crud-peminjaman-alat/

| Folder | Isi |
|---|---|
| [`modul/`](modul/00-PENDAHULUAN.md) | **Mulai dari sini.** Modul langkah demi langkah (BAB 00–13) untuk membuat aplikasinya sendiri |
| [`peminjaman-alat/`](peminjaman-alat/) | Proyek Laravel yang sudah jadi (kunci jawaban) |
| [`dokumentasi/`](dokumentasi/) | ERD, flowchart, dokumentasi fungsi, debugging, pengujian, laporan evaluasi |

Database `.sql`: [`peminjaman-alat/database/db_peminjaman_alat.sql`](peminjaman-alat/database/db_peminjaman_alat.sql)

## Cara menjalankan proyek

```bash
cd peminjaman-alat
composer install
cp .env.example .env
php artisan key:generate
```

Ubah `.env`: `DB_CONNECTION=mysql`, `DB_DATABASE=db_peminjaman_alat`, `DB_USERNAME=root`, `DB_PASSWORD=` (sesuaikan). Buat database `db_peminjaman_alat` di MySQL, lalu:

```bash
php artisan migrate --seed
php artisan serve
```

Buka http://localhost:8000. Akun: `admin`/`admin123`, `petugas`/`petugas123`, `peminjam`/`peminjam123`.

Folder `vendor/` sengaja tidak disertakan (sekitar 86 MB). `composer install` membuatnya lagi.

Lisensi: MIT (lihat `LICENSE`).
