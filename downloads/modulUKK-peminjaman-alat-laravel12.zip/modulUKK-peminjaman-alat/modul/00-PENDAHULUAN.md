# BAB 00 — Pendahuluan

Modul ini memandu kamu membuat **Aplikasi Peminjaman Alat** (soal UKK RPL 2025/2026 Paket 1) dari nol sampai selesai, memakai **Laravel + MySQL + Bootstrap 5**.

Ketik ulang kodenya sendiri (jangan copy-paste terus), supaya waktu UKK tanganmu sudah hafal polanya.

---

## 1. Apa yang diminta soal?

Aplikasi dengan **3 level pengguna**:

| Fitur | Admin | Petugas | Peminjam |
|---|:-:|:-:|:-:|
| Login / Logout | ✔ | ✔ | ✔ |
| CRUD user, alat, kategori | ✔ | | |
| CRUD data peminjaman & pengembalian | ✔ | | |
| Log aktivitas | ✔ | | |
| Menyetujui peminjaman | | ✔ | |
| Memantau pengembalian | | ✔ | |
| Mencetak laporan | | ✔ | |
| Melihat daftar alat | | | ✔ |
| Mengajukan peminjaman | | | ✔ |
| Mengembalikan alat | | | ✔ |

Di database juga wajib ada: **relasi tabel, stored procedure, function, trigger, commit & rollback**.

Yang dikumpulkan:
1. Folder proyek (kode lengkap)
2. File database `.sql`
3. Dokumentasi: ERD, deskripsi program, dokumentasi fungsi, debugging, pengujian + screenshot
4. Laporan evaluasi singkat

---

## 2. Alur aplikasi (gambaran besar)

```
Peminjam                 Petugas                    Database
--------                 -------                    --------
lihat daftar alat
ajukan pinjam  ───────►  status = "menunggu"
                         klik Setujui ───────────►  TRIGGER kurangi_stok  (stok - jumlah)
                         (atau Tolak)               status = "disetujui"
klik Kembalikan ───────────────────────────────►   PROCEDURE kembalikan_alat
                                                     ├─ FUNCTION hitung_denda (Rp 5.000/hari telat)
                                                     ├─ simpan ke tabel pengembalian
                                                     ├─ TRIGGER tambah_stok (stok + jumlah)
                                                     └─ status = "dikembalikan"  → COMMIT
                         lihat Pantau Pengembalian
                         cetak Laporan
```

---

## 3. Struktur folder akhir

```
modulUKK/
├── peminjaman-alat/          ← proyek Laravel (hasil akhir)
├── modul/                    ← modul ini
└── dokumentasi/              ← ERD, flowchart, pengujian, laporan (contoh jawaban)
```

---

## 4. Daftar bab

| Bab | Isi |
|---|---|
| [01](01-ANALISIS-DAN-DESAIN.md) | Analisis kebutuhan, ERD, flowchart |
| [02](02-INSTALASI-PROYEK.md) | Install Laravel, setting database |
| [03](03-MIGRATION-TABEL.md) | Membuat tabel dengan migration |
| [04](04-FUNCTION-PROCEDURE-TRIGGER.md) | Function, stored procedure, trigger, commit/rollback |
| [05](05-MODEL-DAN-SEEDER.md) | Model (relasi) dan data awal |
| [06](06-LOGIN-ROLE-LAYOUT.md) | Login, logout, hak akses per role, layout |
| [07](07-ADMIN-KATEGORI-ALAT.md) | CRUD kategori & alat |
| [08](08-ADMIN-USER.md) | CRUD user |
| [09](09-ADMIN-PEMINJAMAN-PENGEMBALIAN-LOG.md) | CRUD peminjaman, pengembalian, log aktivitas |
| [10](10-PETUGAS.md) | Setujui peminjaman, pantau pengembalian, cetak laporan |
| [11](11-PEMINJAM.md) | Daftar alat, ajukan pinjam, kembalikan alat |
| [12](12-PENGUJIAN-DEBUGGING.md) | Test case, cara debugging |
| [13](13-EXPORT-SQL-DAN-PENGUMPULAN.md) | Export `.sql`, laporan evaluasi, checklist kumpul |

---

## 5. Akun untuk mencoba

| Role | Username | Password |
|---|---|---|
| Admin | `admin` | `admin123` |
| Petugas | `petugas` | `petugas123` |
| Peminjam | `peminjam` | `peminjam123` |

---

## 6. Pola yang akan terus berulang

Hampir semua fitur di Laravel dibuat dengan 4 langkah yang sama. Hafalkan ini:

1. **Route** (`routes/web.php`) → alamat URL mana memanggil fungsi apa
2. **Controller** (`app/Http/Controllers`) → logika: ambil data, validasi, simpan
3. **Model** (`app/Models`) → wakil tabel database
4. **View** (`resources/views`) → tampilan HTML (Blade)

Kalau bingung "kodenya taruh di mana", balik lagi ke 4 langkah ini.

Lanjut ke **[BAB 01 — Analisis dan Desain](01-ANALISIS-DAN-DESAIN.md)**.
