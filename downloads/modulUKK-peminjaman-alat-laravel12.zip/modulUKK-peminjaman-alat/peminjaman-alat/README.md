# Aplikasi Peminjaman Alat

Soal UKK RPL 2025/2026 Paket 1 — Laravel 12 + MySQL 8 + Bootstrap 5.

## Menjalankan

```bash
composer install
cp .env.example .env        # lalu atur DB_* ke MySQL (database: db_peminjaman_alat)
php artisan key:generate
php artisan migrate --seed  # atau import database/db_peminjaman_alat.sql
php artisan serve
```

Buka http://localhost:8000

## Akun

| Role | Username | Password |
|---|---|---|
| Admin | admin | admin123 |
| Petugas | petugas | petugas123 |
| Peminjam | peminjam | peminjam123 |

## Database

- File: `database/db_peminjaman_alat.sql`
- Function `hitung_denda`, procedure `kembalikan_alat`, trigger `kurangi_stok` & `tambah_stok`
  ada di migration `database/migrations/*_create_function_procedure_trigger.php`.
