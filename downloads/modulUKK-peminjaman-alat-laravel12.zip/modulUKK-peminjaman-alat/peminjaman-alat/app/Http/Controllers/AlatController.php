<?php

namespace App\Http\Controllers;

use App\Models\Alat;
use App\Models\Kategori;
use App\Models\LogAktivitas;
use Illuminate\Http\Request;

class AlatController extends Controller
{
    public function index()
    {
        // with('kategori') = ambil data kategori sekaligus (query lebih efisien)
        $alat = Alat::with('kategori')->latest()->paginate(10);
        return view('alat.index', compact('alat'));
    }

    public function create()
    {
        $kategori = Kategori::all();
        return view('alat.create', compact('kategori'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'kategori_id' => 'required',
            'nama_alat' => 'required',
            'stok' => 'required|integer|min:0',
            'keterangan' => 'nullable',
        ]);

        Alat::create($data);
        LogAktivitas::catat('Menambah alat ' . $data['nama_alat']);

        return redirect()->route('alat.index')->with('success', 'Alat berhasil ditambah');
    }

    public function edit(Alat $alat)
    {
        $kategori = Kategori::all();
        return view('alat.edit', compact('alat', 'kategori'));
    }

    public function update(Request $request, Alat $alat)
    {
        $data = $request->validate([
            'kategori_id' => 'required',
            'nama_alat' => 'required',
            'stok' => 'required|integer|min:0',
            'keterangan' => 'nullable',
        ]);

        $alat->update($data);
        LogAktivitas::catat('Mengubah alat ' . $alat->nama_alat);

        return redirect()->route('alat.index')->with('success', 'Alat berhasil diubah');
    }

    public function destroy(Alat $alat)
    {
        $alat->delete();
        LogAktivitas::catat('Menghapus alat ' . $alat->nama_alat);

        return redirect()->route('alat.index')->with('success', 'Alat berhasil dihapus');
    }
}
