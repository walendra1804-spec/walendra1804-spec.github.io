<?php

namespace App\Http\Controllers;

use App\Models\LogAktivitas;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    // menampilkan halaman login
    public function index()
    {
        return view('auth.login');
    }

    // memproses login
    public function login(Request $request)
    {
        $data = $request->validate([
            'username' => 'required',
            'password' => 'required',
        ]);

        if (Auth::attempt($data)) {
            $request->session()->regenerate();
            LogAktivitas::catat('Login ke sistem');
            return redirect('/dashboard');
        }

        return back()->withInput()->with('error', 'Username atau password salah!');
    }

    // memproses logout
    public function logout(Request $request)
    {
        LogAktivitas::catat('Logout dari sistem');
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect('/login');
    }
}
