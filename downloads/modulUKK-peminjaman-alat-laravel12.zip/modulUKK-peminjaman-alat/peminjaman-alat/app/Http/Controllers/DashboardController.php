<?php

namespace App\Http\Controllers;

use App\Models\Alat;
use App\Models\Peminjaman;
use App\Models\User;

class DashboardController extends Controller
{
    public function index()
    {
        $jumlahAlat = Alat::count();
        $jumlahUser = User::count();
        $menunggu = Peminjaman::where('status', 'menunggu')->count();
        $dipinjam = Peminjaman::where('status', 'disetujui')->count();

        return view('dashboard', compact('jumlahAlat', 'jumlahUser', 'menunggu', 'dipinjam'));
    }
}
