<?php

namespace App\Http\Controllers;

use App\Models\Kategori;
use App\Models\LogAktivitas;
use Illuminate\Http\Request;

class KategoriController extends Controller
{
    public function index()
    {
        $kategori = Kategori::latest()->paginate(10);
        return view('kategori.index', compact('kategori'));
    }

    public function create()
    {
        return view('kategori.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'nama_kategori' => 'required',
        ]);

        Kategori::create($data);
        LogAktivitas::catat('Menambah kategori ' . $data['nama_kategori']);

        return redirect()->route('kategori.index')->with('success', 'Kategori berhasil ditambah');
    }

    public function edit(Kategori $kategori)
    {
        return view('kategori.edit', compact('kategori'));
    }

    public function update(Request $request, Kategori $kategori)
    {
        $data = $request->validate([
            'nama_kategori' => 'required',
        ]);

        $kategori->update($data);
        LogAktivitas::catat('Mengubah kategori ' . $kategori->nama_kategori);

        return redirect()->route('kategori.index')->with('success', 'Kategori berhasil diubah');
    }

    public function destroy(Kategori $kategori)
    {
        $kategori->delete();
        LogAktivitas::catat('Menghapus kategori ' . $kategori->nama_kategori);

        return redirect()->route('kategori.index')->with('success', 'Kategori berhasil dihapus');
    }
}
