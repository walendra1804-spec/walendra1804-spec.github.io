<?php

namespace App\Http\Controllers;

use App\Models\LogAktivitas;

class LogController extends Controller
{
    public function index()
    {
        $logs = LogAktivitas::with('user')->latest()->paginate(20);
        return view('log.index', compact('logs'));
    }
}
