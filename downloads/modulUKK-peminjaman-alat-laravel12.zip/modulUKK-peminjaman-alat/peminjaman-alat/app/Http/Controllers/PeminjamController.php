<?php

namespace App\Http\Controllers;

use App\Models\Alat;
use App\Models\LogAktivitas;
use App\Models\Peminjaman;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PeminjamController extends Controller
{
    // melihat daftar alat (bisa dicari)
    public function alat(Request $request)
    {
        $cari = $request->cari;

        $alat = Alat::with('kategori')
            ->where('nama_alat', 'like', '%' . $cari . '%')
            ->paginate(10);

        return view('peminjam.alat', compact('alat', 'cari'));
    }

    // form pengajuan peminjaman
    public function formPinjam(Alat $alat)
    {
        return view('peminjam.pinjam', compact('alat'));
    }

    // menyimpan pengajuan peminjaman
    public function pinjam(Request $request, Alat $alat)
    {
        $request->validate([
            'jumlah' => 'required|integer|min:1|max:' . $alat->stok,
            'batas_kembali' => 'required|date|after_or_equal:today',
        ]);

        Peminjaman::create([
            'user_id' => auth()->id(),
            'alat_id' => $alat->id,
            'jumlah' => $request->jumlah,
            'tanggal_pinjam' => date('Y-m-d'),
            'batas_kembali' => $request->batas_kembali,
            'status' => 'menunggu',
        ]);
        LogAktivitas::catat('Mengajukan peminjaman ' . $alat->nama_alat);

        return redirect()->route('peminjam.riwayat')->with('success', 'Pengajuan berhasil, tunggu persetujuan petugas');
    }

    // riwayat peminjaman milik peminjam yang login
    public function riwayat()
    {
        $peminjaman = Peminjaman::with('alat', 'pengembalian')
            ->where('user_id', auth()->id())
            ->latest()
            ->paginate(10);

        return view('peminjam.riwayat', compact('peminjaman'));
    }

    // mengembalikan alat
    public function kembalikan(Peminjaman $peminjaman)
    {
        // hanya boleh mengembalikan pinjaman milik sendiri yang sedang dipinjam
        if ($peminjaman->user_id != auth()->id() || $peminjaman->status != 'disetujui') {
            return back()->with('error', 'Peminjaman ini tidak bisa dikembalikan');
        }

        // panggil STORED PROCEDURE: simpan pengembalian + hitung denda + ubah status
        DB::statement('CALL kembalikan_alat(?, ?)', [$peminjaman->id, date('Y-m-d')]);
        LogAktivitas::catat('Mengembalikan alat ' . $peminjaman->alat->nama_alat);

        $denda = $peminjaman->pengembalian()->first()->denda;

        return back()->with('success', 'Alat berhasil dikembalikan. Denda: Rp ' . number_format($denda, 0, ',', '.'));
    }
}
