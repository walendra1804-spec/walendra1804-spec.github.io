<?php

namespace App\Http\Controllers;

use App\Models\Alat;
use App\Models\LogAktivitas;
use App\Models\Peminjaman;
use App\Models\User;
use Illuminate\Http\Request;

class PeminjamanController extends Controller
{
    public function index()
    {
        $peminjaman = Peminjaman::with('user', 'alat')->latest()->paginate(10);
        return view('peminjaman.index', compact('peminjaman'));
    }

    public function create()
    {
        $users = User::where('role', 'peminjam')->get();
        $alat = Alat::all();
        return view('peminjaman.create', compact('users', 'alat'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'user_id' => 'required',
            'alat_id' => 'required',
            'jumlah' => 'required|integer|min:1',
            'tanggal_pinjam' => 'required|date',
            'batas_kembali' => 'required|date|after_or_equal:tanggal_pinjam',
        ]);

        Peminjaman::create($data);
        LogAktivitas::catat('Menambah data peminjaman');

        return redirect()->route('peminjaman.index')->with('success', 'Peminjaman berhasil ditambah');
    }

    public function edit(Peminjaman $peminjaman)
    {
        $users = User::where('role', 'peminjam')->get();
        $alat = Alat::all();
        return view('peminjaman.edit', compact('peminjaman', 'users', 'alat'));
    }

    public function update(Request $request, Peminjaman $peminjaman)
    {
        $data = $request->validate([
            'user_id' => 'required',
            'alat_id' => 'required',
            'jumlah' => 'required|integer|min:1',
            'tanggal_pinjam' => 'required|date',
            'batas_kembali' => 'required|date|after_or_equal:tanggal_pinjam',
            'status' => 'required',
        ]);

        $peminjaman->update($data);
        LogAktivitas::catat('Mengubah data peminjaman #' . $peminjaman->id);

        return redirect()->route('peminjaman.index')->with('success', 'Peminjaman berhasil diubah');
    }

    public function destroy(Peminjaman $peminjaman)
    {
        $peminjaman->delete();
        LogAktivitas::catat('Menghapus data peminjaman #' . $peminjaman->id);

        return redirect()->route('peminjaman.index')->with('success', 'Peminjaman berhasil dihapus');
    }
}
