<?php

namespace App\Http\Controllers;

use App\Models\LogAktivitas;
use App\Models\Peminjaman;
use App\Models\Pengembalian;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PengembalianController extends Controller
{
    public function index()
    {
        $pengembalian = Pengembalian::with('peminjaman.user', 'peminjaman.alat')->latest()->paginate(10);
        return view('pengembalian.index', compact('pengembalian'));
    }

    public function create()
    {
        // hanya peminjaman yang sedang dipinjam (disetujui) yang bisa dikembalikan
        $peminjaman = Peminjaman::with('user', 'alat')->where('status', 'disetujui')->get();
        return view('pengembalian.create', compact('peminjaman'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'peminjaman_id' => 'required',
            'tanggal_dikembalikan' => 'required|date',
        ]);

        // panggil STORED PROCEDURE kembalikan_alat
        DB::statement('CALL kembalikan_alat(?, ?)', [$data['peminjaman_id'], $data['tanggal_dikembalikan']]);
        LogAktivitas::catat('Menambah data pengembalian peminjaman #' . $data['peminjaman_id']);

        return redirect()->route('pengembalian.index')->with('success', 'Pengembalian berhasil disimpan');
    }

    public function edit(Pengembalian $pengembalian)
    {
        return view('pengembalian.edit', compact('pengembalian'));
    }

    public function update(Request $request, Pengembalian $pengembalian)
    {
        $data = $request->validate([
            'tanggal_dikembalikan' => 'required|date',
        ]);

        // hitung ulang denda pakai FUNCTION hitung_denda
        $batas = $pengembalian->peminjaman->batas_kembali;
        $hasil = DB::selectOne('SELECT hitung_denda(?, ?) AS denda', [$batas, $data['tanggal_dikembalikan']]);

        $pengembalian->update([
            'tanggal_dikembalikan' => $data['tanggal_dikembalikan'],
            'denda' => $hasil->denda,
        ]);
        LogAktivitas::catat('Mengubah data pengembalian #' . $pengembalian->id);

        return redirect()->route('pengembalian.index')->with('success', 'Pengembalian berhasil diubah');
    }

    public function destroy(Pengembalian $pengembalian)
    {
        $pengembalian->delete();
        LogAktivitas::catat('Menghapus data pengembalian #' . $pengembalian->id);

        return redirect()->route('pengembalian.index')->with('success', 'Pengembalian berhasil dihapus');
    }
}
