<?php

namespace App\Http\Controllers;

use App\Models\LogAktivitas;
use App\Models\Peminjaman;
use App\Models\Pengembalian;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PetugasController extends Controller
{
    // daftar pengajuan yang menunggu persetujuan
    public function peminjaman()
    {
        $peminjaman = Peminjaman::with('user', 'alat')->where('status', 'menunggu')->oldest()->paginate(10);
        return view('petugas.peminjaman', compact('peminjaman'));
    }

    // menyetujui peminjaman (pakai COMMIT & ROLLBACK)
    public function setujui(Peminjaman $peminjaman)
    {
        DB::beginTransaction();

        try {
            if ($peminjaman->status != 'menunggu') {
                throw new \Exception('Peminjaman ini sudah diproses');
            }

            if ($peminjaman->alat->stok < $peminjaman->jumlah) {
                throw new \Exception('Stok alat tidak cukup');
            }

            // stok alat otomatis berkurang oleh TRIGGER kurangi_stok
            $peminjaman->update([
                'status' => 'disetujui',
                'petugas_id' => auth()->id(),
            ]);
            LogAktivitas::catat('Menyetujui peminjaman #' . $peminjaman->id);

            DB::commit();
            return back()->with('success', 'Peminjaman disetujui');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'Gagal: ' . $e->getMessage());
        }
    }

    // menolak peminjaman
    public function tolak(Peminjaman $peminjaman)
    {
        $peminjaman->update([
            'status' => 'ditolak',
            'petugas_id' => auth()->id(),
        ]);
        LogAktivitas::catat('Menolak peminjaman #' . $peminjaman->id);

        return back()->with('success', 'Peminjaman ditolak');
    }

    // memantau alat yang sedang dipinjam & yang sudah dikembalikan
    public function pengembalian()
    {
        $dipinjam = Peminjaman::with('user', 'alat')->where('status', 'disetujui')->orderBy('batas_kembali')->get();
        $kembali = Pengembalian::with('peminjaman.user', 'peminjaman.alat')->latest()->paginate(10);

        return view('petugas.pengembalian', compact('dipinjam', 'kembali'));
    }

    // laporan peminjaman berdasarkan tanggal
    public function laporan(Request $request)
    {
        $dari = $request->dari ?? date('Y-m-01');
        $sampai = $request->sampai ?? date('Y-m-d');

        $data = Peminjaman::with('user', 'alat', 'pengembalian')
            ->whereBetween('tanggal_pinjam', [$dari, $sampai])
            ->orderBy('tanggal_pinjam')
            ->get();

        return view('petugas.laporan', compact('data', 'dari', 'sampai'));
    }
}
