<?php

namespace App\Http\Controllers;

use App\Models\LogAktivitas;
use App\Models\User;
use Illuminate\Http\Request;

class UserController extends Controller
{
    public function index()
    {
        $users = User::latest()->paginate(10);
        return view('user.index', compact('users'));
    }

    public function create()
    {
        return view('user.create');
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => 'required',
            'username' => 'required|unique:users',
            'password' => 'required|min:6',
            'role' => 'required',
        ]);

        User::create($data);
        LogAktivitas::catat('Menambah user ' . $data['username']);

        return redirect()->route('user.index')->with('success', 'User berhasil ditambah');
    }

    public function edit(User $user)
    {
        return view('user.edit', compact('user'));
    }

    public function update(Request $request, User $user)
    {
        $data = $request->validate([
            'name' => 'required',
            'username' => 'required|unique:users,username,' . $user->id,
            'password' => 'nullable|min:6',
            'role' => 'required',
        ]);

        // kalau password dikosongkan, password lama tidak diubah
        if ($request->password == null) {
            unset($data['password']);
        }

        $user->update($data);
        LogAktivitas::catat('Mengubah user ' . $user->username);

        return redirect()->route('user.index')->with('success', 'User berhasil diubah');
    }

    public function destroy(User $user)
    {
        // admin tidak boleh menghapus akunnya sendiri
        if ($user->id == auth()->id()) {
            return back()->with('error', 'Tidak bisa menghapus akun sendiri');
        }

        $user->delete();
        LogAktivitas::catat('Menghapus user ' . $user->username);

        return redirect()->route('user.index')->with('success', 'User berhasil dihapus');
    }
}
