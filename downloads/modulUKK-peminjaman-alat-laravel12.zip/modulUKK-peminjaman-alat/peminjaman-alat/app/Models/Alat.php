<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Alat extends Model
{
    protected $table = 'alat';

    protected $fillable = ['kategori_id', 'nama_alat', 'stok', 'keterangan'];

    // satu alat milik satu kategori
    public function kategori()
    {
        return $this->belongsTo(Kategori::class);
    }
}
