<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LogAktivitas extends Model
{
    protected $table = 'log_aktivitas';

    protected $fillable = ['user_id', 'aktivitas'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    // fungsi bantu untuk mencatat aktivitas, contoh: LogAktivitas::catat('Login');
    public static function catat($aktivitas)
    {
        LogAktivitas::create([
            'user_id' => auth()->id(),
            'aktivitas' => $aktivitas,
        ]);
    }
}
