<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Peminjaman extends Model
{
    protected $table = 'peminjaman';

    protected $fillable = ['user_id', 'alat_id', 'jumlah', 'tanggal_pinjam', 'batas_kembali', 'status', 'petugas_id'];

    // peminjam (user yang meminjam)
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function alat()
    {
        return $this->belongsTo(Alat::class);
    }

    // petugas yang menyetujui / menolak
    public function petugas()
    {
        return $this->belongsTo(User::class, 'petugas_id');
    }

    // data pengembalian (kalau sudah dikembalikan)
    public function pengembalian()
    {
        return $this->hasOne(Pengembalian::class);
    }
}
