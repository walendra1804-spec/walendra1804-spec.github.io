<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    public function up(): void
    {
        // hapus dulu kalau sudah ada (supaya migrate:fresh tidak error)
        DB::unprepared('DROP FUNCTION IF EXISTS hitung_denda');
        DB::unprepared('DROP PROCEDURE IF EXISTS kembalikan_alat');

        // 1. FUNCTION: menghitung denda (Rp 5.000 per hari terlambat)
        DB::unprepared("
            CREATE FUNCTION hitung_denda(p_batas DATE, p_kembali DATE)
            RETURNS INT
            DETERMINISTIC
            BEGIN
                DECLARE telat INT;
                SET telat = DATEDIFF(p_kembali, p_batas);
                IF telat > 0 THEN
                    RETURN telat * 5000;
                END IF;
                RETURN 0;
            END
        ");

        // 2. STORED PROCEDURE: proses pengembalian alat (pakai COMMIT & ROLLBACK)
        DB::unprepared("
            CREATE PROCEDURE kembalikan_alat(IN p_peminjaman_id INT, IN p_tanggal DATE)
            BEGIN
                DECLARE v_batas DATE;

                DECLARE EXIT HANDLER FOR SQLEXCEPTION
                BEGIN
                    ROLLBACK;
                    RESIGNAL;
                END;

                START TRANSACTION;

                SELECT batas_kembali INTO v_batas
                FROM peminjaman WHERE id = p_peminjaman_id;

                INSERT INTO pengembalian (peminjaman_id, tanggal_dikembalikan, denda, created_at, updated_at)
                VALUES (p_peminjaman_id, p_tanggal, hitung_denda(v_batas, p_tanggal), NOW(), NOW());

                UPDATE peminjaman SET status = 'dikembalikan', updated_at = NOW()
                WHERE id = p_peminjaman_id;

                COMMIT;
            END
        ");

        // 3. TRIGGER: stok alat berkurang saat peminjaman disetujui
        DB::unprepared("
            CREATE TRIGGER kurangi_stok
            AFTER UPDATE ON peminjaman
            FOR EACH ROW
            BEGIN
                IF OLD.status <> 'disetujui' AND NEW.status = 'disetujui' THEN
                    UPDATE alat SET stok = stok - NEW.jumlah WHERE id = NEW.alat_id;
                END IF;
            END
        ");

        // 4. TRIGGER: stok alat bertambah saat alat dikembalikan
        DB::unprepared("
            CREATE TRIGGER tambah_stok
            AFTER INSERT ON pengembalian
            FOR EACH ROW
            BEGIN
                UPDATE alat
                JOIN peminjaman ON peminjaman.alat_id = alat.id
                SET alat.stok = alat.stok + peminjaman.jumlah
                WHERE peminjaman.id = NEW.peminjaman_id;
            END
        ");
    }

    public function down(): void
    {
        DB::unprepared('DROP TRIGGER IF EXISTS tambah_stok');
        DB::unprepared('DROP TRIGGER IF EXISTS kurangi_stok');
        DB::unprepared('DROP PROCEDURE IF EXISTS kembalikan_alat');
        DB::unprepared('DROP FUNCTION IF EXISTS hitung_denda');
    }
};
