<?php

namespace Database\Seeders;

use App\Models\Alat;
use App\Models\Kategori;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // 3 akun, satu untuk setiap level
        User::create(['name' => 'Administrator', 'username' => 'admin', 'password' => 'admin123', 'role' => 'admin']);
        User::create(['name' => 'Petugas Lab', 'username' => 'petugas', 'password' => 'petugas123', 'role' => 'petugas']);
        User::create(['name' => 'Budi Siswa', 'username' => 'peminjam', 'password' => 'peminjam123', 'role' => 'peminjam']);

        // kategori
        $elektronik = Kategori::create(['nama_kategori' => 'Elektronik']);
        $olahraga = Kategori::create(['nama_kategori' => 'Olahraga']);
        $perkakas = Kategori::create(['nama_kategori' => 'Perkakas']);

        // alat
        Alat::create(['kategori_id' => $elektronik->id, 'nama_alat' => 'Proyektor', 'stok' => 3, 'keterangan' => 'Epson']);
        Alat::create(['kategori_id' => $elektronik->id, 'nama_alat' => 'Laptop', 'stok' => 5, 'keterangan' => 'Untuk presentasi']);
        Alat::create(['kategori_id' => $olahraga->id, 'nama_alat' => 'Bola Basket', 'stok' => 10, 'keterangan' => null]);
        Alat::create(['kategori_id' => $perkakas->id, 'nama_alat' => 'Obeng Set', 'stok' => 4, 'keterangan' => 'Lengkap']);
    }
}
