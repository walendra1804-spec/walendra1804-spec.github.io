@extends('layout')

@section('content')
<h3>Data Alat</h3>
<a href="{{ route('alat.create') }}" class="btn btn-primary mb-3">+ Tambah Alat</a>

<table class="table table-bordered bg-white">
    <tr>
        <th>No</th>
        <th>Nama Alat</th>
        <th>Kategori</th>
        <th>Stok</th>
        <th>Keterangan</th>
        <th>Aksi</th>
    </tr>
    @foreach ($alat as $a)
    <tr>
        <td>{{ $alat->firstItem() + $loop->index }}</td>
        <td>{{ $a->nama_alat }}</td>
        <td>{{ $a->kategori->nama_kategori }}</td>
        <td>{{ $a->stok }}</td>
        <td>{{ $a->keterangan }}</td>
        <td>
            <a href="{{ route('alat.edit', $a->id) }}" class="btn btn-warning btn-sm">Edit</a>
            <form action="{{ route('alat.destroy', $a->id) }}" method="POST" class="d-inline">
                @csrf
                @method('DELETE')
                <button class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus?')">Hapus</button>
            </form>
        </td>
    </tr>
    @endforeach
</table>

{{ $alat->links('pagination::bootstrap-5') }}
@endsection
