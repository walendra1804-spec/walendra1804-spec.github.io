@extends('layout')

@section('content')
<h3>Dashboard</h3>
<p>Selamat datang, <b>{{ auth()->user()->name }}</b>. Anda login sebagai <b>{{ auth()->user()->role }}</b>.</p>

<div class="row">
    <div class="col-md-3 mb-3">
        <div class="card text-bg-primary">
            <div class="card-body">
                <h6>Jumlah Alat</h6>
                <h2>{{ $jumlahAlat }}</h2>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card text-bg-success">
            <div class="card-body">
                <h6>Jumlah User</h6>
                <h2>{{ $jumlahUser }}</h2>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card text-bg-warning">
            <div class="card-body">
                <h6>Menunggu Persetujuan</h6>
                <h2>{{ $menunggu }}</h2>
            </div>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card text-bg-danger">
            <div class="card-body">
                <h6>Sedang Dipinjam</h6>
                <h2>{{ $dipinjam }}</h2>
            </div>
        </div>
    </div>
</div>
@endsection
