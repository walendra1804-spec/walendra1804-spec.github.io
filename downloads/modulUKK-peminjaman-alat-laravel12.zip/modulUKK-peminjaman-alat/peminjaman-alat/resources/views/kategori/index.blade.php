@extends('layout')

@section('content')
<h3>Data Kategori</h3>
<a href="{{ route('kategori.create') }}" class="btn btn-primary mb-3">+ Tambah Kategori</a>

<table class="table table-bordered bg-white">
    <tr>
        <th>No</th>
        <th>Nama Kategori</th>
        <th>Aksi</th>
    </tr>
    @foreach ($kategori as $k)
    <tr>
        <td>{{ $kategori->firstItem() + $loop->index }}</td>
        <td>{{ $k->nama_kategori }}</td>
        <td>
            <a href="{{ route('kategori.edit', $k->id) }}" class="btn btn-warning btn-sm">Edit</a>
            <form action="{{ route('kategori.destroy', $k->id) }}" method="POST" class="d-inline">
                @csrf
                @method('DELETE')
                <button class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus?')">Hapus</button>
            </form>
        </td>
    </tr>
    @endforeach
</table>

{{ $kategori->links('pagination::bootstrap-5') }}
@endsection
