<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Peminjaman Alat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* saat dicetak, sembunyikan navbar & tombol */
        @media print {
            .no-print { display: none !important; }
        }
    </style>
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-primary mb-4 no-print">
    <div class="container">
        <a class="navbar-brand" href="/dashboard">Peminjaman Alat</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="menu">
            <ul class="navbar-nav me-auto">
                <li class="nav-item"><a class="nav-link" href="/dashboard">Dashboard</a></li>

                @if (auth()->user()->role == 'admin')
                    <li class="nav-item"><a class="nav-link" href="{{ route('user.index') }}">User</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('kategori.index') }}">Kategori</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('alat.index') }}">Alat</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('peminjaman.index') }}">Peminjaman</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('pengembalian.index') }}">Pengembalian</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('log.index') }}">Log Aktivitas</a></li>
                @endif

                @if (auth()->user()->role == 'petugas')
                    <li class="nav-item"><a class="nav-link" href="{{ route('petugas.peminjaman') }}">Persetujuan</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('petugas.pengembalian') }}">Pantau Pengembalian</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('petugas.laporan') }}">Laporan</a></li>
                @endif

                @if (auth()->user()->role == 'peminjam')
                    <li class="nav-item"><a class="nav-link" href="{{ route('peminjam.alat') }}">Daftar Alat</a></li>
                    <li class="nav-item"><a class="nav-link" href="{{ route('peminjam.riwayat') }}">Peminjaman Saya</a></li>
                @endif
            </ul>

            <span class="navbar-text text-white me-3">
                {{ auth()->user()->name }} ({{ auth()->user()->role }})
            </span>
            <form action="{{ route('logout') }}" method="POST">
                @csrf
                <button class="btn btn-light btn-sm">Logout</button>
            </form>
        </div>
    </div>
</nav>

<div class="container">
    {{-- pesan sukses / gagal --}}
    @if (session('success'))
        <div class="alert alert-success no-print">{{ session('success') }}</div>
    @endif
    @if (session('error'))
        <div class="alert alert-danger no-print">{{ session('error') }}</div>
    @endif

    {{-- pesan error validasi --}}
    @if ($errors->any())
        <div class="alert alert-danger no-print">
            <ul class="mb-0">
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    @yield('content')
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
