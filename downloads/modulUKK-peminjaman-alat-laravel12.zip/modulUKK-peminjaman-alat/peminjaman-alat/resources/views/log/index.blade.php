@extends('layout')

@section('content')
<h3>Log Aktivitas</h3>

<table class="table table-bordered bg-white">
    <tr>
        <th>Waktu</th>
        <th>User</th>
        <th>Aktivitas</th>
    </tr>
    @foreach ($logs as $log)
    <tr>
        <td>{{ $log->created_at }}</td>
        <td>{{ $log->user->name ?? '-' }}</td>
        <td>{{ $log->aktivitas }}</td>
    </tr>
    @endforeach
</table>

{{ $logs->links('pagination::bootstrap-5') }}
@endsection
