@extends('layout')

@section('content')
<h3>Daftar Alat</h3>

<form action="{{ route('peminjam.alat') }}" method="GET" class="row g-2 mb-3">
    <div class="col-auto">
        <input type="text" name="cari" class="form-control" placeholder="Cari nama alat..." value="{{ $cari }}">
    </div>
    <div class="col-auto">
        <button class="btn btn-primary">Cari</button>
    </div>
</form>

<table class="table table-bordered bg-white">
    <tr>
        <th>No</th>
        <th>Nama Alat</th>
        <th>Kategori</th>
        <th>Stok</th>
        <th>Keterangan</th>
        <th>Aksi</th>
    </tr>
    @foreach ($alat as $a)
    <tr>
        <td>{{ $alat->firstItem() + $loop->index }}</td>
        <td>{{ $a->nama_alat }}</td>
        <td>{{ $a->kategori->nama_kategori }}</td>
        <td>{{ $a->stok }}</td>
        <td>{{ $a->keterangan }}</td>
        <td>
            @if ($a->stok > 0)
                <a href="{{ route('peminjam.form', $a->id) }}" class="btn btn-primary btn-sm">Pinjam</a>
            @else
                <span class="badge bg-secondary">Stok habis</span>
            @endif
        </td>
    </tr>
    @endforeach
</table>

{{ $alat->links('pagination::bootstrap-5') }}
@endsection
