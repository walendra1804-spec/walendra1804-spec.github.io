@extends('layout')

@section('content')
<h3>Ajukan Peminjaman</h3>

<form action="{{ route('peminjam.pinjam', $alat->id) }}" method="POST" class="card card-body">
    @csrf
    <p>
        Alat: <b>{{ $alat->nama_alat }}</b><br>
        Stok tersedia: <b>{{ $alat->stok }}</b>
    </p>
    <div class="mb-3">
        <label class="form-label">Jumlah</label>
        <input type="number" name="jumlah" class="form-control" value="{{ old('jumlah', 1) }}" min="1" max="{{ $alat->stok }}">
    </div>
    <div class="mb-3">
        <label class="form-label">Tanggal Kembali</label>
        <input type="date" name="batas_kembali" class="form-control" value="{{ old('batas_kembali') }}">
    </div>
    <p class="text-muted">Terlambat mengembalikan dikenakan denda Rp 5.000 per hari.</p>
    <div>
        <button class="btn btn-primary">Ajukan</button>
        <a href="{{ route('peminjam.alat') }}" class="btn btn-secondary">Kembali</a>
    </div>
</form>
@endsection
