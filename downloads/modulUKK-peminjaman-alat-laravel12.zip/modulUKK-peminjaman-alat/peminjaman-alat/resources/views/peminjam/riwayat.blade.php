@extends('layout')

@section('content')
<h3>Peminjaman Saya</h3>

<table class="table table-bordered bg-white">
    <tr>
        <th>No</th>
        <th>Alat</th>
        <th>Jumlah</th>
        <th>Tgl Pinjam</th>
        <th>Batas Kembali</th>
        <th>Status</th>
        <th>Denda</th>
        <th>Aksi</th>
    </tr>
    @forelse ($peminjaman as $p)
    <tr>
        <td>{{ $peminjaman->firstItem() + $loop->index }}</td>
        <td>{{ $p->alat->nama_alat }}</td>
        <td>{{ $p->jumlah }}</td>
        <td>{{ $p->tanggal_pinjam }}</td>
        <td>{{ $p->batas_kembali }}</td>
        <td><span class="badge bg-secondary">{{ $p->status }}</span></td>
        <td>Rp {{ number_format($p->pengembalian->denda ?? 0, 0, ',', '.') }}</td>
        <td>
            @if ($p->status == 'disetujui')
                <form action="{{ route('peminjam.kembalikan', $p->id) }}" method="POST">
                    @csrf
                    <button class="btn btn-success btn-sm" onclick="return confirm('Kembalikan alat ini?')">Kembalikan</button>
                </form>
            @endif
        </td>
    </tr>
    @empty
    <tr>
        <td colspan="8" class="text-center">Belum ada peminjaman</td>
    </tr>
    @endforelse
</table>

{{ $peminjaman->links('pagination::bootstrap-5') }}
@endsection
