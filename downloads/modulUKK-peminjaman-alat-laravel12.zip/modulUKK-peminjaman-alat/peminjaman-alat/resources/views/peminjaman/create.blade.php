@extends('layout')

@section('content')
<h3>Tambah Peminjaman</h3>

<form action="{{ route('peminjaman.store') }}" method="POST" class="card card-body">
    @csrf
    <div class="mb-3">
        <label class="form-label">Peminjam</label>
        <select name="user_id" class="form-select">
            @foreach ($users as $u)
                <option value="{{ $u->id }}">{{ $u->name }}</option>
            @endforeach
        </select>
    </div>
    <div class="mb-3">
        <label class="form-label">Alat</label>
        <select name="alat_id" class="form-select">
            @foreach ($alat as $a)
                <option value="{{ $a->id }}">{{ $a->nama_alat }} (stok: {{ $a->stok }})</option>
            @endforeach
        </select>
    </div>
    <div class="mb-3">
        <label class="form-label">Jumlah</label>
        <input type="number" name="jumlah" class="form-control" value="{{ old('jumlah', 1) }}">
    </div>
    <div class="mb-3">
        <label class="form-label">Tanggal Pinjam</label>
        <input type="date" name="tanggal_pinjam" class="form-control" value="{{ old('tanggal_pinjam', date('Y-m-d')) }}">
    </div>
    <div class="mb-3">
        <label class="form-label">Batas Kembali</label>
        <input type="date" name="batas_kembali" class="form-control" value="{{ old('batas_kembali') }}">
    </div>
    <div>
        <button class="btn btn-primary">Simpan</button>
        <a href="{{ route('peminjaman.index') }}" class="btn btn-secondary">Kembali</a>
    </div>
</form>
@endsection
