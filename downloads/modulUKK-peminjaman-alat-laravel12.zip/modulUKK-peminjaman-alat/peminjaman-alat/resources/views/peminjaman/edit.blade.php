@extends('layout')

@section('content')
<h3>Edit Peminjaman</h3>

<form action="{{ route('peminjaman.update', $peminjaman->id) }}" method="POST" class="card card-body">
    @csrf
    @method('PUT')
    <div class="mb-3">
        <label class="form-label">Peminjam</label>
        <select name="user_id" class="form-select">
            @foreach ($users as $u)
                <option value="{{ $u->id }}" @selected($u->id == $peminjaman->user_id)>{{ $u->name }}</option>
            @endforeach
        </select>
    </div>
    <div class="mb-3">
        <label class="form-label">Alat</label>
        <select name="alat_id" class="form-select">
            @foreach ($alat as $a)
                <option value="{{ $a->id }}" @selected($a->id == $peminjaman->alat_id)>{{ $a->nama_alat }} (stok: {{ $a->stok }})</option>
            @endforeach
        </select>
    </div>
    <div class="mb-3">
        <label class="form-label">Jumlah</label>
        <input type="number" name="jumlah" class="form-control" value="{{ old('jumlah', $peminjaman->jumlah) }}">
    </div>
    <div class="mb-3">
        <label class="form-label">Tanggal Pinjam</label>
        <input type="date" name="tanggal_pinjam" class="form-control" value="{{ old('tanggal_pinjam', $peminjaman->tanggal_pinjam) }}">
    </div>
    <div class="mb-3">
        <label class="form-label">Batas Kembali</label>
        <input type="date" name="batas_kembali" class="form-control" value="{{ old('batas_kembali', $peminjaman->batas_kembali) }}">
    </div>
    <div class="mb-3">
        <label class="form-label">Status</label>
        <select name="status" class="form-select">
            <option value="menunggu" @selected($peminjaman->status == 'menunggu')>Menunggu</option>
            <option value="disetujui" @selected($peminjaman->status == 'disetujui')>Disetujui</option>
            <option value="ditolak" @selected($peminjaman->status == 'ditolak')>Ditolak</option>
            <option value="dikembalikan" @selected($peminjaman->status == 'dikembalikan')>Dikembalikan</option>
        </select>
    </div>
    <div>
        <button class="btn btn-primary">Update</button>
        <a href="{{ route('peminjaman.index') }}" class="btn btn-secondary">Kembali</a>
    </div>
</form>
@endsection
