@extends('layout')

@section('content')
<h3>Data Peminjaman</h3>
<a href="{{ route('peminjaman.create') }}" class="btn btn-primary mb-3">+ Tambah Peminjaman</a>

<table class="table table-bordered bg-white">
    <tr>
        <th>No</th>
        <th>Peminjam</th>
        <th>Alat</th>
        <th>Jumlah</th>
        <th>Tgl Pinjam</th>
        <th>Batas Kembali</th>
        <th>Status</th>
        <th>Aksi</th>
    </tr>
    @foreach ($peminjaman as $p)
    <tr>
        <td>{{ $peminjaman->firstItem() + $loop->index }}</td>
        <td>{{ $p->user->name }}</td>
        <td>{{ $p->alat->nama_alat }}</td>
        <td>{{ $p->jumlah }}</td>
        <td>{{ $p->tanggal_pinjam }}</td>
        <td>{{ $p->batas_kembali }}</td>
        <td><span class="badge bg-secondary">{{ $p->status }}</span></td>
        <td>
            <a href="{{ route('peminjaman.edit', $p->id) }}" class="btn btn-warning btn-sm">Edit</a>
            <form action="{{ route('peminjaman.destroy', $p->id) }}" method="POST" class="d-inline">
                @csrf
                @method('DELETE')
                <button class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus?')">Hapus</button>
            </form>
        </td>
    </tr>
    @endforeach
</table>

{{ $peminjaman->links('pagination::bootstrap-5') }}
@endsection
