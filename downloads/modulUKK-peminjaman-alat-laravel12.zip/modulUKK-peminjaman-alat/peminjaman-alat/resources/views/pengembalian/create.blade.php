@extends('layout')

@section('content')
<h3>Tambah Pengembalian</h3>

<form action="{{ route('pengembalian.store') }}" method="POST" class="card card-body">
    @csrf
    <div class="mb-3">
        <label class="form-label">Peminjaman (yang sedang dipinjam)</label>
        <select name="peminjaman_id" class="form-select">
            @foreach ($peminjaman as $p)
                <option value="{{ $p->id }}">
                    #{{ $p->id }} - {{ $p->user->name }} - {{ $p->alat->nama_alat }} (batas: {{ $p->batas_kembali }})
                </option>
            @endforeach
        </select>
    </div>
    <div class="mb-3">
        <label class="form-label">Tanggal Dikembalikan</label>
        <input type="date" name="tanggal_dikembalikan" class="form-control" value="{{ date('Y-m-d') }}">
    </div>
    <p class="text-muted">Denda dihitung otomatis: Rp 5.000 per hari keterlambatan.</p>
    <div>
        <button class="btn btn-primary">Simpan</button>
        <a href="{{ route('pengembalian.index') }}" class="btn btn-secondary">Kembali</a>
    </div>
</form>
@endsection
