@extends('layout')

@section('content')
<h3>Edit Pengembalian</h3>

<form action="{{ route('pengembalian.update', $pengembalian->id) }}" method="POST" class="card card-body">
    @csrf
    @method('PUT')
    <p>
        Peminjam: <b>{{ $pengembalian->peminjaman->user->name }}</b><br>
        Alat: <b>{{ $pengembalian->peminjaman->alat->nama_alat }}</b><br>
        Batas Kembali: <b>{{ $pengembalian->peminjaman->batas_kembali }}</b>
    </p>
    <div class="mb-3">
        <label class="form-label">Tanggal Dikembalikan</label>
        <input type="date" name="tanggal_dikembalikan" class="form-control" value="{{ $pengembalian->tanggal_dikembalikan }}">
    </div>
    <p class="text-muted">Denda akan dihitung ulang otomatis.</p>
    <div>
        <button class="btn btn-primary">Update</button>
        <a href="{{ route('pengembalian.index') }}" class="btn btn-secondary">Kembali</a>
    </div>
</form>
@endsection
