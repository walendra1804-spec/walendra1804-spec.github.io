@extends('layout')

@section('content')
<h3>Data Pengembalian</h3>
<a href="{{ route('pengembalian.create') }}" class="btn btn-primary mb-3">+ Tambah Pengembalian</a>

<table class="table table-bordered bg-white">
    <tr>
        <th>No</th>
        <th>Peminjam</th>
        <th>Alat</th>
        <th>Batas Kembali</th>
        <th>Tgl Dikembalikan</th>
        <th>Denda</th>
        <th>Aksi</th>
    </tr>
    @foreach ($pengembalian as $k)
    <tr>
        <td>{{ $pengembalian->firstItem() + $loop->index }}</td>
        <td>{{ $k->peminjaman->user->name }}</td>
        <td>{{ $k->peminjaman->alat->nama_alat }}</td>
        <td>{{ $k->peminjaman->batas_kembali }}</td>
        <td>{{ $k->tanggal_dikembalikan }}</td>
        <td>Rp {{ number_format($k->denda, 0, ',', '.') }}</td>
        <td>
            <a href="{{ route('pengembalian.edit', $k->id) }}" class="btn btn-warning btn-sm">Edit</a>
            <form action="{{ route('pengembalian.destroy', $k->id) }}" method="POST" class="d-inline">
                @csrf
                @method('DELETE')
                <button class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus?')">Hapus</button>
            </form>
        </td>
    </tr>
    @endforeach
</table>

{{ $pengembalian->links('pagination::bootstrap-5') }}
@endsection
