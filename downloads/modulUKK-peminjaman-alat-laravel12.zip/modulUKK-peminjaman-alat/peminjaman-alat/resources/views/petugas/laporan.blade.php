@extends('layout')

@section('content')
<h3>Laporan Peminjaman Alat</h3>

<form action="{{ route('petugas.laporan') }}" method="GET" class="row g-2 mb-3 no-print">
    <div class="col-auto">
        <input type="date" name="dari" class="form-control" value="{{ $dari }}">
    </div>
    <div class="col-auto">
        <input type="date" name="sampai" class="form-control" value="{{ $sampai }}">
    </div>
    <div class="col-auto">
        <button class="btn btn-primary">Tampilkan</button>
        <button type="button" class="btn btn-success" onclick="window.print()">Cetak</button>
    </div>
</form>

<p>Periode: <b>{{ $dari }}</b> s/d <b>{{ $sampai }}</b></p>

<table class="table table-bordered bg-white">
    <tr>
        <th>No</th>
        <th>Peminjam</th>
        <th>Alat</th>
        <th>Jumlah</th>
        <th>Tgl Pinjam</th>
        <th>Batas Kembali</th>
        <th>Tgl Dikembalikan</th>
        <th>Status</th>
        <th>Denda</th>
    </tr>
    @php $totalDenda = 0; @endphp
    @forelse ($data as $p)
    <tr>
        <td>{{ $loop->iteration }}</td>
        <td>{{ $p->user->name }}</td>
        <td>{{ $p->alat->nama_alat }}</td>
        <td>{{ $p->jumlah }}</td>
        <td>{{ $p->tanggal_pinjam }}</td>
        <td>{{ $p->batas_kembali }}</td>
        <td>{{ $p->pengembalian->tanggal_dikembalikan ?? '-' }}</td>
        <td>{{ $p->status }}</td>
        <td>Rp {{ number_format($p->pengembalian->denda ?? 0, 0, ',', '.') }}</td>
    </tr>
    @php $totalDenda += $p->pengembalian->denda ?? 0; @endphp
    @empty
    <tr>
        <td colspan="9" class="text-center">Tidak ada data</td>
    </tr>
    @endforelse
    <tr>
        <th colspan="8" class="text-end">Total Denda</th>
        <th>Rp {{ number_format($totalDenda, 0, ',', '.') }}</th>
    </tr>
</table>
@endsection
