@extends('layout')

@section('content')
<h3>Persetujuan Peminjaman</h3>
<p>Daftar pengajuan peminjaman yang menunggu persetujuan.</p>

<table class="table table-bordered bg-white">
    <tr>
        <th>No</th>
        <th>Peminjam</th>
        <th>Alat</th>
        <th>Jumlah</th>
        <th>Stok Alat</th>
        <th>Tgl Pinjam</th>
        <th>Batas Kembali</th>
        <th>Aksi</th>
    </tr>
    @forelse ($peminjaman as $p)
    <tr>
        <td>{{ $peminjaman->firstItem() + $loop->index }}</td>
        <td>{{ $p->user->name }}</td>
        <td>{{ $p->alat->nama_alat }}</td>
        <td>{{ $p->jumlah }}</td>
        <td>{{ $p->alat->stok }}</td>
        <td>{{ $p->tanggal_pinjam }}</td>
        <td>{{ $p->batas_kembali }}</td>
        <td>
            <form action="{{ route('petugas.setujui', $p->id) }}" method="POST" class="d-inline">
                @csrf
                <button class="btn btn-success btn-sm">Setujui</button>
            </form>
            <form action="{{ route('petugas.tolak', $p->id) }}" method="POST" class="d-inline">
                @csrf
                <button class="btn btn-danger btn-sm" onclick="return confirm('Tolak peminjaman ini?')">Tolak</button>
            </form>
        </td>
    </tr>
    @empty
    <tr>
        <td colspan="8" class="text-center">Tidak ada pengajuan</td>
    </tr>
    @endforelse
</table>

{{ $peminjaman->links('pagination::bootstrap-5') }}
@endsection
