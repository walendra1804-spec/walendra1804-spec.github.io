@extends('layout')

@section('content')
<h3>Pantau Pengembalian</h3>

<h5 class="mt-4">Alat yang Sedang Dipinjam</h5>
<table class="table table-bordered bg-white">
    <tr>
        <th>Peminjam</th>
        <th>Alat</th>
        <th>Jumlah</th>
        <th>Batas Kembali</th>
        <th>Keterangan</th>
    </tr>
    @forelse ($dipinjam as $p)
    <tr>
        <td>{{ $p->user->name }}</td>
        <td>{{ $p->alat->nama_alat }}</td>
        <td>{{ $p->jumlah }}</td>
        <td>{{ $p->batas_kembali }}</td>
        <td>
            @if ($p->batas_kembali < date('Y-m-d'))
                <span class="badge bg-danger">Terlambat</span>
            @else
                <span class="badge bg-success">Masih dalam waktu</span>
            @endif
        </td>
    </tr>
    @empty
    <tr>
        <td colspan="5" class="text-center">Tidak ada alat yang sedang dipinjam</td>
    </tr>
    @endforelse
</table>

<h5 class="mt-4">Riwayat Pengembalian</h5>
<table class="table table-bordered bg-white">
    <tr>
        <th>Peminjam</th>
        <th>Alat</th>
        <th>Batas Kembali</th>
        <th>Tgl Dikembalikan</th>
        <th>Denda</th>
    </tr>
    @foreach ($kembali as $k)
    <tr>
        <td>{{ $k->peminjaman->user->name }}</td>
        <td>{{ $k->peminjaman->alat->nama_alat }}</td>
        <td>{{ $k->peminjaman->batas_kembali }}</td>
        <td>{{ $k->tanggal_dikembalikan }}</td>
        <td>Rp {{ number_format($k->denda, 0, ',', '.') }}</td>
    </tr>
    @endforeach
</table>

{{ $kembali->links('pagination::bootstrap-5') }}
@endsection
