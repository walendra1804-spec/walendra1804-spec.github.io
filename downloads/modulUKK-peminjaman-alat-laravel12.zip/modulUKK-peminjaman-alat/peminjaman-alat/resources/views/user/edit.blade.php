@extends('layout')

@section('content')
<h3>Edit User</h3>

<form action="{{ route('user.update', $user->id) }}" method="POST" class="card card-body">
    @csrf
    @method('PUT')
    <div class="mb-3">
        <label class="form-label">Nama</label>
        <input type="text" name="name" class="form-control" value="{{ old('name', $user->name) }}">
    </div>
    <div class="mb-3">
        <label class="form-label">Username</label>
        <input type="text" name="username" class="form-control" value="{{ old('username', $user->username) }}">
    </div>
    <div class="mb-3">
        <label class="form-label">Password <small class="text-muted">(kosongkan jika tidak diubah)</small></label>
        <input type="password" name="password" class="form-control">
    </div>
    <div class="mb-3">
        <label class="form-label">Role</label>
        <select name="role" class="form-select">
            <option value="admin" @selected($user->role == 'admin')>Admin</option>
            <option value="petugas" @selected($user->role == 'petugas')>Petugas</option>
            <option value="peminjam" @selected($user->role == 'peminjam')>Peminjam</option>
        </select>
    </div>
    <div>
        <button class="btn btn-primary">Update</button>
        <a href="{{ route('user.index') }}" class="btn btn-secondary">Kembali</a>
    </div>
</form>
@endsection
