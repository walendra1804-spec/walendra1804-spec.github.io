@extends('layout')

@section('content')
<h3>Data User</h3>
<a href="{{ route('user.create') }}" class="btn btn-primary mb-3">+ Tambah User</a>

<table class="table table-bordered bg-white">
    <tr>
        <th>No</th>
        <th>Nama</th>
        <th>Username</th>
        <th>Role</th>
        <th>Aksi</th>
    </tr>
    @foreach ($users as $u)
    <tr>
        <td>{{ $users->firstItem() + $loop->index }}</td>
        <td>{{ $u->name }}</td>
        <td>{{ $u->username }}</td>
        <td>{{ $u->role }}</td>
        <td>
            <a href="{{ route('user.edit', $u->id) }}" class="btn btn-warning btn-sm">Edit</a>
            <form action="{{ route('user.destroy', $u->id) }}" method="POST" class="d-inline">
                @csrf
                @method('DELETE')
                <button class="btn btn-danger btn-sm" onclick="return confirm('Yakin hapus?')">Hapus</button>
            </form>
        </td>
    </tr>
    @endforeach
</table>

{{ $users->links('pagination::bootstrap-5') }}
@endsection
