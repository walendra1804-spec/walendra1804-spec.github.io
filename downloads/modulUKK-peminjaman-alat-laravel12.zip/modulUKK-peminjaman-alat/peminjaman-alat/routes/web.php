<?php

use App\Http\Controllers\AlatController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\KategoriController;
use App\Http\Controllers\LogController;
use App\Http\Controllers\PeminjamanController;
use App\Http\Controllers\PeminjamController;
use App\Http\Controllers\PengembalianController;
use App\Http\Controllers\PetugasController;
use App\Http\Controllers\UserController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return redirect('/login');
});

// hanya untuk yang BELUM login
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'index'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
});

// hanya untuk yang SUDAH login
Route::middleware('auth')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // ===== ADMIN =====
    Route::middleware('role:admin')->prefix('admin')->group(function () {
        Route::resource('user', UserController::class)->except('show');
        Route::resource('kategori', KategoriController::class)->except('show');
        Route::resource('alat', AlatController::class)->except('show');
        Route::resource('peminjaman', PeminjamanController::class)->except('show');
        Route::resource('pengembalian', PengembalianController::class)->except('show');
        Route::get('log', [LogController::class, 'index'])->name('log.index');
    });

    // ===== PETUGAS =====
    Route::middleware('role:petugas')->prefix('petugas')->group(function () {
        Route::get('peminjaman', [PetugasController::class, 'peminjaman'])->name('petugas.peminjaman');
        Route::post('peminjaman/{peminjaman}/setujui', [PetugasController::class, 'setujui'])->name('petugas.setujui');
        Route::post('peminjaman/{peminjaman}/tolak', [PetugasController::class, 'tolak'])->name('petugas.tolak');
        Route::get('pengembalian', [PetugasController::class, 'pengembalian'])->name('petugas.pengembalian');
        Route::get('laporan', [PetugasController::class, 'laporan'])->name('petugas.laporan');
    });

    // ===== PEMINJAM =====
    Route::middleware('role:peminjam')->prefix('peminjam')->group(function () {
        Route::get('alat', [PeminjamController::class, 'alat'])->name('peminjam.alat');
        Route::get('pinjam/{alat}', [PeminjamController::class, 'formPinjam'])->name('peminjam.form');
        Route::post('pinjam/{alat}', [PeminjamController::class, 'pinjam'])->name('peminjam.pinjam');
        Route::get('riwayat', [PeminjamController::class, 'riwayat'])->name('peminjam.riwayat');
        Route::post('kembalikan/{peminjaman}', [PeminjamController::class, 'kembalikan'])->name('peminjam.kembalikan');
    });
});
